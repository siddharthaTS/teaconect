/* eslint no-console: 0 */

global.icplApp = {};
// global.isProductionMode = false;
// icplApp.isClientMode = true;
icplApp.appVersion = 1;

const port = process.env.PORT || 1368;
// eslint-disable-next-line no-unused-vars
const DEVELOPMENT_BASEPATH = `http://localhost:${port}`;


icplApp.appDisplayName = "TEAConnect";
const server = require("./server-obfuscated");

global.masterPrivileges = {
	"user_management": {
		"display": "Users",
		"page": "userManagement",
		"path": "/user-management.html",
		"access": [
			"view",
			"create",
			"update",
		],
		"childNodes": null,
	},
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"seller_management": {
				"display": "Seller Management",
				"page": "sellerManagement",
				"path": "/masters/seller-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"buyer_management": {
				"display": "Buyer Management",
				"page": "buyerManagement",
				"path": "/masters/buyer-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"location_management": {
				"display": "Location Management",
				"page": "locationManagement",
				"path": "/masters/location-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"auction_center_management": {
				"display": "Auction Center Management",
				"page": "auctionCenterManagement",
				"path": "/masters/auction-center-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"category_management": {
				"display": "Category Management",
				"page": "categoryManagement",
				"path": "/masters/category-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mark_management": {
				"display": "Mark Management",
				"page": "markManagement",
				"path": "/masters/mark-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"grade_management": {
				"display": "Grade Management",
				"page": "gradeManagement",
				"path": "/masters/grade-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"tasting_parameter_management": {
				"display": "Tasting Parameter",
				"page": "tastingParameter",
				"path": "/masters/tasting-parameter-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"group_management": {
				"display": "Group management",
				"page": "groupManagement",
				"path": "/masters/group-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"mapping_management": {
		"display": "Mapping",
		"access": [
			"view",
		],
		"childNodes": {
			"group_seller_mapping": {
				"display": "Group Seller",
				"page": "groupSellerMapping",
				"path": "/mapping/group-seller.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"seller_mark_mapping": {
				"display": "Seller Mark",
				"page": "sellerMarkMapping",
				"path": "/mapping/seller-mark.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mark_entity_mapping": {
				"display": "Mark Entity",
				"page": "markEntityMapping",
				"path": "/mapping/mark-entity.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"invoice_management": {
		"display": "Invoices",
		"access": [
			"view",
		],
		"childNodes": {
			"muster_tasting_invoices": {
				"display": "Muster",
				"page": "musterTastingInvoices",
				"path": "/invoices/muster.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"auction_tasting_invoices": {
				"display": "Auction",
				"page": "auctionTastingInvoices",
				"path": "/invoices/auction.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"finance_tasting_invoices": {
				"display": "Finance",
				"page": "financeTastingInvoices",
				"path": "/invoices/finance.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"private_sale_tasting_invoices": {
				"display": "Private Sale",
				"page": "privateSaleTastingInvoices",
				"path": "/invoices/private-sale.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"tea_tasting": {
		"display": "Tasting",
		"page": "teaTasting",
		"path": "/tea-tasting.html",
		"access": [
			"create",
			"update",
		],
		"childNodes": null,
	},
	"tasting_reports": {
		"display": "Reports",
		"access": [
			"view",
		],
		"childNodes": {
			"muster_tasting_reports": {
				"display": "Muster",
				"page": "musterTastingReports",
				"path": "/reports/muster.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"auction_tasting_reports": {
				"display": "Auction",
				"page": "auctionTastingReports",
				"path": "/reports/auction.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"finance_tasting_reports": {
				"display": "Finance",
				"page": "financeTastingReports",
				"path": "/reports/finance.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
			"private_sale_tasting_reports": {
				"display": "Private Sale",
				"page": "privateSaleTastingReports",
				"path": "/reports/private-sale.html",
				"access": [
					"view",
				],
				"childNodes": null,
			},
		},
	},
};
global.userRoleMap = {};
global.userRoleMap.Admin = {
	"user_management": global.masterPrivileges.user_management,
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"location_management": {
				"display": "Location Management",
				"page": "locationManagement",
				"path": "/masters/location-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"auction_center_management": {
				"display": "Auction Center Management",
				"page": "auctionCenterManagement",
				"path": "/masters/auction-center-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
};
global.userRoleMap.Support = {
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"seller_management": {
				"display": "Seller Management",
				"page": "sellerManagement",
				"path": "/masters/seller-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"category_management": {
				"display": "Category Management",
				"page": "categoryManagement",
				"path": "/masters/category-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"mark_management": {
				"display": "Mark Management",
				"page": "markManagement",
				"path": "/masters/mark-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"grade_management": {
				"display": "Grade Management",
				"page": "gradeManagement",
				"path": "/masters/grade-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"tasting_parameter_management": {
				"display": "Tasting Parameter",
				"page": "tastingParameter",
				"path": "/masters/tasting-parameter-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
			"group_management": {
				"display": "Group management",
				"page": "groupManagement",
				"path": "/masters/group-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"invoice_management": global.masterPrivileges.invoice_management,
	"mapping_management": global.masterPrivileges.mapping_management,
	"tea_tasting": global.masterPrivileges.tea_tasting,
	"tasting_reports": global.masterPrivileges.tasting_reports,
};
global.userRoleMap.Taster = {
	"master_management": {
		"display": "Masters",
		"access": [
			"view",
		],
		"childNodes": {
			"tasting_parameter_management": {
				"display": "Tasting Parameter",
				"page": "tastingParameter",
				"path": "/masters/tasting-parameter-management.html",
				"access": [
					"view",
					"create",
					"update",
				],
				"childNodes": null,
			},
		},
	},
	"tea_tasting": global.masterPrivileges.tea_tasting,
	"tasting_reports": global.masterPrivileges.tasting_reports,
};
global.hostCompanyId = "5eb2d65f5bbfeb46054a93b0";
global.hostCompanyName = "Parcon India Pvt Ltd";
global.hostCompanyEmail = " info@parcon-india.com";
global.hostCompanyAddress = "2nd Floor 207 A.J.C. Bose Road, Kolkata 700017";

icplApp.tastingAppVersionName = "1.0.0.1";
icplApp.tastingAppVersionCode = 2;

server.listen(port, () => console.log(`${icplApp.appDisplayName} running on http://localhost:${port}`));
