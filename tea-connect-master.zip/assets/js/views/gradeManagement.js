
/* global grades categories:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "gradeController",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "gradeController",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "gradeController",
				},
			},
			url: "/update?gradeid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$("#grade_selection").dropdown({forceSelection: false});
			$("#grade_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-grade-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.gradeid) {
					$("#grade_selection").dropdown("set selected", currentParams.gradeid);
				}
			}, 300);
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$(".create-grade-tabs .item").tab();
			holder = document.getElementById("holder");
			holder.ondragover = function() {
				$(this).addClass("div_drag_hover");
				return false;
			};
			holder.ondragend = function() {
				$(this).removeClass("div_drag_hover");
				return false;
			};
			holder.ondrop = function(e) {
				$(this).removeClass("div_drag_hover");
				e.preventDefault();
				processFileForUpload(e);
			};
			setTimeout(function() {
				$(".boolean-field").checkbox();
				$("input.datepicker").each(function(idx, ele) {
					$(ele).daterangepicker({
						format: "DD MMM YYYY",
						singleDatePicker: true,
						showDropdowns: true,
						startDate: moment(),
					},
					function(start, end, label) {
						$(ele).attr("data-value", start.toDate().getTime());
					});
				});
			}, 500);
		}
	});
}]);

var categoryMap = {};
app.controller("gradeController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.grades = grades;
	$scope.categories = categories;
	$scope.currentGrade = {isActive: true};
	$scope.currentGradeOrg = {isActive: true};
	$scope.gradesUnderProcessing = {};

	$scope.gradeChanged = function() {
		var gradeId = $("#grade_selection input").val();
		if (gradeId.length > 1) {
			if ($state.current.name == "update") {
				var posInGrades = _.findIndex($scope.grades, ["_id", gradeId]);
				if (posInGrades > -1) {
					$scope.currentGrade = JSON.parse(JSON.stringify($scope.grades[posInGrades]));
					$scope.currentGradeOrg = JSON.parse(JSON.stringify($scope.grades[posInGrades]));
					$(".datepicker").each(function(idx, ele) {
						try {
							$(ele).attr("data-value", $scope.currentGrade[$(ele).attr("name")]);
							var tmpMoment = moment($scope.currentGrade[$(ele).attr("name")]);
							$(ele).val(tmpMoment.format("DD MMM YYYY"));
							$(ele).daterangepicker({
								format: "DD MMM YYYY",
								singleDatePicker: true,
								showDropdowns: true,
								startDate: tmpMoment,
							},
							function(start, end, label) {
								$(ele).attr("data-value", start.toDate().getTime());
							});
						} catch (e) {
							//
						}
					});
					$(".boolean-field").checkbox("uncheck");
					$(".boolean-field").each(function(idx, ele) {
						try {
							if ($scope.currentGrade[$(ele).attr("data-field-name")]) {
								$(ele).checkbox("check");
							}
						} catch (e) {
							//
						}
					});
					$("#submit_update_grade").removeClass("disabled");
					$("#reset_update_grade").removeClass("disabled");
				}
			}
		}
	};

	$scope.navUpdate = function(grade) {
		$state.go("update", {gradeid: grade._id});
	};

	$scope.submitUpdateGrade = function() {
		var parsleyHandle = $("#grades_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#submit_update_grade").addClass("loading disabled");
			$("#reset_update_grade").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			var _tmp = JSON.parse(JSON.stringify($scope.currentGrade));
			delete _tmp.isActive;
			var payload = {
				find: $("#grade_selection input").val(),
				update: _tmp,
			};
			dataFactory.post("update-grade.json", payload).then(function(data) {
				$("#submit_update_grade").removeClass("loading disabled");
				$("#reset_update_grade").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess("Grade updated successfully");
					var posInGrades = _.findIndex(grades, ["_id", $("#grade_selection input").val()]);
					if (posInGrades >= 0) {
						grades[posInGrades] = data.doc;
						$scope.grades = grades;
						$scope.currentGradeOrg = JSON.parse(JSON.stringify(data.doc));
					}
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_grade").removeClass("loading disabled");
				$("#reset_update_grade").removeClass("disabled");
			});
		}
	};

	$scope.resetUpdateGrade = function() {
		$scope.currentGrade = JSON.parse(JSON.stringify($scope.currentGradeOrg));
	};

	$scope.setEnableddisabled = function(grade) {
		if ($scope.gradesUnderProcessing[grade._id]) {
			return;
		}
		$scope.gradesUnderProcessing[grade._id] = true;
		$("." + grade._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + grade._id).checkbox();
		var payload = {
			find: grade._id,
			update: {isActive: (!grade.isActive)},
		};
		dataFactory.post("update-grade.json", payload).then(function(data) {
			if (data.status) {
				grade.isActive = data.doc.isActive;
				$timeout(function() {
					if (grade.isActive) {
						$("." + grade._id).checkbox("check");
					} else {
						$("." + grade._id).checkbox("uncheck");
					}
					$("." + grade._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + grade._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.gradesUnderProcessing[grade._id] = false;
		}, function() {
			$("." + grade._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.gradesUnderProcessing[grade._id] = false;
		});
	};

	$scope.submitCreateGrade = function() {
		var parsleyHandle = $("#grades_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_create_grade").addClass("loading disabled");
			$("#reset_create_grade").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("create-grade.json", $scope.currentGrade).then(function(data) {
				$("#submit_create_grade").removeClass("loading disabled");
				$("#reset_create_grade").addClass("disabled");
				if (data.status) {
					grades.push(data.doc);
					$scope.grades = grades;
					$scope.clearCreateGrade();
					dataFactory.toastSuccess("Grade created successfully");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_grade").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreateGrade = function() {
		$scope.currentGrade = {isActive: true};
	};

	$scope.submitCreateGradeBulk = function() {
		$("#submit_create_grade_bulk").addClass("loading");
		$.ajax({
			url: BASE_URL + "bulk-grade-create.json",
			data: window.fileUploadForm,
			cache: false,
			contentType: false,
			processData: false,
			type: "POST",
			dataType: "json",
			success: function(data) {
				if (data.status) {
					$scope.clearCreateGradeBulk();
					uploadResultArray = [];
					for (var loop = 0; loop < data.outcome.length; loop++) {
						uploadResultArray.push([data.outcome[loop]]);
					}
					if (data.docs) {
						grades = data.docs;
						$scope.grades = grades;
					}
					$(".upload-status-modal p span").html(data.successCount + "/" + data.outcome.length + "Grades created.");
					$(".upload-status-modal").modal({closable: false}).modal("show");
				} else {
					dataFactory.toastError(data.msg);
				}
				window.fileUploadForm = null;
				$("#submit_create_grade_bulk").removeClass("loading");
			},
			error: function() {
				$("#submit_create_grade_bulk").removeClass("loading");
				dataFactory.toastError("Currently we are unable to process your request, plesae try later.");
			},
		});
	};

	$scope.clearCreateGradeBulk = function() {
		$(".file-upload-tab .parsley-required").html("");
		$("#holder p label").show();
		$("#holder p a").html("");
		$("#holder p a").hide();
		$("#submit_create_grade_bulk").addClass("disabled");
		$("#reset_create_grade_bulk").addClass("disabled");
		window.fileUploadForm = null;
	};

	$scope.loadDateAndBooleanFields = function() {
		$(".datepicker").each(function(idx, ele) {
			try {
				$scope.currentGrade[$(ele).attr("name")] = Number($(ele).attr("data-value"));
			} catch (e) {
				//
			}
		});

		$(".boolean-field").each(function(idx, ele) {
			try {
				$scope.currentGrade[$(ele).attr("data-field-name")] = $(ele).hasClass("checked");
			} catch (e) {
				//
			}
		});

		$(".foreign-field").each(function(idx, ele) {
			try {
				$scope.currentGrade[$(ele).attr("data-field-name")] = $(ele).find("input").val();
			} catch (e) {
				//
			}
		});
	};

	$scope.getGradeSubTypeName = function(input) {
		if (!input) {
			return "";
		}
		if (input=="P") {
			return "Primary";
		} else if (input=="S") {
			return "Secondary";
		} else if (input=="T") {
			return "Tea Waste";
		} else if (input=="O") {
			return "Orthodox";
		} else {
			return "N/A";
		}
	};

	$scope.getGradeTypeName = function(input) {
		if (!input) {
			return "";
		}
		if (input=="B") {
			return "Broken";
		} else if (input=="F") {
			return "Fannings";
		} else if (input=="D") {
			return "Dust";
		} else if (input=="W") {
			return "Wholeleaf";
		} else if (input=="G") {
			return "Green Tea";
		} else {
			return "N/A";
		}
	};

	$scope.getCategoryName = function(input) {
		if (!input) {
			return "";
		}
		if (!categoryMap[input]) {
			var obj = _.find(categories, {_id: input});
			if (obj) {
				categoryMap[input] = obj;
			} else {
				categoryMap[input] = {name: "N/A", code: "N/A"};
			}
		}
		return categoryMap[input].name;
	};

	$scope.getSubcategoryName = function(input) {
		if (!input) {
			return "";
		}
		if (!categoryMap[input]) {
			var obj = _.find(categories, {_id: input});
			if (obj) {
				categoryMap[input] = obj;
			} else {
				categoryMap[input] = {name: "N/A", code: "N/A"};
			}
		}
		return categoryMap[input].name;
	};
}]);
var holder = null;

function processFileForUpload(e) {
	try {
		var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
		var file = files[0];
		if (file) {
			if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
				var extention = file.name.toUpperCase().split(".");
				extention = extention[extention.length - 1];
				$(".file-upload-tab .parsley-required").html("");
				if (file.size > (512 * 1024 * 1024)) {
					$(".file-upload-tab .parsley-required").html("Please use a file smaller than 512kB");
					return;
				}
				$(".file-upload-tab .parsley-required").html("");
				$("#holder p label").hide();
				$("#holder p a").html(file.name);
				$("#holder p a").show();
				$("#submit_create_grade_bulk").removeClass("disabled");
				$("#reset_create_grade_bulk").removeClass("disabled");
				window.fileUploadForm = new FormData();
				window.fileUploadForm.append("extention", extention);
				window.fileUploadForm.append("upload", file);
				document.getElementById("file_for_upload").value = "";
			} else {
				$(".file-upload-tab .parsley-required").html("Only <i>xls, xlsx, ods<i/> files are allowed.");
			}
		}
		return;
	} catch (err) {
		//
	}
}
var uploadResultArray = [[]];
// eslint-disable-next-line no-unused-vars
function downloadExcel() {
	$(".upload-status-modal .positive").click();
	var wb = new Workbook();
	var ws = sheet_from_array_of_arrays(uploadResultArray);
	wb.SheetNames.push("outcome");
	wb.Sheets["outcome"] = ws;
	var wbout = XLSX.write(wb, {
		bookType: "xlsx",
		bookSST: true,
		type: "binary",
	});
	saveAs(new Blob([s2ab(wbout)], {
		type: "application/octet-stream",
	}), "outcome_" + new Date().getTime() + ".xlsx");
}

