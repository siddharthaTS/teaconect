/* global allUsers userRoles masterPrivileges currentlyLoggedInUser uuid locations roleMap:true*/
/* eslint no-global-assign:0 */


app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: ["$rootScope", function($rootScope) {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			}],
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "userController",
				},
			},
			url: "/list",
		})
		.state("user-type", {
			onEnter: ["$rootScope", function($rootScope) {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-user-type").addClass("active");
			}],
			views: {
				"main": {
					templateUrl: "/user-type.tpl.html",
					controller: "userController",
				},
			},
			url: "/user-type",
		})
		.state("create", {
			onEnter: ["$rootScope", function($rootScope) {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			}],
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "userController",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: ["$rootScope", function($rootScope) {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			}],
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "userController",
				},
			},
			url: "/update?userid",
		})
		.state("update-privilege", {
			onEnter: ["$rootScope", function($rootScope) {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update-privilege").addClass("active");
			}],
			views: {
				"main": {
					templateUrl: "/update-privilege.tpl.html",
					controller: "userController",
				},
			},
			url: "/update-privilege?userid",
		})
		.state("change-password", {
			onEnter: ["$rootScope", function($rootScope) {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-change-password").addClass("active");
			}],
			views: {
				"main": {
					templateUrl: "/change-password.tpl.html",
					controller: "userController",
				},
			},
			url: "/change-password?userid",
		});
}]);
var currentState = null;
var currentParams = null;
var commandId = null;
var acknowledgementReceived = false;
// eslint-disable-next-line no-unused-vars
var locateUserTimeout;
var userLocation = null;
// eslint-disable-next-line no-unused-vars
var commandActivatedUser = null;

// var bookMap = {};

app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {

	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {

	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update", "update-privilege", "change-password"].indexOf(currentState.name) >= 0) {
			$("#user_selection").dropdown({forceSelection: false});
			$("#user_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-user-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.userid) {
					$("#user_selection").dropdown("set selected", currentParams.userid);
				}
			}, 300);
		}
		if (currentState && ["user-type", "update", "create"].indexOf(currentState.name) >= 0) {
			$("#user_type_selection").dropdown({forceSelection: false});
			$("#user_type_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-user-type-change").click();
				}, 200);
			});
		}
		if (currentState && ["user-type", "update-privilege"].indexOf(currentState.name) >= 0) {
			setTimeout(function() {
				$(".privilege-container .ui.checkbox").checkbox({
					onChecked: function() {
						var classes = $(this).parent().attr("class").split(" ");
						if (classes.indexOf("create") >= 0 || classes.indexOf("update") >= 0) {
							$(this).parent().parent().parent().find(".ui.checkbox.view").checkbox("check");
						}
					},
					onUnchecked: function() {
						var classes = $(this).parent().attr("class").split(" ");
						if (classes.indexOf("view") >= 0) {
							$(this).parent().parent().parent().find(".ui.checkbox").checkbox("uncheck");
						}
					},
				});
			}, 300);
		}
		if (currentState && ["update", "create"].indexOf(currentState.name) >= 0) {
			$("#parent_user_selection").dropdown({forceSelection: false});
			$("#parent_user_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-parent-user-change").click();
				}, 200);
			});
		}
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$(".password-only-for-create input").removeAttr("data-parsley-required");
			$(".password-only-for-create").hide();
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$(".create-users-tabs .item").tab();
			holder = document.getElementById("holder");
			holder.ondragover = function() {
				$(this).addClass("div_drag_hover");
				return false;
			};
			holder.ondragend = function() {
				$(this).removeClass("div_drag_hover");
				return false;
			};
			holder.ondrop = function(e) {
				$(this).removeClass("div_drag_hover");
				e.preventDefault();
				processFileForUpload(e);
			};
		}

		if (currentState && ["list"].indexOf(currentState.name) >= 0) {
			$("#book_selection").dropdown({forceSelection: false});
		}
	});
}]);

app.controller("userController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	if (currentState && ["user-location"].indexOf(currentState.name) >= 0) {
		if (!userLocation) {
			$state.go("list");
			return;
		}
	}
	if (!locations) {
		locations = [];
	}
	$scope.locations = locations;
	$scope.users = allUsers;
	// $scope.userRoles = userRoles;
	$scope.userTypes = userRoles;
	$scope.currentUser = null;
	$scope.currentUserOriginal = null;
	$scope.usersUnderProcessing = {};
	$scope.masterPrivileges = masterPrivileges;
	$scope.loginIdValidated = false;
	$scope.emailIdValidated = false;
	// $rootScope.books = [];

	$scope.userChanged = function() {
		var userId = $("#user_selection input").val();
		var posInUsers = -1;
		if (userId.length > 1) {
			if ($state.current.name == "update-privilege") {
				posInUsers = _.findIndex($scope.users, ["_id", userId]);
				var privileges = null;
				if (posInUsers > -1) {
					privileges = $scope.users[posInUsers].privileges;
					if ($scope.users[posInUsers]._id != $scope.users[posInUsers].parentUserId) {
						$("#update_user_privilege").removeClass("disabled");
						$("#reset_user_privilege").removeClass("disabled");
					}
				}
				setupPrivilegesAsPerValue(privileges);
			} else if ($state.current.name == "update") {
				$("#submit_update_user").removeClass("disabled");
				$scope.loginIdValidated = true;
				$scope.emailIdValidated = true;
				$("#reset_update_user").removeClass("disabled");
				posInUsers = _.findIndex($scope.users, ["_id", userId]);
				if (posInUsers > -1) {
					var tmp = JSON.parse(JSON.stringify($scope.users[posInUsers]));
					delete tmp.$$hashKey;
					$scope.currentUserOriginal = JSON.parse(JSON.stringify(tmp));
					$scope.currentUser = tmp;
					$("#user_type_selection").dropdown("set selected", $scope.currentUser.userType);
					$timeout(function() {
						$("#parent_user_selection").dropdown("set selected", $scope.currentUser.parentUserId);
					}, 200);
					if ($scope.users[posInUsers]._id == $scope.users[posInUsers].parentUserId) {
						$("#user_type_selection").addClass("disabled");
						$("#parent_user_selection").addClass("disabled");
					} else {
						$("#user_type_selection").removeClass("disabled");
						$("#parent_user_selection").removeClass("disabled");
					}
				}
			} else if ($state.current.name == "change-password") {
				$("#submit_change_password").removeClass("disabled");
			}
		}
	};

	$scope.submitUpdatePassword = function() {
		var parsleyHandle = $("#change_password_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#submit_change_password").addClass("loading disabled");
			$("#reset_change_password").addClass("disabled");
			var payload = {
				userid: $("#user_selection input").val(),
				password: $("#change_password").val(),
			};
			dataFactory.post("update-password-admin.json", payload).then(function(data) {
				$("#submit_change_password").removeClass("loading disabled");
				$("#reset_change_password").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess(data.msg);
					$scope.clearPassword();
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_change_password").removeClass("loading disabled");
				$("#reset_change_password").removeClass("disabled");
			});
		}
	};

	$scope.clearPassword = function() {
		$("#change_password").val("");
		$("#repeat_password").val("");
	};

	$scope.setEnableddisabled = function(user) {
		if (user._id == user.parentUserId) {
			dataFactory.toastError("Can not deactivate primary admin.");
			return;
		}
		if (user._id == currentlyLoggedInUser) {
			dataFactory.toastError("Can not deactivate self.");
			return;
		}
		if ($scope.usersUnderProcessing[user._id]) {
			return;
		}
		$scope.usersUnderProcessing[user._id] = true;
		$("." + user._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + user._id).checkbox();
		var payload = {
			userid: user._id,
			update: {$set: {isActive: (!user.isActive)}},
		};
		dataFactory.post("update-user.json", payload).then(function(data) {
			if (data.status) {
				user.isActive = data.doc.isActive;
				$timeout(function() {
					if (user.isActive) {
						$("." + user._id).checkbox("check");
					} else {
						$("." + user._id).checkbox("uncheck");
					}
					$("." + user._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + user._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.usersUnderProcessing[user._id] = false;
		}, function() {
			$("." + user._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.usersUnderProcessing[user._id] = false;
		});
	};

	$scope.parentUserChanged = function() {
		var parentUser = $("#parent_user_selection input").val();
		if (parentUser.trim().length > 0) {
			$(".parsley-error-custom.create-user-parent").html("");
		}
	};

	$scope.resetUserPrivilege = function() {
		var userId = $("#user_selection input").val();
		var posInUsers = _.findIndex($scope.users, ["_id", userId]);
		var privileges = null;
		if (posInUsers > -1) {
			privileges = $scope.users[posInUsers].privileges;
		}
		setupPrivilegesAsPerValue(privileges);
	};

	$scope.updateUserPrivilege = function() {
		var privilege = getPrivilegesAsPerPage();
		var payload = {userid: $("#user_selection input").val(), update: {$set: {privileges: privilege}}};
		$("#update_user_privilege").addClass("loading disabled");
		dataFactory.post("update-user.json", payload).then(function(data) {
			$("#update_user_privilege").removeClass("loading disabled");
			if (data.status) {
				var userId = $("#user_selection input").val();
				var posInUsers = _.findIndex($scope.users, ["_id", userId]);
				if (posInUsers > -1) {
					$scope.users[posInUsers] = data.doc;
				}
				posInUsers = _.findIndex(allUsers, ["_id", userId]);
				if (posInUsers > -1) {
					allUsers[posInUsers] = data.doc;
				}
				dataFactory.toastSuccess(data.msg);
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#update_user_privilege").removeClass("loading disabled");
		});
	};

	$scope.validateMailId = function() {
		if ($scope.currentUserOriginal && $scope.currentUserOriginal.userEmail == $scope.currentUser.userEmail) {
			$scope.validateMailIdSuccess();
			return;
		}
		$(".parsley-error-custom.create-user-emailId").html("");
		$(".create-user-emailId").parent().parent().find("input").parsley().validate();
		var parsleyHandle = $(".create-user-emailId").parent().parent().find("input").parsley();
		if (parsleyHandle.isValid()) {
			$(".create-user-emailId").parent().parent().find(".ui.icon").addClass("loading disabled");
			$(".create-user-emailId").parent().parent().find("i").show();
			dataFactory.post("unique-mailid.json", {
				newEmailId: $scope.currentUser.userEmail,
				currentEmailId: null,
			}).then(function(data) {
				if (data.status) {
					$scope.validateMailIdSuccess();
				} else {
					$scope.validateMailIdError(data.msg);
				}
				$(".create-user-emailId").parent().parent().find(".ui.icon").removeClass("loading disabled");
			}, function() {
				$(".create-company-emailId").parent().parent().find(".ui.icon").removeClass("loading disabled");
				$scope.validateMailIdError("This email id is already registered.");
			});
		} else {
			$scope.emailIdValidated = false;
			return false;
		}
	};

	$scope.validateLoginId = function() {
		if ($scope.currentUserOriginal && $scope.currentUserOriginal.loginId == $scope.currentUser.loginId) {
			$scope.validateLoginIdSuccess();
			return;
		}
		$(".parsley-error-custom.create-user-loginid").html("");
		$(".create-user-loginid").parent().parent().find("input").parsley().validate();
		var parsleyHandle = $(".create-user-loginid").parent().parent().find("input").parsley();
		if (parsleyHandle.isValid()) {
			$(".create-user-loginid").parent().parent().find(".ui.icon").addClass("loading disabled");
			$(".create-user-loginid").parent().parent().find("i").show();
			dataFactory.post("unique-loginid.json", {
				newLoginId: $scope.currentUser.loginId,
				currentLoginId: null,
			}).then(function(data) {
				if (data.status) {
					$scope.validateLoginIdSuccess();
				} else {
					$scope.validateLoginIdError(data.msg);
				}
				$(".create-user-loginid").parent().parent().find(".ui.icon").removeClass("loading disabled");
			}, function() {
				$(".create-company-loginid").parent().parent().find(".ui.icon").removeClass("loading disabled");
				$scope.validateLoginIdError("This login id is already taken.");
			});
		} else {
			$scope.emailIdValidated = false;
			return false;
		}
	};

	$scope.validateMailIdSuccess = function() {
		$(".create-user-emailId").parent().parent().find("i").show();
		$scope.emailIdValidated = true;
		if ($scope.loginIdValidated) {
			$("#submit_update_user").removeClass("disabled");
			$("#submit_create_user").removeClass("disabled");
		}
		$(".parsley-error-custom.create-user-emailId").html("");
		if (!$(".create-user-emailId").parent().parent().find("i").hasClass("checkmark")) {
			$(".create-user-emailId").parent().parent().find("i").addClass("checkmark");
			$(".create-user-emailId").parent().parent().find("i").addClass("stat-ok");
		}
		if ($(".create-user-emailId").parent().parent().find("i").hasClass("remove")) {
			$(".create-user-emailId").parent().parent().find("i").removeClass("remove");
			$(".create-user-emailId").parent().parent().find("i").removeClass("stat-nok");
		}
	};

	$scope.validateMailIdError = function(msg) {
		$scope.emailIdValidated = false;
		$("#submit_update_user").addClass("disabled");
		$("#submit_create_user").addClass("disabled");
		$(".parsley-error-custom.create-user-emailId").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">" + msg + "</li></ul>");
		if ($(".create-user-emailId").parent().parent().find("i").hasClass("checkmark")) {
			$(".create-user-emailId").parent().parent().find("i").removeClass("checkmark");
			$(".create-user-emailId").parent().parent().find("i").removeClass("stat-ok");
		}
		if (!$(".create-user-emailId").parent().parent().find("i").hasClass("remove")) {
			$(".create-user-emailId").parent().parent().find("i").addClass("remove");
			$(".create-user-emailId").parent().parent().find("i").addClass("stat-nok");
		}
	};

	$scope.validateLoginIdSuccess = function() {
		$(".create-user-loginid").parent().parent().find("i").show();
		$scope.loginIdValidated = true;
		if ($scope.emailIdValidated) {
			$("#submit_update_user").removeClass("disabled");
			$("#submit_create_user").removeClass("disabled");
		}
		$(".parsley-error-custom.create-user-loginid").html("");
		if (!$(".create-user-loginid").parent().parent().find("i").hasClass("checkmark")) {
			$(".create-user-loginid").parent().parent().find("i").addClass("checkmark");
			$(".create-user-loginid").parent().parent().find("i").addClass("stat-ok");
		}
		if ($(".create-user-loginid").parent().parent().find("i").hasClass("remove")) {
			$(".create-user-loginid").parent().parent().find("i").removeClass("remove");
			$(".create-user-loginid").parent().parent().find("i").removeClass("stat-nok");
		}
	};

	$scope.validateLoginIdError = function(msg) {
		$scope.loginIdValidated = false;
		$("#submit_update_user").addClass("disabled");
		$("#submit_create_user").addClass("disabled");
		$(".parsley-error-custom.create-user-loginid").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">" + msg + "</li></ul>");
		if ($(".create-user-loginid").parent().parent().find("i").hasClass("checkmark")) {
			$(".create-user-loginid").parent().parent().find("i").removeClass("checkmark");
			$(".create-user-loginid").parent().parent().find("i").removeClass("stat-ok");
		}
		if (!$(".create-user-loginid").parent().parent().find("i").hasClass("remove")) {
			$(".create-user-loginid").parent().parent().find("i").addClass("remove");
			$(".create-user-loginid").parent().parent().find("i").addClass("stat-nok");
		}
	};

	$scope.submitUpdateUser = function() {
		var parsleyHandle = $("#create_user_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if ($("#user_type_selection input").val().trim().length == 0) {
			$(".parsley-error-custom.create-user-type").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">THIS VALUE IS REQUIRED.</li></ul>");
			additionalValidations = false;
		}
		/* if ($("#parent_user_selection input").val().trim().length == 0) {
			$(".parsley-error-custom.create-user-parent").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">THIS VALUE IS REQUIRED.</li></ul>");
			additionalValidations = false;
		} */
		if (parsleyHandle.isValid() && additionalValidations) {
			var payload = {
				userid: $("#user_selection input").val(), update: {
					$set: {
						userName: $scope.currentUser.userName,
						code: $scope.currentUser.code,
						userEmail: $scope.currentUser.userEmail,
						contactNumber: $scope.currentUser.contactNumber,
						userType: $("#user_type_selection input").val(),
						loginId: $scope.currentUser.loginId,
						// parentUserId: $("#parent_user_selection input").val(),
						locationId: $scope.currentUser.locationId,
					},
				},
			};
			$("#submit_update_user").addClass("loading disabled");
			dataFactory.post("update-user.json", payload).then(function(data) {
				$("#submit_update_user").removeClass("loading disabled");
				if (data.status) {
					var userId = $("#user_selection input").val();
					var posInUsers = _.findIndex($scope.users, ["_id", userId]);
					if (posInUsers > -1) {
						$scope.users[posInUsers] = data.doc;
					}
					posInUsers = _.findIndex(allUsers, ["_id", userId]);
					if (posInUsers > -1) {
						allUsers[posInUsers] = data.doc;
					}
					dataFactory.toastSuccess(data.msg);
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_user").removeClass("loading disabled");
			});
		}
	};

	$scope.clearUpdateUser = function() {
		$scope.userChanged();
		$("#submit_update_user").removeClass("disabled");
		$(".parsley-error-custom.create-user-loginid").html("");
		$(".create-user-loginid").parent().parent().find("i").hide();
		$(".parsley-error-custom.create-user-emailId").html("");
		$(".create-user-emailId").parent().parent().find("i").hide();
	};

	$scope.submitCreateUser = function() {
		var parsleyHandle = $("#create_user_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if ($("#user_type_selection input").val().trim().length == 0) {
			$(".parsley-error-custom.create-user-type").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">THIS VALUE IS REQUIRED.</li></ul>");
			additionalValidations = false;
		}
		/* if ($("#parent_user_selection input").val().trim().length == 0) {
			$(".parsley-error-custom.create-user-parent").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">THIS VALUE IS REQUIRED.</li></ul>");
			additionalValidations = false;
		} */
		if (parsleyHandle.isValid() && additionalValidations) {
			if ($("#user_type_selection input").val().trim().length == 0) {
				$(".parsley-error-custom.create-user-type").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">THIS VALUE IS REQUIRED.</li></ul>");
				return;
			}
			/* if ($("#parent_user_selection input").val().trim().length == 0) {
				$(".parsley-error-custom.create-user-parent").html("<ul class=\"parsley-errors-list filled\"><li class=\"parsley-required\">THIS VALUE IS REQUIRED.</li></ul>");
				return;
			} */
			var privileges = roleMap[$("#user_type_selection input").val()];
			if (!privileges) {
				privileges = {};
			}
			/* var posInRoles = _.findIndex($scope.userRoles, ["name", $("#user_type_selection input").val()]);
			var privileges = null;
			if (posInRoles > -1) {
				privileges = $scope.userRoles[posInRoles].privileges;
			} else {
				return;
			} */
			if (!$scope.currentUser.contactNumber) {
				$scope.currentUser.contactNumber = "";
			}
			var payload = {
				userName: $scope.currentUser.userName,
				code: $scope.currentUser.code,
				userEmail: $scope.currentUser.userEmail,
				contactNumber: $scope.currentUser.contactNumber,
				userType: $("#user_type_selection input").val(),
				privileges: privileges,
				loginId: $scope.currentUser.loginId,
				parentUserId: $scope.users[0]._id,
				password: $scope.currentUser.password,
				locationId: $scope.currentUser.locationId,
			};
			$("#submit_create_user").addClass("loading disabled");
			dataFactory.post("create-user.json", payload).then(function(data) {
				$("#submit_create_user").removeClass("loading disabled");
				if (data.status) {
					allUsers.push(data.doc);
					$scope.users = allUsers;
					$scope.clearCreateUser();
					dataFactory.toastSuccess("User Created");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_user").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreateUser = function() {
		$scope.currentUser = null;
		$("#user_type_selection").dropdown("restore defaults");
		$("#parent_user_selection").dropdown("restore defaults");
		$("#submit_create_user").addClass("disabled");
		$(".parsley-error-custom.create-user-loginid").html("");
		$(".create-user-loginid").parent().parent().find("i").hide();
		$(".parsley-error-custom.create-user-emailId").html("");
		$(".create-user-emailId").parent().parent().find("i").hide();
	};

	$scope.notifyUser = function(user) {
		$(".notify-user-modal").modal({
			closable: false,
			onApprove: function() {
				var parsleyHandle = $("#notify_user_form").parsley();
				parsleyHandle.validate();
				if (parsleyHandle.isValid()) {
					$(".notify-user-modal .negative").addClass("disabled");
					$(".notify-user-modal .positive").addClass("disabled loading");
					$("#proxy_notify_user").click();
				}
				return false;
			},
			onShow: function() {
				$(".notify-user-modal .header").html("Notify " + user.userName);
				$(".notify-user-modal").attr("data-target", user._id);
			},
		}).modal("show");
	};

	$scope.notifyUserAction = function() {
		var userId = $(".notify-user-modal").attr("data-target");
		var payload = {
			userid: userId,
			heading: $("#notify_user_form input").val(),
			msgBody: $("#notify_user_form textarea").val(),
		};
		dataFactory.post("send-notification-to-user.json", payload).then(function(data) {
			$("#notify_user_form input").val("");
			$("#notify_user_form textarea").val("");
			$(".notify-user-modal .negative").removeClass("disabled");
			$(".notify-user-modal .positive").removeClass("disabled loading");
			$(".notify-user-modal .negative").click();
			if (data.status) {
				dataFactory.toastSuccess(data.msg);
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			$("#notify_user_form input").val("");
			$("#notify_user_form textarea").val("");
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$(".notify-user-modal .negative").removeClass("disabled");
			$(".notify-user-modal .positive").removeClass("disabled loading");
			$(".notify-user-modal .negative").click();
		});
	};

	$scope.locateUser = function(user) {
		commandActivatedUser = user;
		var userId = user._id;
		userLocation = null;
		commandId = uuid.v1();
		var payload = {
			userid: userId,
			command: "LOCATION",
			commandId: commandId,
		};
		acknowledgementReceived = false;
		$("#locate-user-modal .msg").html("Connecting to device...");
		$("#locate-user-modal").modal("setting", "closable", false).modal("show");
		dataFactory.post("command-request.json", payload).then(function(data) {
			if (data.status == 0) {
				// dataFactory.toastSuccess(data.msg);
				locateUserTimeout = setTimeout(function() {
					if (!acknowledgementReceived) {
						$("#locate-user-modal").modal("hide");
						dataFactory.toastError("We are unable to locate the user.");
					}
				}, 60000);
			} else {
				$("#locate-user-modal").modal("hide");
				dataFactory.toastError(data.msg);
			}
		}, function() {
			$("#locate-user-modal").modal("hide");
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
		});
	};

	$scope.submitCreateUserBulk = function() {
		$("#submit_create_user_bulk").addClass("loading");
		$.ajax({
			url: BASE_URL + "bulk-user-create.json",
			data: window.fileUploadForm,
			cache: false,
			contentType: false,
			processData: false,
			type: "POST",
			dataType: "json",
			success: function(data) {
				if (data.status) {
					// dataFactory.toastSuccess(data.msg);
					uploadResultArray = [];
					for (var loop = 0; loop < data.outcome.length; loop++) {
						uploadResultArray.push([data.outcome[loop]]);
					}
					if (data.docs) {
						allUsers = data.docs;
						$scope.users = allUsers;
					}
					$(".upload-status-modal p span").html(data.successCount + "/" + data.outcome.length + "users created, ");
					$(".upload-status-modal").modal({closable: false}).modal("show");
				} else {
					dataFactory.toastError(data.msg);
				}
				$scope.clearCreateUserBulk();
				window.fileUploadForm = null;
				$("#submit_create_user_bulk").removeClass("loading");
			},
			error: function() {
				$scope.clearCreateUserBulk();
				$("#submit_create_user_bulk").removeClass("loading");
				dataFactory.toastError("Currently we are unable to process your request, plesae try later.");
			},
		});
	};

	$scope.clearCreateUserBulk = function() {
		$(".file-upload-tab .parsley-required").html("");
		$("#holder p label").show();
		$("#holder p a").html("");
		$("#holder p a").hide();
		$("#submit_create_user_bulk").addClass("disabled");
		$("#reset_create_user_bulk").addClass("disabled");
		window.fileUploadForm = null;
	};

	$scope.assignBook = function(user) {
		$(".assign-books-modal").modal({
			closable: false,
			onApprove: function() {
				var bookIds = $("#book_selection input").val();
				if (bookIds.length < 1) {
					dataFactory.toastError("Please select book(s).");
					return false;
				}

				$(".assign-books-modal .positive").addClass("loading disabled");
				$(".assign-books-modal .negative").addClass("disabled");
				var payload = {userid: user._id, update: {$set: {books: bookIds.split(",")}}};
				dataFactory.post("update-user.json", payload).then(function(data) {
					if (data.status) {
						var userId = user._id;
						var posInUsers = _.findIndex($scope.users, ["_id", userId]);
						if (posInUsers > -1) {
							$scope.users[posInUsers] = data.doc;
						}
						posInUsers = _.findIndex(allUsers, ["_id", userId]);
						if (posInUsers > -1) {
							allUsers[posInUsers] = data.doc;
						}
						dataFactory.toastSuccess(data.msg);
						$(".assign-books-modal .positive").removeClass("loading disabled");
						$(".assign-books-modal .negative").removeClass("disabled");
						$(".assign-books-modal .negative").click();
					} else {
						dataFactory.toastError(data.msg);
						$(".assign-books-modal .positive").removeClass("loading disabled");
						$(".assign-books-modal .negative").removeClass("disabled");
					}
				}, function() {
					dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
					$(".assign-books-modal .positive").removeClass("loading disabled");
					$(".assign-books-modal .negative").removeClass("disabled");
				});
				return false;
			},
			onShow: function() {
				$("#book_selection").dropdown("restore defaults");
				$(".assign-books-modal .button").removeClass("loading disabled");
			},
		}).modal("show");
	};
}]);

var holder = null;

function setupPrivilegesAsPerValue(privileges) {
	$(".privilege-container .ui.checkbox").checkbox("uncheck");
	if (privileges) {
		$.each(privileges, function(key, obj) {
			if (obj) {
				if (obj.childNodes) {
					$.each(obj.childNodes, function(innerkey, innerObj) {
						$(innerObj.access).each(function(index, name) {
							$(".privilege-container .ui.checkbox." + innerkey + "." + name).checkbox("check");
						});
					});
				} else {
					$(obj.access).each(function(index, name) {
						$(".privilege-container .ui.checkbox." + key + "." + name).checkbox("check");
					});
				}
			}
		});
	}
}

function getPrivilegesAsPerPage() {
	var privileges = masterPrivileges;
	var currentPrivileges = {};
	if (privileges) {
		$.each(privileges, function(key, obj) {
			if (obj.childNodes) {
				$.each(obj.childNodes, function(innerkey, innerObj) {
					$(innerObj.access).each(function(index, name) {
						if ($(".privilege-container .ui.checkbox." + innerkey + "." + name).hasClass("checked")) {
							if (!currentPrivileges[key]) {
								currentPrivileges[key] = {
									display: obj.display,
									access: ["view"],
									childNodes: {},
								};
								/* currentPrivileges[key].childNodes[innerkey] = {
                                    display: innerObj.display,
                                    page: innerObj.page,
                                    path: innerObj.path,
                                    access: [],
                                    childNodes: null
                                }*/
							}
							if (!currentPrivileges[key].childNodes) {
								currentPrivileges[key].childNodes[innerkey] = {
									display: innerObj.display,
									page: innerObj.page,
									path: innerObj.path,
									access: [],
									childNodes: null,
								};
							}
							if (!currentPrivileges[key].childNodes[innerkey]) {
								currentPrivileges[key].childNodes[innerkey] = {
									display: innerObj.display,
									page: innerObj.page,
									path: innerObj.path,
									access: [],
									childNodes: null,
								};
							}
							// console.log(currentPrivileges)
							currentPrivileges[key].childNodes[innerkey].access.push(name);
						}
					});
				});
			} else {
				$(obj.access).each(function(index, name) {
					if ($(".privilege-container .ui.checkbox." + key + "." + name).hasClass("checked")) {
						if (!currentPrivileges[key]) {
							currentPrivileges[key] = {
								display: obj.display,
								page: obj.page,
								path: obj.path,
								access: [],
								childNodes: null,
							};
						}
						currentPrivileges[key].access.push(name);
					}
				});
			}
		});
	}
	return currentPrivileges;
}


// eslint-disable-next-line no-unused-vars
function deleteOk() {
	var target = $(".confirm-delete-modal").attr("data-target");
	$("#" + target).click();
}

function processFileForUpload(e) {
	try {
		var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
		var file = files[0];
		if (file) {
			if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
				var extention = file.name.toUpperCase().split(".");
				extention = extention[extention.length - 1];
				$(".file-upload-tab .parsley-required").html("");
				if (file.size > (512 * 1024 * 1024)) {
					$(".file-upload-tab .parsley-required").html("Please use a file smaller than 512kB");
					return;
				}
				$(".file-upload-tab .parsley-required").html("");
				$("#holder p label").hide();
				$("#holder p a").html(file.name);
				$("#holder p a").show();
				$("#submit_create_user_bulk").removeClass("disabled");
				$("#reset_create_user_bulk").removeClass("disabled");
				window.fileUploadForm = new FormData();
				window.fileUploadForm.append("extention", extention);
				window.fileUploadForm.append("upload", file);
				document.getElementById("file_for_upload").value = "";
			} else {
				$(".file-upload-tab .parsley-required").html("Only <i>xls, xlsx, ods<i/> files are allowed.");
			}
		}
		return;
	} catch (err) {
		//
	}
}

var uploadResultArray = [[]];

// eslint-disable-next-line no-unused-vars
function downloadExcel() {
	$(".upload-status-modal .positive").click();
	var wb = new Workbook(); var ws = sheet_from_array_of_arrays(uploadResultArray);
	wb.SheetNames.push("outcome");
	wb.Sheets["outcome"] = ws;
	var wbout = XLSX.write(wb, {
		bookType: "xlsx",
		bookSST: true,
		type: "binary",
	});
	saveAs(new Blob([s2ab(wbout)], {
		type: "application/octet-stream",
	}), "outcome_" + new Date().getTime() + ".xlsx");
}
