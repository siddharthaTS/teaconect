
/* global grades auctions marks users locations:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "invoiceController",
				},
			},
			url: "/list",
		})
		.state("manage", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-manage").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/manage.tpl.html",
					controller: "invoiceController",
				},
			},
			url: "/manage?auctionid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["manage"].indexOf(currentState.name) >= 0) {
			$("#submit_update").hide();
			setTimeout(function() {
				if (currentParams.auctionid) {
					$("#proxy_auction_selection").attr("data-auctionid", currentParams.auctionid);
					$("#proxy_auction_selection").click();
				}
			}, 300);
		}
		/* else if (currentState && ["details"].indexOf(currentState.name) >= 0) {
			$("#submit_create").hide();
			setTimeout(function() {
				if (currentParams.musterid) {
					$("#proxy_muster_selection").attr("data-musterid", currentParams.musterid);
					$("#proxy_muster_selection").click();
				}
			}, 300);
		} */
	});
}]);

var gradeMap = {};
var gradeReverseMap = {};
var locationMap = {};
var markMap = {};
var markReverseMap = {};
var userMap = {};
var loop=0;
var length = 0;

for (loop=0, length=marks.length; loop<length; loop++) {
	markMap[marks[loop]._id] = loop;
	markReverseMap[marks[loop].code] = marks[loop]._id;
}

for (loop=0, length=grades.length; loop<length; loop++) {
	gradeMap[grades[loop]._id] = loop;
	gradeReverseMap[grades[loop].code] = grades[loop]._id;
}

for (loop=0, length=locations.length; loop<length; loop++) {
	locationMap[locations[loop]._id] = loop;
}

for (loop=0, length=auctions.length; loop<length; loop++) {
	auctions[loop].tastingDate = new Date(auctions[loop].tastingDate);
}
for (loop=0, length=users.length; loop<length; loop++) {
	userMap[users[loop]._id] = loop;
}

var _dt = new Date();
var _season = _dt.getFullYear();
if (_dt.getMonth<3) {
	_season--;
}
var selection = {locationId: "", status: "PENDING", season: _season};
app.controller("invoiceController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.grades = grades;
	$scope.auctions = auctions;
	$scope.locations = locations;
	$scope.marks = marks;
	$scope.selection = selection;
	$scope.currentRecord = {};
	$scope.currentPageNumberInList = 1;
	$scope.users = users;

	$scope.mode = "CREATE";

	$scope.records = [];

	var editPos = -1;
	var auctionId;

	$scope.assignedConfig = {
		valueField: "_id",
		labelField: "userName",
		searchField: ["userName"],
		maxOptions: 25,
		create: false,
	};

	$scope.navManage = function(obj) {
		$state.go("manage", {auctionid: obj._id});
	};

	$scope.addCurrentRecord = function() {
		if (!$scope.currentRecord.invNo) {
			dataFactory.toastError("Invoice Number must be entered");
			return;
		}
		if (!$scope.currentRecord.lotNum) {
			dataFactory.toastError("Lot Number must be entered");
			return;
		}
		if (!$scope.currentRecord.gradeId) {
			dataFactory.toastError("Grade must be selected");
			return;
		}
		if (!$scope.currentRecord.markId) {
			dataFactory.toastError("Mark must be selected");
			return;
		}
		if (!$scope.currentRecord.season) {
			dataFactory.toastError("Manufacture season must be entered");
			return;
		}
		if (!$scope.currentRecord.noOfPkg) {
			dataFactory.toastError("Number of Packages must be entered");
			return;
		}
		/* if (!$scope.currentRecord.avlKg) {
			dataFactory.toastError("Gross Kg must be entered");
			return;
		} */
		var _rec = {
			invNo: $scope.currentRecord.invNo.toUpperCase(),
			lotNum: "" + $scope.currentRecord.lotNum,
			markId: "" + $scope.currentRecord.markId,
			gradeId: "" + $scope.currentRecord.gradeId,
			season: $scope.currentRecord.season,
			// mfgDate: $scope.currentRecord.mfgDate.getTime(),
			// mfgDateStr: date2String($scope.currentRecord.mfgDate),
			noOfPkg: 0 + $scope.currentRecord.noOfPkg,
			// avlKg: 0 + $scope.currentRecord.avlKg,
		};
		if ($scope.currentRecord.netPerPkg) {
			_rec.netPerPkg = 0 + $scope.currentRecord.netPerPkg;
		}
		if (editPos == -1) {
			$scope.records.push(_rec);
		} else {
			$scope.records[editPos] = _rec;
		}
		$scope.currentRecord.invNo = "";
		$scope.currentRecord.lotNum = "";
		$("#current-lot-number").focus();
		editPos = -1;
	};

	$scope.pageChangeHandler=function(pos) {
		$scope.currentPageNumberInList = pos;
	};

	$scope.getActualPos = function(pos) {
		return (($scope.currentPageNumberInList - 1) * 40) + pos;
	};

	$scope.getGradeCode = function(input) {
		if (!input) {
			return "";
		}
		var pos = gradeMap[input];
		if (pos==null) {
			return "n/a";
		}
		return $scope.grades[pos].code;
	};

	$scope.getMarkCode = function(input) {
		if (!input) {
			return "";
		}
		var pos = markMap[input];
		if (pos==null) {
			return "n/a";
		}
		return $scope.marks[pos].name;
	};

	$scope.removeInvoice = function(pos) {
		pos = $scope.getActualPos(pos);
		$scope.records.splice(pos, 1);
	};

	$scope.editInvoice = function(pos) {
		pos = $scope.getActualPos(pos);
		editPos = pos;
		var ref = $scope.records[editPos];
		$scope.currentRecord.invNo = ref.invNo.toUpperCase();
		$scope.currentRecord.lotNum = "" + ref.lotNum.toUpperCase();
		$scope.currentRecord.markId = ref.markId + "";
		$scope.currentRecord.gradeId = ref.gradeId + "";
		$scope.currentRecord.season = ref.season;
		$scope.currentRecord.noOfPkg = ref.noOfPkg + 0;
		$scope.currentRecord.netPerPkg = ref.netPerPkg + 0;
	};

	$scope.processFileForUpload = function(e) {
		$("#loader").show();
		try {
			e.stopPropagation();
			e.preventDefault();
			var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
			var file = files[0];
			if (file) {
				if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						var workbook = XLSX.read(data, {type: "binary"});
						var first_sheet_name = workbook.SheetNames[0];
						var worksheet = workbook.Sheets[first_sheet_name];
						var requiredJson = XLSX.utils.sheet_to_json(worksheet);
						$scope.appendRecords(requiredJson);
					};
					reader.readAsBinaryString(file);
				}
				document.getElementById("file_for_upload").value = "";
			}
			return;
		} catch (err) {
			$("#loader").hide();
		}
	};

	$scope.appendRecords = function(docs) {
		if ((!docs) || (docs.length==0)) {
			$("#loader").hide();
		}
		for (var loop=0, length = docs.length; loop<length; loop++) {
			try {
				var invNum = docs[loop]["Inv/Batch"];
				if (!invNum) {
					continue;
				}
				invNum = ""+invNum;
				var lotNum = docs[loop]["Lot No"];
				if (!lotNum) {
					continue;
				}
				lotNum = ""+lotNum;
				var mark = docs[loop]["Garden"];
				var markId = null;
				if (mark) {
					mark = ""+mark;
					mark = mark.trim().toUpperCase();
					markId = markReverseMap[mark];
					if (!markId) {
						continue;
					}
				}
				var grade = docs[loop].Grade;
				var gradeId = null;
				if (grade) {
					grade = ""+grade;
					grade = grade.trim().toUpperCase();
					gradeId = gradeReverseMap[grade];
					if (!gradeId) {
						continue;
					}
				}
				var season = docs[loop]["Season"];
				if (isNaN(season)) {
					continue;
				}
				// mfgDate = excelDateToJSDate(mfgDate);
				var noOfPkg = docs[loop]["PKGS"];
				if (isNaN(noOfPkg)) {
					continue;
				}
				// var avlKg = docs[loop]["G Wt(*)"];
				// if ((!avlKg) || isNaN(avlKg)) {
				//	continue;
				// }
				var netPerPkg = null;
				var tmp = docs[loop].KGS;
				if (tmp && (tmp!="null") && (tmp != "undefined")) {
					if (!isNaN(tmp)) {
						netPerPkg = Number(tmp)/Number(noOfPkg);
					}
				}
				var _rec = {
					invNo: invNum.toUpperCase(),
					lotNum: lotNum.toUpperCase(),
					markId: markId,
					gradeId: gradeId,
					season: Number(season),
					// mfgDateStr: date2String(mfgDate),
					noOfPkg: Number(noOfPkg),
					// avlKg: Number(avlKg),
				};
				if (netPerPkg) {
					_rec.netPerPkg = netPerPkg;
				}
				$scope.records.push(_rec);
			} catch (err) {
				//
			}
		}
		try {
			$scope.$apply();
		} catch (err) {
			//
		}
		$("#loader").hide();
	};

	$scope.processFileForUploadPrices = function(e) {
		$("#loader").show();
		try {
			e.stopPropagation();
			e.preventDefault();
			var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
			var file = files[0];
			if (file) {
				if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						var workbook = XLSX.read(data, {type: "binary"});
						var first_sheet_name = workbook.SheetNames[0];
						var worksheet = workbook.Sheets[first_sheet_name];
						var requiredJson = XLSX.utils.sheet_to_json(worksheet);
						$scope.updatePrices(requiredJson);
					};
					reader.readAsBinaryString(file);
				}
				document.getElementById("file_for_upload_prices").value = "";
			}
			return;
		} catch (err) {
			$("#loader").hide();
		}
	};

	$scope.updatePrices = function(docs) {
		if ((!docs) || (docs.length==0)) {
			$("#loader").hide();
		}
		var mapping = {};
		for (var loop=0, length = $scope.records.length; loop<length; loop++) {
			mapping[$scope.records[loop].lotNum] = loop;
		}
		for (loop=0, length = docs.length; loop<length; loop++) {
			try {
				var lotNumber = docs[loop]["Lot No"];
				if (!lotNumber) {
					continue;
				}
				lotNumber = ""+lotNumber.trim();
				lotNumber = lotNumber.toUpperCase();
				var pos = mapping[lotNumber];
				if (pos==null) {
					continue;
				}
				var price = docs[loop]["Price"];
				if ((!price)|| (isNaN(price))) {
					continue;
				}
				price = Number(price);
				if (price<0) {
					continue;
				}
				var status = docs[loop].Status;
				if (!status) {
					continue;
				}
				var avlKg = docs[loop]["G Wt"];
				if ((!avlKg) || isNaN(avlKg)) {
					avlKg = null;
				}
				status = ""+status.trim();
				status = status.toUpperCase();
				$scope.records[pos].price = price;
				$scope.records[pos].status = status;
				if (avlKg) {
					$scope.records[pos].avlKg = Number(avlKg);
				}
				var buyer = docs[loop]["Buyer"];
				if (buyer && price) {
					buyer = ""+buyer.trim();
					buyer = buyer.toUpperCase();
					$scope.records[pos].buyer = buyer;
				}
			} catch (err) {
				//
			}
		}
		try {
			$scope.$apply();
		} catch (err) {
			//
		}
		$("#loader").hide();
	};

	$scope.saveRecords = function() {
		if (!($scope.selection.locationId && $scope.selection.saleNum && $scope.selection.season)) {
			dataFactory.toastError("Location, Sale Num, Season all are required.");
			return;
		}
		$("#loader").show();
		var payload = {
			locationId: $scope.selection.locationId,
			saleNum: $scope.selection.saleNum.trim().toUpperCase(),
			season: $scope.selection.season,
			records: $scope.records,
		};
		payload._id = auctionId;
		if (payload._id && ($scope.selection.status) && ($scope.selection.status != "PENDING")) {
			payload.status = $scope.selection.status;
		}
		dataFactory.post("update-auction.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				if (!auctionId) {
					dataFactory.toastSuccess("records successfully created");
					if ($scope.selection.status=="PENDING") {
						auctions.push({_id: data.doc._id, auctionCenter: data.doc.auctionCenter, saleNum: data.doc.saleNum, season: data.doc.season});
					}
				} else {
					dataFactory.toastSuccess("records successfully updated");
				}
				$state.go("list");
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};

	$scope.getLocationName = function(input) {
		if (!input) {
			return "";
		}
		var pos = locationMap[input];
		if (pos==null) {
			return "n/a";
		}
		return $scope.locations[pos].name;
	};

	$scope.updateAssignment = function(auction) {
		if ((!auction.assignedTo) || (auction.assignedTo.length==0) || (!auction.tastingDate)) {
			dataFactory.toastError("Both assignee and tasting date is required");
			return;
		}
		for (var loop=0, length = auction.assignedTo.length; loop<length; loop++) {
			var userLocation = users[userMap[auction.assignedTo[loop]]].locationId;
			if (userLocation && (userLocation != auction.locationId)) {
				dataFactory.toastError("Assigned user location and must match location");
				return;
			}
		}
		$("#loader").show();
		var payload = {
			auctionId: auction._id,
			assignedTo: auction.assignedTo,
			tastingDate: auction.tastingDate.getTime(),
		};
		dataFactory.post("update-auction-assignment.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				dataFactory.toastSuccess("Record updated");
			} else {
				dataFactory.toastError(data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};

	$scope.auctionDetails = function(payload, callback) {
		if (!callback) {
			callback = function() {};
		}
		dataFactory.post("auction-details.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status && data.doc) {
				$scope.selection.locationId = data.doc.auctionCenter;
				$scope.selection.saleNum = data.doc.saleNum;
				$scope.selection.season = data.doc.season;
				if (data.doc.status) {
					$scope.selection.status = data.doc.status;
				}
				$scope.currentRecord = {};
				// for (var loop=0, length = data.doc.invoices.length; loop<length; loop++) {
				// var tmp = new Date(data.doc.invoices[loop].mfgDate);
				// data.doc.invoices[loop].mfgDateStr = date2String(tmp);
				// }
				$scope.records = data.doc.invoices;
				callback(null, data.doc);
			} else {
				// dataFactory.toastError(data.status?"Details not found":data.msg);
				callback(data.status?"Details not found":data.msg);
			}
		}, function() {
			// dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
			callback("we have encounterd an unexpected error, plesae try after some time.");
		});
	};

	$scope.assignAuctionId = function() {
		var id = $("#proxy_auction_selection").attr("data-auctionid");
		if (id) {
			$("#loader").show();
			var payload = {auctionId: id};
			$scope.auctionDetails(payload, function(err) {
				if (err) {
					dataFactory.toastError(err);
					$state.go("list");
				} else {
					$scope.selection.ready = true;
					$scope.selection.readonly = false;
					auctionId = id;
				}
			});
		} else {
			$state.go("list");
		}
	};

	$scope.doLookup = function() {
		if ($scope.selection.readonly) {
			$scope.doReset();
			return;
		}
		if (!($scope.selection.locationId && $scope.selection.saleNum && $scope.selection.season)) {
			dataFactory.toastError("Location, Sale Num, Season all are required.");
			return;
		}
		auctionId = null;
		$scope.selection.ready = false;
		$scope.selection.readonly = false;
		$scope.auctionDetails({
			locationId: $scope.selection.locationId,
			saleNum: $scope.selection.saleNum,
			season: $scope.selection.season,
		}, function(err, doc) {
			if (err) {
				$scope.selection.readonly = true;
				$scope.selection.ready = true;
			} else {
				$scope.selection.ready = true;
				auctionId = doc._id;
			}
		});
	};

	$scope.doReset = function() {
		auctionId = null;
		$scope.selection.ready = false;
		$scope.selection.readonly = false;
		$scope.currentRecord = {};
		$scope.currentPageNumberInList = 1;
		$scope.records = [];
	};

	$scope.fetchRecords = function() {
		if (!$scope.selection.season) {
			dataFactory.toastError("Season must be selected.");
			return;
		}
		auctions = [];
		$scope.auctions = [];
		var payload = {season: $scope.selection.season, status: $scope.selection.status, locationId: $scope.selection.locationId};
		dataFactory.post("list-auction-invoices.json", payload).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				auctions = data.docs;
				for (var loop=0, length=auctions.length; loop<length; loop++) {
					auctions[loop].tastingDate = new Date(auctions[loop].tastingDate);
				}
				$scope.auctions = auctions;
			} else {
				dataFactory.toastError(data.status?"records not found":data.msg);
			}
		}, function() {
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$("#loader").hide();
		});
	};
}]);
