
/* global mappings locations couriers:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "courierAddressMappingController",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "courierAddressMappingController",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "courierAddressMappingController",
				},
			},
			url: "/update?courierAddressMappingid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$("#courierAddressMapping_selection").dropdown({forceSelection: false});
			$("#courierAddressMapping_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-courierAddressMapping-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.courierAddressMappingid) {
					$("#courierAddressMapping_selection").dropdown("set selected", currentParams.courierAddressMappingid);
				}
			}, 300);
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$(".create-courierAddressMapping-tabs .item").tab();
			holder = document.getElementById("holder");
			holder.ondragover = function() {
				$(this).addClass("div_drag_hover");
				return false;
			};
			holder.ondragend = function() {
				$(this).removeClass("div_drag_hover");
				return false;
			};
			holder.ondrop = function(e) {
				$(this).removeClass("div_drag_hover");
				e.preventDefault();
				processFileForUpload(e);
			};
			setTimeout(function() {
				$(".boolean-field").checkbox();
				$("input.datepicker").each(function(idx, ele) {
					$(ele).daterangepicker({
						format: "DD MMM YYYY",
						singleDatePicker: true,
						showDropdowns: true,
						startDate: moment(),
					},
					function(start, end, label) {
						$(ele).attr("data-value", start.toDate().getTime());
					});
				});
			}, 500);
		}
	});
}]);
var courierMap = {};
var locationMap = {};
app.controller("courierAddressMappingController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.mappings = mappings;
	$scope.locations = locations;
	$scope.couriers = couriers;
	$scope.currentCourierAddressMapping = {isActive: true};
	$scope.currentCourierAddressMappingOrg = {isActive: true};
	$scope.courierAddressMappingUnderProcessing = {};


	$scope.courierAddressMappingChanged = function() {
		var courierAddressMappingId = $("#courierAddressMapping_selection input").val();
		if (courierAddressMappingId.length > 1) {
			if ($state.current.name == "update") {
				var posInCourierAddressMappings = _.findIndex($scope.mappings, ["_id", courierAddressMappingId]);
				if (posInCourierAddressMappings > -1) {
					$scope.currentCourierAddressMapping = JSON.parse(JSON.stringify($scope.mappings[posInCourierAddressMappings]));
					$scope.currentCourierAddressOrg = JSON.parse(JSON.stringify($scope.mappings[posInCourierAddressMappings]));
					$(".datepicker").each(function(idx, ele) {
						try {
							$(ele).attr("data-value", $scope.currentCourierAddressMapping[$(ele).attr("name")]);
							var tmpMoment = moment($scope.currentCourierAddressMapping[$(ele).attr("name")]);
							$(ele).val(tmpMoment.format("DD MMM YYYY"));
							$(ele).daterangepicker({
								format: "DD MMM YYYY",
								singleDatePicker: true,
								showDropdowns: true,
								startDate: tmpMoment,
							},
							function(start, end, label) {
								$(ele).attr("data-value", start.toDate().getTime());
							});
						} catch (e) {
							//
						}
					});
					$(".boolean-field").checkbox("uncheck");
					$(".boolean-field").each(function(idx, ele) {
						try {
							if ($scope.currentCourierAddressMapping[$(ele).attr("data-field-name")]) {
								$(ele).checkbox("check");
							}
						} catch (e) {
							//
						}
					});
					$("#submit_update_courierAddressMapping").removeClass("disabled");
					$("#reset_update_courierAddressMapping").removeClass("disabled");
				}
			}
		}
	};

	$scope.navUpdate = function(courierAddressMapping) {
		$state.go("update", {courierAddressMappingid: courierAddressMapping._id});
	};

	$scope.submitUpdateCourierAddressMapping = function() {
		var parsleyHandle = $("#courierAddressMappings_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#submit_update_courierAddressMapping").addClass("loading disabled");
			$("#reset_update_courierAddressMapping").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			var _tmp = JSON.parse(JSON.stringify($scope.currentCourierAddressMapping));
			delete _tmp.isActive;
			var payload = {
				find: $("#courierAddressMapping_selection input").val(),
				update: _tmp,
			};
			dataFactory.post("update-courier-location-mapping.json", payload).then(function(data) {
				$("#submit_update_courierAddressMapping").removeClass("loading disabled");
				$("#reset_update_courierAddressMapping").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess("CourierAddressMapping updated successfully");
					var posInCourierAddressMappings = _.findIndex(mappings, ["_id", $("#courierAddressMapping_selection input").val()]);
					if (posInCourierAddressMappings >= 0) {
						mappings[posInCourierAddressMappings] = data.doc;
						$scope.mappings = mappings;
						$scope.currentCourierAddressMappingOrg = JSON.parse(JSON.stringify(data.doc));
					}
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_courierAddressMapping").removeClass("loading disabled");
				$("#reset_update_courierAddressMapping").removeClass("disabled");
			});
		}
	};

	$scope.resetUpdateCourierAddressMapping = function() {
		$scope.currentCourierAddressMapping = JSON.parse(JSON.stringify($scope.currentCourierAddressMappingOrg));
	};

	$scope.setEnableddisabled = function(courierAddressMapping) {
		if ($scope.courierAddressMappingsUnderProcessing[courierAddressMapping._id]) {
			return;
		}
		$scope.courierAddressMappingsUnderProcessing[courierAddressMapping._id] = true;
		$("." + courierAddressMapping._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + courierAddressMapping._id).checkbox();
		var payload = {
			find: courierAddressMapping._id,
			update: {isActive: (!courierAddressMapping.isActive)},
		};
		dataFactory.post("update-courier-location-mapping.json", payload).then(function(data) {
			if (data.status) {
				courierAddressMapping.isActive = data.doc.isActive;
				$timeout(function() {
					if (courierAddressMapping.isActive) {
						$("." + courierAddressMapping._id).checkbox("check");
					} else {
						$("." + courierAddressMapping._id).checkbox("uncheck");
					}
					$("." + courierAddressMapping._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + courierAddressMapping._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.courierAddressMappingsUnderProcessing[courierAddressMapping._id] = false;
		}, function() {
			$("." + courierAddressMapping._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.courierAddressMappingsUnderProcessing[courierAddressMapping._id] = false;
		});
	};

	$scope.submitCreateCourierAddressMapping = function() {
		var parsleyHandle = $("#courierAddressMappings_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_create_courierAddressMapping").addClass("loading disabled");
			$("#reset_create_courierAddressMapping").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("create-courier-location-mapping.json", $scope.currentCourierAddressMapping).then(function(data) {
				$("#submit_create_courierAddressMapping").removeClass("loading disabled");
				$("#reset_create_courierAddressMapping").addClass("disabled");
				if (data.status) {
					mappings.push(data.doc);
					$scope.mappings = mappings;
					$scope.clearCreateCourierAddressMapping();
					dataFactory.toastSuccess("CourierAddressMapping created successfully");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_courierAddressMapping").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreateCourierAddressMapping = function() {
		$scope.currentCourierAddressMapping = {isActive: true};
	};

	$scope.submitCreateCourierAddressMappingBulk = function() {
		$("#submit_create_courierAddressMapping_bulk").addClass("loading");
		$.ajax({
			url: BASE_URL + "bulk-courier-location-mapping-create.json",
			data: window.fileUploadForm,
			cache: false,
			contentType: false,
			processData: false,
			type: "POST",
			dataType: "json",
			success: function(data) {
				if (data.status) {
					$scope.clearCreateCourierAddressMappingBulk();
					uploadResultArray = [];
					for (var loop = 0; loop < data.outcome.length; loop++) {
						uploadResultArray.push([data.outcome[loop]]);
					}
					if (data.docs) {
						mappings = data.docs;
						$scope.mappings = mappings;
					}
					$(".upload-status-modal p span").html(data.successCount + "/" + data.outcome.length + "Mappings created.");
					$(".upload-status-modal").modal({closable: false}).modal("show");
				} else {
					dataFactory.toastError(data.msg);
				}
				window.fileUploadForm = null;
				$("#submit_create_courierAddressMapping_bulk").removeClass("loading");
			},
			error: function() {
				$("#submit_create_courierAddressMapping_bulk").removeClass("loading");
				dataFactory.toastError("Currently we are unable to process your request, plesae try later.");
			},
		});
	};

	$scope.clearCreateCourierAddressMappingBulk = function() {
		$(".file-upload-tab .parsley-required").html("");
		$("#holder p label").show();
		$("#holder p a").html("");
		$("#holder p a").hide();
		$("#submit_create_courierAddressMapping_bulk").addClass("disabled");
		$("#reset_create_courierAddressMapping_bulk").addClass("disabled");
		window.fileUploadForm = null;
	};

	$scope.loadDateAndBooleanFields = function() {
		$(".datepicker").each(function(idx, ele) {
			try {
				$scope.currentCourierAddressMapping[$(ele).attr("name")] = Number($(ele).attr("data-value"));
			} catch (e) {
				//
			}
		});

		$(".boolean-field").each(function(idx, ele) {
			try {
				$scope.currentCourierAddressMapping[$(ele).attr("data-field-name")] = $(ele).hasClass("checked");
			} catch (e) {
				//
			}
		});

		$(".foreign-field").each(function(idx, ele) {
			try {
				$scope.currentCourierAddressMapping[$(ele).attr("data-field-name")] = $(ele).find("input").val();
			} catch (e) {
				//
			}
		});
	};

	$scope.getSellerName = function(input) {
		if (!input) {
			return "";
		}
		if (!courierMap[input]) {
			var obj = _.find(couriers, {_id: input});
			if (obj) {
				courierMap[input] = obj;
			} else {
				courierMap[input] = {name: "N/A", code: "N/A"};
			}
		}
		return courierMap[input].name;
	};

	$scope.getMarkName = function(input) {
		if (!input) {
			return "";
		}
		if (!locationMap[input]) {
			var obj = _.find(locations, {_id: input});
			if (obj) {
				locationMap[input] = obj;
			} else {
				locationMap[input] = {name: "N/A", code: "N/A"};
			}
		}
		return locationMap[input].name;
	};
}]);
var holder = null;

function processFileForUpload(e) {
	try {
		var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
		var file = files[0];
		if (file) {
			if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
				var extention = file.name.toUpperCase().split(".");
				extention = extention[extention.length - 1];
				$(".file-upload-tab .parsley-required").html("");
				if (file.size > (512 * 1024 * 1024)) {
					$(".file-upload-tab .parsley-required").html("Please use a file smaller than 512kB");
					return;
				}
				$(".file-upload-tab .parsley-required").html("");
				$("#holder p label").hide();
				$("#holder p a").html(file.name);
				$("#holder p a").show();
				$("#submit_create_courierAddressMapping_bulk").removeClass("disabled");
				$("#reset_create_courierAddressMapping_bulk").removeClass("disabled");
				window.fileUploadForm = new FormData();
				window.fileUploadForm.append("extention", extention);
				window.fileUploadForm.append("upload", file);
				document.getElementById("file_for_upload").value = "";
			} else {
				$(".file-upload-tab .parsley-required").html("Only <i>xls, xlsx, ods<i/> files are allowed.");
			}
		}
		return;
	} catch (err) {
		//
	}
}
var uploadResultArray = [[]];
// eslint-disable-next-line no-unused-vars
function downloadExcel() {
	$(".upload-status-modal .positive").click();
	var wb = new Workbook();
	var ws = sheet_from_array_of_arrays(uploadResultArray);
	wb.SheetNames.push("outcome");
	wb.Sheets["outcome"] = ws;
	var wbout = XLSX.write(wb, {
		bookType: "xlsx",
		bookSST: true,
		type: "binary",
	});
	saveAs(new Blob([s2ab(wbout)], {
		type: "application/octet-stream",
	}), "outcome_" + new Date().getTime() + ".xlsx");
}

