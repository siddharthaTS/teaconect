/* global clients marks locations type:true*/

var dateFormat = "DD-MM-YYYY";
var _start;
var _end;
var locationMap = {};
var clientMap = {};
var markMap = {};
var loop=0;
var length = 0;

var _currentDate = new Date();

app.controller("reportController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.modeDespatchSelection = true;
	$scope.clients = clients;
	$scope.locations = locations;
	$scope.marks = marks;

	$scope.report = {};

	$scope.reports =[];

	$scope.detailsHeader = "";

	var dt = moment(_currentDate).startOf("week").toDate();
	dt.setHours(0);
	dt.setMinutes(0);
	dt.setSeconds(0);
	dt.setMilliseconds(0);
	$scope.startDate = _start;
	if (!$scope.startDate) {
		$scope.startDate = dt.getTime();
	}
	dt = moment(_currentDate).endOf("week").toDate();
	dt.setHours(23);
	dt.setMinutes(59);
	dt.setSeconds(59);
	dt.setMilliseconds(999);
	$scope.endDate = _end;
	if (!$scope.endDate) {
		$scope.endDate = dt.getTime();
	}
	$scope.selection={clientId: "", markId: "", locationId: "", reportType: type, mode: "search"};
	$timeout(function() {
		$scope.initDateRangePicker();
	}, 150);

	$scope.fetchRecords = function() {
		$scope.errorMessage = null;
		$("#loader").show();
		dataFactory.post("app/search-tasting-reports.json", $scope.selection).then(function(data) {
			$("#loader").hide();
			if (data.status && (data.docs.length>0)) {
				$scope.reports = data.docs;
			} else {
				$scope.errorMessage = "No record(s) found for your search criteria";
			}
		}, function() {
			$("#loader").hide();
			$scope.errorMessage = "No record(s) found for your search criteria";
		});
	};

	$scope.dateChanged = function() {
	};

	$scope.clientChanged = function() {
		/* var pos = _.findIndex(clients, {_id: $scope.selection.clientId});
		if (pos>=0) {
			$scope.marks = clients[pos].marks;
		} else {
			$scope.marks = [];
		} */
	};

	$scope.getMarkName = function(id) {
		if (!markMap[id]) {
			return "--";
		}
		return markMap[id];
	};

	$scope.getClientName = function(id) {
		if (!clientMap[id]) {
			return "--";
		}
		return clientMap[id];
	};

	$scope.getLocationName = function(id) {
		if (!locationMap[id]) {
			return "--";
		}
		return locationMap[id];
	};

	$scope.initDateRangePicker = function() {
		var startDate = moment($scope.startDate);
		var enddate = moment($scope.endDate);
		$(".date_range_selector").val(startDate.format(dateFormat) + " To " + enddate.format(dateFormat));
		$scope.selection.dateRangeStr = startDate.format(dateFormat) + " To " + enddate.format(dateFormat);
		$scope.selection.start = $scope.startDate;
		$scope.selection.end = $scope.endDate;
		$(".date_range_selector").daterangepicker(
			{
				startDate: startDate,
				endDate: enddate,
				format: dateFormat,
				separator: " To ",
				ranges: {
					"Today": [moment(), moment()],
					"Yesterday": [moment().subtract(1, "days"), moment().subtract(1, "days")],
					"Last 7 Days": [moment().subtract(6, "days"), moment()],
					"Last 30 Days": [moment().subtract(29, "days"), moment()],
					"This Month": [moment().startOf("month"), moment().endOf("month")],
					"Last Month": [moment().subtract(1, "month").startOf("month"), moment().subtract(1, "month").endOf("month")],
				},
			},
			function(start, end) {
				$scope.selection.dateRangeStr = start.format(dateFormat) + " To " + end.format(dateFormat);
				$scope.startDate = start.valueOf();
				$scope.endDate = end.valueOf();
				_start = start.valueOf();
				_end = end.valueOf();
				$scope.selection.start = _start;
				$scope.selection.end = _end;
			});
	};

	$scope.viewReportDetails = function(report) {
		$scope.errorMessage = null;
		$("#loader").show();
		dataFactory.post("app/tasting-report-details.json", {reportId: report._id}).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				$scope.selection.mode = "details";
				$scope.report = data.doc;
				$scope.detailsHeader = report.addlDisplay +" - " + report.date;
			} else {
				dataFactory.toastError("No record(s) found for your search criteria");
			}
		}, function() {
			$("#loader").hide();
			dataFactory.toastError("No record(s) found for your search criteria");
		});
	};

	$scope.navBack = function() {
		$scope.selection.mode = "search";
	};

	$scope.editReport = function() {
		window.location.href = "/tea-tasting.html#/update?reportid="+$scope.report._id;
	};

	$scope.publish = function(status) {
		if (userprofile.userType != "Taster") {
			dataFactory.toastError("You are not permitted this operation");
			return;
		}
		$("#loader").show();
		dataFactory.post("app/update-publish-report.json", {reportId: $scope.report._id}).then(function(data) {
			$("#loader").hide();
			if (data.status) {
				$scope.report.published = data.published;
			} else {
				dataFactory.toastError("Failed to update status");
			}
		}, function() {
			$("#loader").hide();
			dataFactory.toastError("Failed to update status");
		});
	};

	$scope.DownloadPdf = function() {
		$("#loader").show();
		var xhr = new XMLHttpRequest();
		xhr.open("POST", BASE_URL + "app/tasting-report.pdf", true);
		xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhr.responseType = "blob";
		xhr.onload = function() {
			$("#loader").hide();
			if (xhr.response.size>0) {
				saveAs(xhr.response, "report.pdf");
			} else {
				dataFactory.toastError("Failed to download");
			}
		};
		xhr.send("reportId="+$scope.report._id);
	};

	$scope.DownloadExcel = function(type) {
		$("#loader").show();
		var xhr = new XMLHttpRequest();
		xhr.open("POST", BASE_URL + "app/tasting-report.xlsx", true);
		xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhr.responseType = "blob";
		xhr.onload = function() {
			$("#loader").hide();
			if (xhr.response.size>0) {
				saveAs(xhr.response, "report.xlsx");
			} else {
				dataFactory.toastError("Failed to download");
			}
		};
		xhr.send("reportId="+$scope.report._id+"&type="+type);
	};
}]);

function dateChanged() { // eslint-disable-line no-unused-vars
	setTimeout(function() {
		$("#proxy-date-change").click();
	}, 100);
}

/* function initDatePicker(dateArr) { // eslint-disable-line no-unused-vars
	$("input.datepicker").each(function(idx, ele) {
		var format = $(ele).attr("data-date-format");
		if (!format) {
			format = "DD MMM YYYY";
		}
		var customClass = $(ele).attr("data-date-additional-class");
		var tmpMoment = null;
		if (dateArr && dateArr[idx]) {
			tmpMoment = moment(dateArr[idx]);
		} else {
			if (_currentDate) {
				tmpMoment = moment(_currentDate);
			} else {
				tmpMoment = moment();
			}
		}
		$(ele).val(tmpMoment.format(format));
		$(ele).attr("data-value", tmpMoment.valueOf());
		$(ele).daterangepicker({
			format: format,
			singleDatePicker: true,
			showDropdowns: true,
			startDate: tmpMoment,
		},
		function(start, end, label) {
			$(ele).attr("data-value", start.toDate().getTime());
		});
		if (customClass) {
			$(".daterangepicker:last").addClass(customClass);
		}
	});
} */

for (loop=0, length = clients.length; loop<length; loop++) {
	clientMap[clients[loop]._id] = clients[loop].name;
}

for (var inner=0, innerLen = marks.length; inner <innerLen; inner++) {
	markMap[marks[inner]._id] = marks[inner].name;
}

for (loop=0, length = locations.length; loop<length; loop++) {
	locationMap[locations[loop]._id] = locations[loop].name;
}
