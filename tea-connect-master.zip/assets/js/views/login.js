var BASE_URL = window.location.origin+"/";
var target = document.querySelector("#login-password");
target.addEventListener("keyup", function(event) {
	if (event.keyCode === 13) {
		event.preventDefault();
		doLogin();
	}
});

// eslint-disable-next-line no-unused-vars
function navToForgotPassword() {
	window.location.assign("/forgot-password.html");
}

function doLogin() {
	var loginId = document.querySelector("#login-id").value.trim();
	var password = document.querySelector("#login-password").value.trim();
	if ((!loginId) && (!password)) {
		document.querySelector("#error-container").innerText="Both Login Id and Password are required.";
	} else if (!loginId) {
		document.querySelector("#error-container").innerText="Login Id is required.";
	} else if (!password) {
		document.querySelector("#error-container").innerText="Password is required.";
	} else {
		document.querySelector("#error-container").innerText="";
		document.querySelector("#loader").style.display = "block";
		var xhr = new XMLHttpRequest();
		xhr.open("POST", BASE_URL + "validate-user.json");
		xhr.setRequestHeader("Content-type", "application/json");
		xhr.responseType = "text";
		xhr.onreadystatechange = function() {
			if (xhr.readyState === 4) {
				document.querySelector("#loader").style.display = "none";
				if (xhr.status === 200) {
					var data = JSON.parse(xhr.responseText);
					if (data.status) {
						localStorage.setItem("userprofile", JSON.stringify(data.doc));
						window.location.replace("/home.html");
					} else {
						document.querySelector("#error-container").innerText=data.msg?data.msg:"Failed to authenticate user";
					}
				} else {
					document.querySelector("#error-container").innerText="Failed to authenticate user";
				}
			}
		};
		var payload = {};
		payload.loginId = loginId;
		payload.password = password;
		// payload.renew = true;
		payload.mode = "WEB";
		xhr.send(JSON.stringify(payload));
	}
}
