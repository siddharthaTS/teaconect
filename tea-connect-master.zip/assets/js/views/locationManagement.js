
/* global locations:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "locationController",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "locationController",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "locationController",
				},
			},
			url: "/update?locationid",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$("#location_selection").dropdown({forceSelection: false});
			$("#location_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-location-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.locationid) {
					$("#location_selection").dropdown("set selected", currentParams.locationid);
				}
			}, 300);
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$(".create-location-tabs .item").tab();
			holder = document.getElementById("holder");
			holder.ondragover = function() {
				$(this).addClass("div_drag_hover");
				return false;
			};
			holder.ondragend = function() {
				$(this).removeClass("div_drag_hover");
				return false;
			};
			holder.ondrop = function(e) {
				$(this).removeClass("div_drag_hover");
				e.preventDefault();
				processFileForUpload(e);
			};
			setTimeout(function() {
				$(".boolean-field").checkbox();
				$("input.datepicker").each(function(idx, ele) {
					$(ele).daterangepicker({
						format: "DD MMM YYYY",
						singleDatePicker: true,
						showDropdowns: true,
						startDate: moment(),
					},
					function(start, end, label) {
						$(ele).attr("data-value", start.toDate().getTime());
					});
				});
			}, 500);
		}
	});
}]);

app.controller("locationController", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.locations = locations;
	$scope.currentLocation = {isActive: true};
	$scope.currentLocationOrg = {isActive: true};
	$scope.locationsUnderProcessing = {};


	$scope.locationChanged = function() {
		var locationId = $("#location_selection input").val();
		if (locationId.length > 1) {
			if ($state.current.name == "update") {
				var posInLocations = _.findIndex($scope.locations, ["_id", locationId]);
				if (posInLocations > -1) {
					$scope.currentLocation = JSON.parse(JSON.stringify($scope.locations[posInLocations]));
					$scope.currentLocationOrg = JSON.parse(JSON.stringify($scope.locations[posInLocations]));
					$(".datepicker").each(function(idx, ele) {
						try {
							$(ele).attr("data-value", $scope.currentLocation[$(ele).attr("name")]);
							var tmpMoment = moment($scope.currentLocation[$(ele).attr("name")]);
							$(ele).val(tmpMoment.format("DD MMM YYYY"));
							$(ele).daterangepicker({
								format: "DD MMM YYYY",
								singleDatePicker: true,
								showDropdowns: true,
								startDate: tmpMoment,
							},
							function(start, end, label) {
								$(ele).attr("data-value", start.toDate().getTime());
							});
						} catch (e) {
							//
						}
					});
					$(".boolean-field").checkbox("uncheck");
					$(".boolean-field").each(function(idx, ele) {
						try {
							if ($scope.currentLocation[$(ele).attr("data-field-name")]) {
								$(ele).checkbox("check");
							}
						} catch (e) {
							//
						}
					});
					$("#submit_update_location").removeClass("disabled");
					$("#reset_update_location").removeClass("disabled");
				}
			}
		}
	};

	$scope.navUpdate = function(location) {
		$state.go("update", {locationid: location._id});
	};

	$scope.submitUpdateLocation = function() {
		var parsleyHandle = $("#locations_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#submit_update_location").addClass("loading disabled");
			$("#reset_update_location").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			var _tmp = JSON.parse(JSON.stringify($scope.currentLocation));
			delete _tmp.isActive;
			var payload = {
				find: $("#location_selection input").val(),
				update: _tmp,
			};
			dataFactory.post("update-location.json", payload).then(function(data) {
				$("#submit_update_location").removeClass("loading disabled");
				$("#reset_update_location").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess("Location updated successfully");
					var posInLocations = _.findIndex(locations, ["_id", $("#location_selection input").val()]);
					if (posInLocations >= 0) {
						locations[posInLocations] = data.doc;
						$scope.locations = locations;
						$scope.currentLocationOrg = JSON.parse(JSON.stringify(data.doc));
					}
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_location").removeClass("loading disabled");
				$("#reset_update_location").removeClass("disabled");
			});
		}
	};

	$scope.resetUpdateLocation = function() {
		$scope.currentLocation = JSON.parse(JSON.stringify($scope.currentLocationOrg));
	};

	$scope.setEnableddisabled = function(location) {
		if ($scope.locationsUnderProcessing[location._id]) {
			return;
		}
		$scope.locationsUnderProcessing[location._id] = true;
		$("." + location._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + location._id).checkbox();
		var payload = {
			find: location._id,
			update: {isActive: (!location.isActive)},
		};
		dataFactory.post("update-location.json", payload).then(function(data) {
			if (data.status) {
				location.isActive = data.doc.isActive;
				$timeout(function() {
					if (location.isActive) {
						$("." + location._id).checkbox("check");
					} else {
						$("." + location._id).checkbox("uncheck");
					}
					$("." + location._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + location._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.locationsUnderProcessing[location._id] = false;
		}, function() {
			$("." + location._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.locationsUnderProcessing[location._id] = false;
		});
	};

	$scope.submitCreateLocation = function() {
		var parsleyHandle = $("#locations_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_create_location").addClass("loading disabled");
			$("#reset_create_location").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("create-location.json", $scope.currentLocation).then(function(data) {
				$("#submit_create_location").removeClass("loading disabled");
				$("#reset_create_location").addClass("disabled");
				if (data.status) {
					locations.push(data.doc);
					$scope.locations = locations;
					$scope.clearCreateLocation();
					dataFactory.toastSuccess("Location created successfully");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_location").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreateLocation = function() {
		$scope.currentLocation = {isActive: true};
	};

	$scope.submitCreateLocationBulk = function() {
		$("#submit_create_location_bulk").addClass("loading");
		$.ajax({
			url: BASE_URL + "bulk-location-create.json",
			data: window.fileUploadForm,
			cache: false,
			contentType: false,
			processData: false,
			type: "POST",
			dataType: "json",
			success: function(data) {
				if (data.status) {
					$scope.clearCreateLocationBulk();
					uploadResultArray = [];
					for (var loop = 0; loop < data.outcome.length; loop++) {
						uploadResultArray.push([data.outcome[loop]]);
					}
					if (data.docs) {
						locations = data.docs;
						$scope.locations = locations;
					}
					$(".upload-status-modal p span").html(data.successCount + "/" + data.outcome.length + "Locations created.");
					$(".upload-status-modal").modal({closable: false}).modal("show");
				} else {
					dataFactory.toastError(data.msg);
				}
				window.fileUploadForm = null;
				$("#submit_create_location_bulk").removeClass("loading");
			},
			error: function() {
				$("#submit_create_location_bulk").removeClass("loading");
				dataFactory.toastError("Currently we are unable to process your request, plesae try later.");
			},
		});
	};

	$scope.clearCreateLocationBulk = function() {
		$(".file-upload-tab .parsley-required").html("");
		$("#holder p label").show();
		$("#holder p a").html("");
		$("#holder p a").hide();
		$("#submit_create_location_bulk").addClass("disabled");
		$("#reset_create_location_bulk").addClass("disabled");
		window.fileUploadForm = null;
	};

	$scope.loadDateAndBooleanFields = function() {
		$(".datepicker").each(function(idx, ele) {
			try {
				$scope.currentLocation[$(ele).attr("name")] = Number($(ele).attr("data-value"));
			} catch (e) {
				//
			}
		});

		$(".boolean-field").each(function(idx, ele) {
			try {
				$scope.currentLocation[$(ele).attr("data-field-name")] = $(ele).hasClass("checked");
			} catch (e) {
				//
			}
		});

		$(".foreign-field").each(function(idx, ele) {
			try {
				$scope.currentLocation[$(ele).attr("data-field-name")] = $(ele).find("input").val();
			} catch (e) {
				//
			}
		});
	};
}]);
var holder = null;

function processFileForUpload(e) {
	try {
		var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
		var file = files[0];
		if (file) {
			if (/\.(xls|xlsx|ods)$/i.test(file.name)) {
				var extention = file.name.toUpperCase().split(".");
				extention = extention[extention.length - 1];
				$(".file-upload-tab .parsley-required").html("");
				if (file.size > (512 * 1024 * 1024)) {
					$(".file-upload-tab .parsley-required").html("Please use a file smaller than 512kB");
					return;
				}
				$(".file-upload-tab .parsley-required").html("");
				$("#holder p label").hide();
				$("#holder p a").html(file.name);
				$("#holder p a").show();
				$("#submit_create_location_bulk").removeClass("disabled");
				$("#reset_create_location_bulk").removeClass("disabled");
				window.fileUploadForm = new FormData();
				window.fileUploadForm.append("extention", extention);
				window.fileUploadForm.append("upload", file);
				document.getElementById("file_for_upload").value = "";
			} else {
				$(".file-upload-tab .parsley-required").html("Only <i>xls, xlsx, ods<i/> files are allowed.");
			}
		}
		return;
	} catch (err) {
		//
	}
}
var uploadResultArray = [[]];
// eslint-disable-next-line no-unused-vars
function downloadExcel() {
	$(".upload-status-modal .positive").click();
	var wb = new Workbook();
	var ws = sheet_from_array_of_arrays(uploadResultArray);
	wb.SheetNames.push("outcome");
	wb.Sheets["outcome"] = ws;
	var wbout = XLSX.write(wb, {
		bookType: "xlsx",
		bookSST: true,
		type: "binary",
	});
	saveAs(new Blob([s2ab(wbout)], {
		type: "application/octet-stream",
	}), "outcome_" + new Date().getTime() + ".xlsx");
}

