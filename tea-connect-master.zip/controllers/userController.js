module.exports = {
	validateLogin: async (ctx) => {
		const loginId = ctx.request.fields.loginId;
		const password = ctx.request.fields.password;
		const mode = ctx.request.fields.mode || "API";
		if (!(password && loginId)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const userModel = require("../models/user")(ctx);
		const result = await userModel.authenticateLite(loginId, password, mode);
		if (!result.status) {
			return ctx.ok(result);
		} else {
			if (mode=="WEB") {
				ctx.session.userId = result.doc._id;
				ctx.session.companyId = result.doc.companyId;
			} else {
				const payload = {_id: result.doc._id, version: icplApp.appVersion, companyId: result.doc.companyId};
				if (mode=="APP") {
					payload.renew = true;
				}
				const jwt = require("jsonwebtoken");
				const token = jwt.sign(payload, ctx.secret, {expiresIn: (mode=="APP")?"10h": 30*60});
				delete result.doc._id;
				result.doc.token = token;
			}
			delete result.doc._id;
			delete result.doc.companyId;
			return ctx.ok(result);
		}
	},
	updateProfile: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		let userName = ctx.request.fields.userName;
		let userEmail = ctx.request.fields.userEmail;
		let contactNumber = ctx.request.fields.contactNumber;
		if (!(userName && userEmail && contactNumber)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		userName = userName.trim();
		userEmail = userEmail.trim();
		contactNumber = (""+contactNumber).trim();
		if (contactNumber.length != 10) {
			return ctx.ok({status: false, msg: "Phone number must be valid 10 digit mobile number."});
		}
		if (!(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(userEmail))) {
			return ctx.ok({status: false, msg: "Email Id must be valid."});
		}
		const model = require("../models/user")(ctx);
		const result = await model.update(userId, {$set: {
			userName: userName,
			userEmail: userEmail,
			contactNumber: contactNumber,
		}});
		if (result.status && ctx.request.fields.tokenExpired) {
			result.token = ctx.request.fields.token;
		}
		return ctx.ok(result);
	},
	logoutAppUser: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const model = require("../models/user")(ctx);
		const result = await model.logoutAppUser(userId);
		if (result.status) {
			delete ctx.session.userId;
		}
		return ctx.ok(result);
	},
	generateUserOTP: async (ctx) => {
		const loginId = ctx.request.fields.loginId;
		if (!(loginId)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const userModel = require("../models/user")(ctx);
		const result = await userModel.generateUserOTP(loginId);
		return ctx.ok(result);
	},
	resetUserPassword: async (ctx) => {
		const loginId = ctx.request.fields.loginId;
		const password = ctx.request.fields.password;
		const otp = ctx.request.fields.otp;
		if (!(password && loginId && otp)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const userModel = require("../models/user")(ctx);
		const result = await userModel.resetUserPassword(loginId, otp, password);
		return ctx.ok(result);
	},
	lastOnline: async (ctx) => {
		const userType = ctx.request.fields.userType;
		let token = ctx.request.fields.token;
		if (!(userType && token)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const jwt = require("jsonwebtoken");
		let _id = "";
		let tokenExpired = false;
		try {
			const decoded = jwt.verify(token, ctx.secret);
			_id = decoded._id;
		} catch (err) {
			if (err.name=="TokenExpiredError") {
				try {
					const decoded = jwt.verify(token, ctx.secret, {ignoreExpiration: true});
					_id = decoded._id;
					token = jwt.sign({_id: _id}, ctx.secret, {expiresIn: "7d"});
					tokenExpired = true;
				} catch (err) {
					return ctx.ok({status: false, msg: "Invalid Token."});
				}
			} else {
				return ctx.ok({status: false, msg: "Invalid Token."});
			}
		}
		const model = require("../models/user")(ctx);
		const result = await model.listBrokersAndBuyerUsers(_id);
		if (result.status) {
			if (tokenExpired) {
				result.token = token;
			}
			let docs = [];
			// const moment = require("moment");
			const _ = require("lodash");
			for (let loop=0, length = result.docs.length; loop<length; loop++) {
				for (let inner = 0, innerlength = result.docs[loop].users.length; inner<innerlength; inner++) {
					docs.push({
						company: result.docs[loop].name,
						user: result.docs[loop].users[inner].userName,
						contactNo: result.docs[loop].users[inner].contactNumber,
						// time: result.docs[loop].users[inner].lastOnline?moment(result.docs[loop].users[inner].lastOnline.getTime()).format("MMM Do YYYY, h:mm a"):"--",
						time: result.docs[loop].users[inner].lastOnline? result.docs[loop].users[inner].lastOnline.getTime():0,
					});
				}
			}
			docs = _.sortBy(docs, ["time"]);
			docs.reverse();
			result.docs = docs;
		}
		return ctx.ok(result);
	},
	isUniqueMailId: async (ctx) => {
		var data = ctx.request.fields;
		var newEmailId = data.newEmailId;
		var currentEmailId = data.currentEmailId;
		if (!newEmailId) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		newEmailId = newEmailId.toLowerCase();
		const userModel = require("../models/user")(ctx);
		const userResult = await userModel.getCountForMailId(newEmailId);
		if (userResult.status) {
			if (userResult.count>0) {
				if (newEmailId == currentEmailId) {
					return ctx.ok({status: true, msg: "success"});
				}
				return ctx.ok({status: false, msg: "This email id is already registered."});
			} else {
				if (newEmailId == currentEmailId) {
					return ctx.ok({status: false, msg: "Invalid email id."});
				}
				return ctx.ok({status: true, msg: "success"});
			}
		} else {
			return ctx.ok({
				status: false, msg: "we have encounterd an unexpected error, plesae try after some time.",
			});
		}
	},
	isUniqueLoginId: async (ctx) => {
		var data = ctx.request.fields;
		var newLoginId = data.newLoginId;
		var currentLoginId = data.currentLoginId;
		if (!newLoginId) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		newLoginId = newLoginId.toLowerCase();
		const userModel = require("../models/user")(ctx);
		const userResult = await userModel.getCountForLoginId(newLoginId);
		if (userResult.status) {
			if (userResult.count>0) {
				if (newLoginId == currentLoginId) {
					return ctx.ok({status: true, msg: "success"});
				}
				return ctx.ok({status: false, msg: "This login id is already registered."});
			} else {
				if (newLoginId == currentLoginId) {
					return ctx.ok({status: false, msg: "Invalid login id."});
				}
				return ctx.ok({status: true, msg: "success"});
			}
		} else {
			return ctx.ok({
				status: false, msg: "We have encounterd an unexpected error, plesae try after some time.",
			});
		}
	},
	changePasswordAdmin: async (ctx) => {
		var params = ctx.request.fields;
		var userId = params.userid;
		var password = params.password;
		/* var hasResetPrivilege = false;
		try {
			if (ctx.session.privileges.user_super_admin.access.indexOf("updatePassword") >= 0) {
				hasResetPrivilege = true;
			}
		} catch (ex) {
			//
		}
		var additionalSearchCriteria = null;
		if (!hasResetPrivilege) {
			try {
				if (ctx.session.privileges.user_management.access.indexOf("update") >= 0) {
					hasResetPrivilege = true;
				}
			} catch (ex) {
				//
			}
			additionalSearchCriteria = {companyId: ctx.session.companyId};
		}
		if (!hasResetPrivilege) {
			return ctx.ok({
				status: false,
				msg: "You do not have the required previleges.",
			});
		} */
		const userModel = require("../models/user")(ctx);
		const userResult = await userModel.updatePassword(userId, password, ctx.session.userId);
		if (userResult.status) {
			return ctx.ok({
				status: true,
				msg: "Password updated",
			});
		} else {
			return ctx.ok({
				status: false,
				msg: "Password not updated",
			});
		}
	},
	changePasswordSelf: async (ctx) => {
		let userId = ctx.session.userId;
		const params = ctx.request.fields;
		let password = params.password;
		if (!(password)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		password = password.trim();
		if (!(password)) {
			return ctx.ok({status: false, msg: "Invalid password."});
		}
		let token = ctx.request.fields.token;
		let tokenExpired = false;
		if (!userId) {
			if (!token) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const jwt = require("jsonwebtoken");
			try {
				const decoded = jwt.verify(token, ctx.secret);
				userId = decoded._id;
			} catch (err) {
				if (err.name=="TokenExpiredError") {
					try {
						const decoded = jwt.verify(token, ctx.secret, {ignoreExpiration: true});
						if (decoded.mode=="API") {
							return ctx.ok({status: false, msg: "Token expired"});
						}
						userId = decoded._id;
						token = jwt.sign({_id: userId}, ctx.secret, {expiresIn: "1d"});
						tokenExpired = true;
					} catch (err) {
						return ctx.ok({status: false, msg: "Invalid Token."});
					}
				} else {
					return ctx.ok({status: false, msg: "Invalid Token."});
				}
			}
		}
		const userModel = require("../models/user")(ctx);
		const userResult = await userModel.updatePassword(userId, password, userId);
		if (userResult.status) {
			if (tokenExpired) {
				return ctx.ok({
					status: true,
					msg: "Password updated",
					token: token,
				});
			}
			return ctx.ok({
				status: true,
				msg: "Password updated",
			});
		} else {
			return ctx.ok({
				status: false,
				msg: "Password not updated",
			});
		}
	},
	changePasswordApp: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const params = ctx.request.fields;
		let oldPassword = params.oldPassword;
		let password = params.password;
		if (!(password && oldPassword)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		oldPassword = oldPassword.trim();
		password = password.trim();
		if (!(password && oldPassword)) {
			return ctx.ok({status: false, msg: "Invalid password."});
		}
		const userModel = require("../models/user")(ctx);
		const result = await userModel.updatePasswordApp(userId, oldPassword, password);
		if (result.status && ctx.request.fields.tokenExpired) {
			result.token = ctx.request.fields.token;
		}
		return ctx.ok(result);
	},
	updateUser: async (ctx) => {
		var params = ctx.request.fields;
		var userId = params.userid;
		var update = params.update;
		if ((!userId) || (!update)) {
			return ctx.ok({
				status: false,
				msg: "Parameter(s) missing.",
			});
		}
		try {
			if (update.$set.userName) {
				update.$set.userName = update.$set.userName.trim().toTitleCase();
			}
			if (update.$set.code) {
				update.$set.code = update.$set.code.trim().toUpperCase();
			}
			update.$set["updatedAt"] = new Date();
			update.$set["updatedBy"] = ctx.session.userId;
		} catch (err) {
			return ctx.ok({
				status: false, msg: "We have encountered an unexpected error, please try after some time.",
			});
		}
		/* var hasPrivilege = false;
		try {
			if ((ctx.session.privileges.user_super_admin.access.indexOf("updatePassword") >= 0) || (ctx.session.privileges.user_super_admin.access.indexOf("setInactive") >= 0)) {
				hasPrivilege = true;
			}
		} catch (ex) {
			//
		}
		if (!hasPrivilege) {
			try {
				if ((ctx.session.privileges.user_management.access.indexOf("update") >= 0)) {
					hasPrivilege = true;
				}
			} catch (ex) {
				//
			}
		}
		if (!hasPrivilege) {
			return ctx.ok({
				status: false,
				msg: "You do not have the required previleges.",
			});
		} */
		const userModel = require("../models/user")(ctx);
		const _ = require("lodash");
		if (update.$set.parentUserId && (update.$set.parentUserId != userId)) {
			const userResult = await userModel.getAllUsers(userId, ctx.session.companyId, {_id: 1});
			if (!userResult.status) {
				return ctx.ok({
					status: false, msg: "We have encountered an unexpected error, please try after some time.",
				});
			}
			var pos = _.findIndex(userResult.docs, {"_id": update.$set.parentUserId});
			if (pos >= 0) {
				return ctx.ok({
					status: false,
					msg: "You can not set a user below in hierarchy as a parent user.",
				});
			}
			await makeUpdate();
		} else {
			await makeUpdate();
		}

		async function makeUpdate() {
			const userResult = await userModel.update(userId, update);
			return ctx.ok(userResult);
		}
	},
	create: async (ctx) =>{
		var params = ctx.request.fields;
		if (!(params.userName && params.code && params.userEmail && params.userType && params.privileges && params.loginId && params.parentUserId && params.password)) {
			return ctx.ok({
				status: 1,
				msg: "Parameter(s) missing.",
			});
		}
		if (!params.contactNumber) {
			params.contactNumber = "";
		}
		let newUserCompanyId = "";
		if (params.userType != "Client") {
			newUserCompanyId = "5eb2d65f5bbfeb46054a93b0";
		}
		var currentTime = new Date();
		var user = {};
		user["companyId"] = newUserCompanyId;
		user["userName"] = params.userName.trim().toTitleCase();
		user["code"] = params.code.trim().toUpperCase();
		user["userEmail"] = params.userEmail.toLowerCase();
		user["isActive"] = true;
		user["contactNumber"] = params.contactNumber;
		user["userType"] = params.userType;
		user["privileges"] = params.privileges;
		user["loginId"] = params.loginId;
		user["parentUserId"] = params.parentUserId;
		user["password"] = params.password;
		user["timezoneOffset"] = -19800000;
		if (params.locationId) {
			user["locationId"] = params.locationId;
		}
		user["createdAt"] = currentTime;
		user["updatedAt"] = currentTime;
		user["createdBy"] = ctx.session.userId;
		user["updatedBy"] = ctx.session.userId;
		const userModel = require("../models/user")(ctx);
		const userResult = await userModel.create(user);
		return ctx.ok(userResult);
	},
	bulkCreate: async (ctx) => {
		/* if (!ctx.session.companyId) {
			return ctx.ok({status: false, msg: "Session expired, login again."});
		} */
		// const path = require("path");
		const fs = require("fs");
		// const start = new Date().getTime();
		try {
			const uploadedFilePath = ctx.request.fields.upload[0].path;
			for (let loop = 0; loop < ctx.request.files.length; loop++) {
				if (ctx.request.files[loop].path != uploadedFilePath) {
					fs.unlinkSync(ctx.request.files[loop].path);
				}
			}
			if (!uploadedFilePath) {
				return ctx.ok({status: false, msg: "Parameter(s) missing."});
			}
			const XLSX = require("xlsx-style");
			let requiredJson = null;
			const workbook = XLSX.readFile(uploadedFilePath);
			const first_sheet_name = workbook.SheetNames[0];
			const worksheet = workbook.Sheets[first_sheet_name];
			requiredJson = XLSX.utils.sheet_to_json(worksheet);
			fs.unlinkSync(uploadedFilePath);
			if (!requiredJson) {
				return ctx.ok({status: false, msg: "Uploaded file was empty or had data in unrecognised format."});
			}
			const validatorService = require("../services/bulkValidationService")(ctx);
			const validatedResult = await validatorService.validateUsers(requiredJson, ctx.session.userId, "5eb2d65f5bbfeb46054a93b0");
			if (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {
				return ctx.ok({
					status: false,
					msg: "Uploaded file was empty or had data in unrecognised format.",
				});
			} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {
				return ctx.ok({
					status: true,
					msg: "",
					outcome: validatedResult.outcome,
					successCount: 0,
				});
			} else {
				const userModel = require("../models/user")(ctx);
				const userResult = await userModel.createBulk(validatedResult.docs);
				if (!userResult.status) {
					return ctx.ok({status: false, msg: "Illegal or invalid values."});
				}
				for (var loop = 0; loop < userResult.result.outcome.length; loop++) {
					validatedResult.outcome[validatedResult.ref[loop]] = userResult.result.outcome[loop];
				}
				const userResult2 = await userModel.getAllCompanyUsers("5eb2d65f5bbfeb46054a93b0");
				if (userResult2.status) {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: userResult.result.successCount,
						docs: userResult2.docs,
					});
				} else {
					return ctx.ok({
						status: true,
						msg: "",
						outcome: validatedResult.outcome,
						successCount: userResult.result.successCount,
					});
				}
			}
		} catch (err) {
			return ctx.ok({status: false, msg: "Illegal or invalid values."});
		}
	},
	userProfile: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const model = require("../models/user")(ctx);
		const result = await model.details({_id: userId}, {userName: 1, userEmail: 1, contactNumber: 1, userType: 1, locationId: 1});
		return ctx.ok(result);
	},
};
