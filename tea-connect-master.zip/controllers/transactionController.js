module.exports = {
	updateMuster: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const sellerId = ctx.request.fields.sellerId;
		const season = ctx.request.fields.season;
		const markId = ctx.request.fields.markId;
		const records = ctx.request.fields.records;
		const _id = ctx.request.fields._id;
		if (!(sellerId && season && markId && records)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const clientModel = require("../models/seller")(ctx);
		const clientResult = await clientModel.infoWithMetadata(sellerId);
		if (clientResult.doc.sellers.length != 1) {
			return ctx.ok({status: false, msg: "Invalid seller selected."});
		}
		const _ = require("lodash");
		const numberPattern = /\d+/g;
		const client = clientResult.doc.sellers[0];
		const markIds = _.map(client.marks, "_id");
		for (let loop=0, length = markIds.length; loop<length; loop++) {
			markIds[loop] = markIds[loop].toHexString();
		}
		const gradeIds = _.map(clientResult.doc.grades, "_id");
		for (let loop=0, length = gradeIds.length; loop<length; loop++) {
			gradeIds[loop] = gradeIds[loop].toHexString();
		}
		if (markIds.indexOf(markId)<0) {
			return ctx.ok({status: false, msg: "Invalid mark selected."});
		}
		const keys = [];
		const invoices = [];
		for (let loop=0, length = records.length; loop<length; loop++) {
			const gradeId = records[loop].gradeId;
			let invNo = records[loop].invNo;
			let mfgDate = records[loop].mfgDate;
			let noOfPkg = records[loop].noOfPkg;
			let netPerPkg = records[loop].netPerPkg;
			let invSeason = records[loop].season;
			if (!(gradeId && invNo && mfgDate && noOfPkg)) {
				return ctx.ok({status: false, msg: "Invalid records."});
			}
			invNo = invNo.trim().toUpperCase();
			if (!invNo) {
				return ctx.ok({status: false, msg: "Invalid invoice number in records."});
			}
			const _arr = invNo.match(numberPattern);
			if ((!_arr) || (_arr.length<1)) {
				return ctx.ok({status: false, msg: "Invalid invoice number in records."});
			}
			if (gradeIds.indexOf(gradeId)<0) {
				return ctx.ok({status: false, msg: "Invalid grade in records."});
			}
			if (isNaN(mfgDate)) {
				return ctx.ok({status: false, msg: "Invalid mfg date in records."});
			}
			if (isNaN(noOfPkg)) {
				return ctx.ok({status: false, msg: "Invalid number of packages in records."});
			} else {
				noOfPkg = Number(noOfPkg);
			}
			if (netPerPkg) {
				if (isNaN(netPerPkg)) {
					return ctx.ok({status: false, msg: "Invalid net per package in records."});
				} else {
					netPerPkg = Number(netPerPkg);
				}
			}
			mfgDate = new Date(mfgDate);
			if (invSeason) {
				if (isNaN(invSeason)) {
					return ctx.ok({status: false, msg: "Invalid season in records."});
				} else {
					invSeason = Number(invSeason);
				}
			} else {
				invSeason = mfgDate.getFullYear();
				if (mfgDate.getMonth()<1) {
					invSeason --;
				}
			}
			const key = `${season}_${markId}_${invNo}`;
			keys.push(key);
			const row = {
				// companyId: ctx.ObjectId,
				season: invSeason,
				markId: markId,
				gradeId: gradeId,
				noOfPkg: noOfPkg,
				mfgDate: mfgDate,
				invNo: invNo,
				_invNo: Number(_arr[0]),
				key: key,
			};
			if (netPerPkg) {
				row.netPerPkg = netPerPkg;
			}
			invoices.push(row);
		}
		// const _ = require("lodash");

		const invoiceModel = require("../models/invoice")(ctx);
		const invoiceResult = await invoiceModel.getIds(invoices, keys);
		if (!invoiceResult.status) {
			return ctx.ok(invoiceResult);
		}
		const now = new Date();
		const muster = {
			// companyId: clientId,
			markId: markId,
			season: season,
			invoices: [],
			status: "PENDING",
			createdAt: now,
			updatedAt: now,
			createdBy: userId,
			updatedBy: userId,
		};
		for (let loop=0, length = invoiceResult.docs.length; loop<length; loop++) {
			muster.invoices.push({id: invoiceResult.docs[loop]._id});
		}
		if (_id) {
			muster._id = _id;
		}
		const model = require("../models/muster")(ctx);
		const result = await model.update(muster);
		if (!result.status) {
			return ctx.ok({status: false, msg: result.msg});
		}
		return ctx.ok({status: true, msg: "OK", doc: {_id: result.doc._id, createdAt: result.doc.createdAt.getTime()}});
	},
	pendingMusterForClient: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const clientId = ctx.request.fields.clientId;
		if (!clientId) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const model = require("../models/muster")(ctx);
		const result = await model.listPendingForClient(clientId);
		if (result.status) {
			for (let loop=0, length = result.docs.length; loop<length; loop++) {
				if (result.docs[loop].tastingDate) {
					result.docs[loop].tastingDate = result.docs[loop].tastingDate.getTime();
				}
				if (result.docs[loop].createdAt) {
					result.docs[loop].createdAt = result.docs[loop].createdAt.getTime();
				}
			}
		}
		return ctx.ok(result);
	},
	pendingMusterSummary: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const ids = ctx.request.fields.ids;
		if (!ids) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		for (let loop=0, length = ids.length; loop<length; loop++) {
			ids[loop] = ctx.ObjectID(ids[loop]);
		}
		const model = require("../models/muster")(ctx);
		const result = await model.list({_id: {$in: ids}, status: "PENDING"});
		if (result.status) {
			for (let loop=0, length = result.docs.length; loop<length; loop++) {
				if (result.docs[loop].tastingDate) {
					result.docs[loop].tastingDate = result.docs[loop].tastingDate.getTime();
				}
				if (result.docs[loop].createdAt) {
					result.docs[loop].createdAt = result.docs[loop].createdAt.getTime();
				}
			}
		}
		return ctx.ok(result);
	},
	musterDetails: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const musterId = ctx.request.fields.musterId;
		if (!musterId) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const model = require("../models/muster")(ctx);
		const result = await model.details(musterId);
		if (result.status) {
			for (let loop=0, length = result.doc.invoices.length; loop<length; loop++) {
				if (result.doc.invoices[loop].mfgDate) {
					result.doc.invoices[loop].mfgDate = result.doc.invoices[loop].mfgDate.getTime();
				}
			}
		}
		return ctx.ok(result);
	},
	updateAssignment: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const musterId = ctx.request.fields.musterId;
		const assignedTo = ctx.request.fields.assignedTo;
		let tastingDate = ctx.request.fields.tastingDate;
		if (!(musterId && assignedTo && tastingDate)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		if (isNaN(tastingDate)) {
			return ctx.ok({status: false, msg: "Invalid tasting date."});
		}
		tastingDate = new Date(Number(tastingDate));
		if (assignedTo.length==0) {
			return ctx.ok({status: false, msg: "Invalid assignee."});
		}
		const model = require("../models/muster")(ctx);
		const result = await model.updateAssignment(musterId, tastingDate, assignedTo, userId);
		return ctx.ok(result);
	},
	auctionDetails: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const _id = ctx.request.fields.auctionId;
		const locationId = ctx.request.fields.locationId;
		const saleNum = ctx.request.fields.saleNum;
		const season = ctx.request.fields.season;
		if ((!_id) && (!(locationId && saleNum && season))) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		if (season && isNaN(season)) {
			return ctx.ok({status: false, msg: "Invalid Season"});
		}
		const input = {};
		if (_id) {
			input._id = _id;
		} else {
			input.locationId = locationId;
			input.saleNum = saleNum.toUpperCase();
			input.season = Number(season);
		}
		const model = require("../models/auction")(ctx);
		const result = await model.details(input);
		if (result.status) {
			for (let loop=0, length = result.doc.invoices.length; loop<length; loop++) {
				// if (result.doc.invoices[loop].mfgDate) {
				//	result.doc.invoices[loop].mfgDate = result.doc.invoices[loop].mfgDate.getTime();
				// }
				delete result.doc.invoices[loop].mfgDate;
			}
		}
		return ctx.ok(result);
	},
	updateAuction: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const locationId = ctx.request.fields.locationId;
		const saleNum = ctx.request.fields.saleNum;
		const season = ctx.request.fields.season;
		const records = ctx.request.fields.records;
		const status = ctx.request.fields.status || "PENDING";
		const _id = ctx.request.fields._id;
		if (!(locationId && saleNum && season && records)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		if (isNaN(season)) {
			return ctx.ok({status: false, msg: "Invalid Season."});
		}
		if (["PENDING", "RECORDED", "PUBLISHED"].indexOf(status)<0) {
			return ctx.ok({status: false, msg: "Invalid status."});
		}
		const markModel = require("../models/mark")(ctx);
		const markResult = await markModel.listWithGrades();
		if (!markResult.status) {
			return ctx.ok({status: false, msg: "Invalid records."});
		}
		const _ = require("lodash");
		const numberPattern = /\d+/g;
		// const markIds = _.map(markResult.doc.marks, "_id");
		const markMap = {};
		for (let loop=0, length = markResult.doc.marks.length; loop<length; loop++) {
			markResult.doc.marks[loop].companyId = markResult.doc.marks[loop].companyId.toHexString();
			markMap[markResult.doc.marks[loop]._id.toHexString()] = markResult.doc.marks[loop];
		}
		const gradeIds = _.map(markResult.doc.grades, "_id");
		for (let loop=0, length = gradeIds.length; loop<length; loop++) {
			gradeIds[loop] = gradeIds[loop].toHexString();
		}
		const keys = [];
		const invoices = [];
		for (let loop=0, length = records.length; loop<length; loop++) {
			const gradeId = records[loop].gradeId;
			const markId = records[loop].markId;
			let lotNum = records[loop].lotNum;
			let invNo = records[loop].invNo;
			const invSeason = records[loop].season;
			// let mfgDate = records[loop].mfgDate;
			let noOfPkg = records[loop].noOfPkg;
			let netPerPkg = records[loop].netPerPkg;
			let avlKg = records[loop].avlKg;
			if (!(gradeId && markId && lotNum && invNo && invSeason && noOfPkg)) {
				return ctx.ok({status: false, msg: "Invalid records."});
			}
			lotNum = lotNum.trim().toUpperCase();
			if (!lotNum) {
				return ctx.ok({status: false, msg: "Invalid lot number in records."});
			}
			const _lotNum = Number(lotNum);
			if (isNaN(_lotNum)) {
				return ctx.ok({status: false, msg: "Invalid lot number in records."});
			}
			invNo = invNo.trim().toUpperCase();
			if (!invNo) {
				return ctx.ok({status: false, msg: "Invalid invoice number in records."});
			}
			const _arr = invNo.match(numberPattern);
			if ((!_arr) || (_arr.length<1)) {
				return ctx.ok({status: false, msg: "Invalid invoice number in records."});
			}
			if (!markMap[markId]) {
				return ctx.ok({status: false, msg: "Invalid mark selected."});
			}
			if (gradeIds.indexOf(gradeId)<0) {
				return ctx.ok({status: false, msg: "Invalid grade in records."});
			}
			if ((!invSeason) || isNaN(invSeason)) {
				return ctx.ok({status: false, msg: "Invalid season in records."});
			}
			if (isNaN(noOfPkg)) {
				return ctx.ok({status: false, msg: "Invalid number of packages in records."});
			} else {
				noOfPkg = Number(noOfPkg);
			}
			if (netPerPkg) {
				if (isNaN(netPerPkg)) {
					return ctx.ok({status: false, msg: "Invalid net per package in records."});
				} else {
					netPerPkg = Number(netPerPkg);
				}
			}
			if (avlKg) {
				if (isNaN(avlKg)) {
					return ctx.ok({status: false, msg: "Invalid gross kgs in records."});
				} else {
					avlKg = Number(avlKg);
				}
			}
			/* mfgDate = new Date(mfgDate);
			let season = mfgDate.getFullYear();
			if (mfgDate.getMonth()<1) {
				season --;
			} */
			const key = `${season}_${markId}_${invNo}`;
			keys.push(key);
			const row = {
				companyId: markMap[markId].companyId,
				season: Number(invSeason),
				markId: markId,
				gradeId: gradeId,
				noOfPkg: noOfPkg,
				// mfgDate: mfgDate,
				invNo: invNo,
				_invNo: Number(_arr[0]),
				lotNum: lotNum,
				_lotNum: _lotNum,
				// avlKg: avlKg,
				key: key,
			};
			if (netPerPkg) {
				row.netPerPkg = netPerPkg;
			}
			if (status != "PENDING") {
				if (records[loop].status) {
					row.status = ""+records[loop].status;
					row.status = row.status.trim().toUpperCase();
					var _price = records[loop].price;
					if (!isNaN(_price)) {
						row.price = Number(_price);
					}
					if (records[loop].buyer) {
						row.buyer = records[loop].buyer;
					}
					if (avlKg) {
						row.avlKg = avlKg;
					}
				}
			}
			invoices.push(row);
		}
		const invoiceModel = require("../models/invoice")(ctx);
		const invoiceResult = await invoiceModel.getIds(invoices, keys);
		if (!invoiceResult.status) {
			return ctx.ok(invoiceResult);
		}
		const now = new Date();
		const auction = {
			auctionCenter: locationId,
			saleNum: saleNum,
			season: season,
			invoices: [],
			status: status,
			createdAt: now,
			updatedAt: now,
			createdBy: userId,
			updatedBy: userId,
		};
		for (let loop=0, length = invoiceResult.docs.length; loop<length; loop++) {
			invoiceResult.docs[loop].id = invoiceResult.docs[loop]._id;
			delete invoiceResult.docs[loop]._id;
			delete invoiceResult.docs[loop].companyId;
			delete invoiceResult.docs[loop].season;
			delete invoiceResult.docs[loop].markId;
			delete invoiceResult.docs[loop].gradeId;
			delete invoiceResult.docs[loop].noOfPkg;
			delete invoiceResult.docs[loop].mfgDate;
			delete invoiceResult.docs[loop].invNo;
			delete invoiceResult.docs[loop]._invNo;
			delete invoiceResult.docs[loop].key;
			delete invoiceResult.docs[loop].netPerPkg;
			auction.invoices.push(invoiceResult.docs[loop]);
		}
		auction.invoices = _.sortBy(auction.invoices, ["_lotNum"]);
		if (_id) {
			auction._id = _id;
		}
		const model = require("../models/auction")(ctx);
		const result = await model.update(auction);
		if (!result.status) {
			return ctx.ok({status: false, msg: result.msg});
		}
		return ctx.ok({status: true, msg: "OK", doc: {
			_id: result.doc._id,
			auctionCenter: result.doc.auctionCenter,
			saleNum: result.doc.saleNum,
			season: result.doc.season,
		}});
	},
	updateAuctionAssignment: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const auctionId = ctx.request.fields.auctionId;
		const assignedTo = ctx.request.fields.assignedTo;
		let tastingDate = ctx.request.fields.tastingDate;
		if (!(auctionId && assignedTo && tastingDate)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		if (isNaN(tastingDate)) {
			return ctx.ok({status: false, msg: "Invalid tasting date."});
		}
		tastingDate = new Date(Number(tastingDate));
		if (assignedTo.length==0) {
			return ctx.ok({status: false, msg: "Invalid assignee."});
		}
		const model = require("../models/auction")(ctx);
		const result = await model.updateAssignment(auctionId, tastingDate, assignedTo, userId);
		return ctx.ok(result);
	},
	listAuctionInvoices: async (ctx) => {
		let userId = ctx.session.userId;
		if (!userId) {
			// use jwt here
			userId = "";
		}
		if (!userId) {
			return ctx.ok({status: false, msg: "Invalid request."});
		}
		const _id = ctx.request.fields.auctionId;
		const auctionCenter = ctx.request.fields.locationId;
		const status = ctx.request.fields.status;
		const season = ctx.request.fields.season;
		if (!(status && season)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		if (season && isNaN(season)) {
			return ctx.ok({status: false, msg: "Invalid Season"});
		}
		const input = {};
		if (_id) {
			input._id = _id;
		} else {
			input.status = status.toUpperCase();
			input.season = Number(season);
			if (auctionCenter) {
				input.auctionCenter = auctionCenter;
			}
		}
		const model = require("../models/auction")(ctx);
		const result = await model.list(input);
		if (result.status) {
			for (let loop=0, length = result.docs.length; loop<length; loop++) {
				if (result.docs[loop].tastingDate) {
					result.docs[loop].tastingDate = result.docs[loop].tastingDate.getTime();
				}
			}
		}
		return ctx.ok(result);
	},
	listCompanyLite: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const model = require("../models/seller")(ctx);
		const result = await model.listWithPendingMuster(userId);
		if (result.status && ctx.request.fields.tokenExpired) {
			result.token = ctx.request.fields.token;
		}
		return ctx.ok(result);
	},
	listTastingParams: async (ctx) => {
		const companyId = ctx.session.companyId || ctx.request.fields.companyId;
		if (!(companyId)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const model = require("../models/tastingParam")(ctx);
		let result = await model.listSorted();
		if (!result.status) {
			return ctx.ok(result);
		}
		const docs = result.docs;
		result = await model.categoryMapping();
		if (result.status) {
			result.docs = docs;
			if (ctx.request.fields.tokenExpired) {
				result.token = ctx.request.fields.token;
			}
		}
		return ctx.ok(result);
	},
	updateTastingParam: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const companyId = ctx.session.companyId || ctx.request.fields.companyId;
		if (!(ctx.request.fields.name && ctx.request.fields.values)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		let enableNotes = ctx.request.fields.enableNotes;
		if (!enableNotes) {
			enableNotes = false;
		} else {
			enableNotes = true;
		}
		let copyGradesByType = ctx.request.fields.copyGradesByType;
		if (!copyGradesByType) {
			copyGradesByType = false;
		} else {
			copyGradesByType = true;
		}
		const notes = ctx.request.fields.notes;
		const suggestions = ctx.request.fields.suggestions;
		const _id = ctx.request.fields._id;
		let slno = ctx.request.fields.slno;
		if (slno) {
			slno = Number(slno);
			if (isNaN(slno)) {
				return ctx.ok({status: false, msg: "Invalid Sl no."});
			}
		}
		const name = ctx.request.fields.name;
		const values = ctx.request.fields.values;
		const now = new Date();
		const input = {
			_id: _id,
			slno: slno,
			name: name.trim().toUpperCase(),
			values: values,
			enableNotes: enableNotes,
			copyGradesByType: copyGradesByType,
		};
		if (notes) {
			input.notes = notes;
		}
		if (suggestions) {
			input.suggestions = suggestions;
		}
		if (!_id) {
			input.companyId = companyId;
			input.createdAt = now;
			input.createdBy = userId;
			input.isActive = true;
		} else {
			input.isActive = ctx.request.fields.isActive;
		}
		input.updatedAt = now;
		input.updatedBy = userId;
		const model = require("../models/tastingParam")(ctx);
		const result = await model.update(input);
		if (result.status && ctx.request.fields.tokenExpired) {
			result.token = ctx.request.fields.token;
		}
		return ctx.ok(result);
	},
	musterInvoicesForTasting: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const clientId = ctx.request.fields.clientId;
		const markName = ctx.request.fields.mark;
		const musterIds = ctx.request.fields.musterIds;
		if (!(clientId && markName && musterIds)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const musterModel = require("../models/muster")(ctx);
		const musterResult = await musterModel.listWithDetails(musterIds);
		if (!musterResult.status) {
			return ctx.ok(musterResult);
		}
		if (musterResult.docs.length ==0) {
			return ctx.ok({status: false, msg: "No records found", docs: []});
		}
		const gradeModel = require("../models/grade")(ctx);
		const gradeResult = await gradeModel.list({}, {code: 1, slno: 1, subType: 1});
		if (!gradeResult.status) {
			return ctx.ok(gradeResult);
		}
		const gradeMap = {};
		const _ = require("lodash");
		let grades = gradeResult.docs;
		grades = _.sortBy(grades, ["slno"]);
		const _grades = [];
		for (let loop=0, length = grades.length; loop<length; loop++) {
			grades[loop]._slno = loop+1;
			gradeMap[grades[loop]._id] = loop;
			_grades.push([]);
		}
		const invoices = [];
		for (let loop=0, length = musterResult.docs.length; loop<length; loop++) {
			const doc = musterResult.docs[loop];
			doc.mark = markName;
			const gradePos = gradeMap[doc.gradeId];
			doc.grade = grades[gradePos].code;
			doc.gradeType = grades[gradePos].subType;
			doc.mfgDate = doc.mfgDate.getTime();
			delete doc.markId;
			delete doc.gradeId;
			delete doc._invNo;
			_grades[gradePos].push(doc);
		}
		for (let loop=0, length = _grades.length; loop<length; loop++) {
			const arr = _grades[loop];
			for (let inner=0, innerLength = arr.length; inner<innerLength; inner++) {
				invoices.push(arr[inner]);
			}
		}
		if (ctx.request.fields.tokenExpired) {
			return ctx.ok({status: true, msg: "OK", docs: invoices, token: ctx.request.fields.token});
		}
		return ctx.ok({status: true, msg: "OK", docs: invoices});
	},
	pendingAuctionInvoice: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const dt = new Date();
		let _season = dt.getFullYear();
		if (dt.getMonth==0) {
			_season--;
		}
		const model = require("../models/auction")(ctx);
		const result = await model.listPendingForUser(_season, userId);
		if (result.status && ctx.request.fields.tokenExpired) {
			result.token = ctx.request.fields.token;
		}
		return ctx.ok(result);
	},
	auctionInvoicesForTasting: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const auctionId = ctx.request.fields.auctionId;
		if (!(auctionId)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const auctionModel = require("../models/auction")(ctx);
		const auctionResult = await auctionModel.listWithDetails(auctionId);
		if (!auctionResult.status) {
			return ctx.ok(auctionResult);
		}
		if (auctionResult.docs.length ==0) {
			return ctx.ok({status: true, msg: "OK", docs: []});
		}
		const gradeModel = require("../models/grade")(ctx);
		const gradeResult = await gradeModel.listWithMarks();
		if (!gradeResult.status) {
			return ctx.ok(gradeResult);
		}
		const gradeMap = {};
		const markMap = {};
		const _ = require("lodash");
		let grades = gradeResult.doc.grades;
		grades = _.sortBy(grades, ["slno"]);
		const marks = gradeResult.doc.marks;
		const _grades = [];
		for (let loop=0, length = grades.length; loop<length; loop++) {
			grades[loop]._slno = loop+1;
			gradeMap[grades[loop]._id] = loop;
			_grades.push([]);
		}
		for (let loop=0, length = marks.length; loop<length; loop++) {
			markMap[marks[loop]._id.toHexString()] = loop;
		}
		// const invoices = [];
		for (let loop=0, length = auctionResult.docs.length; loop<length; loop++) {
			const doc = auctionResult.docs[loop];
			const markPos = markMap[doc.markId.toHexString()];
			doc.mark = marks[markPos].name;
			const gradePos = gradeMap[doc.gradeId];
			doc.grade = grades[gradePos].code;
			doc.gradeType = grades[gradePos].subType;
			doc.gradeSlno = grades[gradePos].slno;
			if (doc.mfgDate) {
				doc.mfgDate = doc.mfgDate.getTime();
			}
			delete doc.markId;
			delete doc.gradeId;
			// _grades[gradePos].push(doc);
		}
		/* for (let loop=0, length = _grades.length; loop<length; loop++) {
			const arr = _grades[loop];
			for (let inner=0, innerLength = arr.length; inner<innerLength; inner++) {
				invoices.push(arr[inner]);
			}
		} */
		const returnObj = {status: true, msg: "OK", docs: auctionResult.docs};
		if (ctx.request.fields.tokenExpired) {
			returnObj.token = ctx.request.fields.token;
		}
		return ctx.ok(returnObj);
	},
	saveTastingReport: async (ctx) => {
		const companyId = ctx.session.companyId || ctx.request.fields.companyId;
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const musterIds = ctx.request.fields.musterIds;
		const auctionId = ctx.request.fields.auctionId;
		const financeId = ctx.request.fields.financeId;
		const privateSaleId = ctx.request.fields.privateSaleId;
		const clientId = ctx.request.fields.clientId;
		const invoices = ctx.request.fields.invoices;
		const suggestions = ctx.request.fields.suggestions || [];
		const summary = ctx.request.fields.summary;
		const location = ctx.request.fields.location;
		let reportId = ctx.request.fields.reportId;
		if (!(invoices && summary)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const docs = [];
		if (suggestions.length>0) {
			const model = require("../models/tastingParam")(ctx);
			model.updateSuggestions(suggestions);
		}
		const now = new Date();
		const today = new Date();
		today.setHours(0, 0, 0, 0);
		const report = {
			companyId: clientId,
			date: today,
			// type: "MUSTER",
			// musterIds: musterIds,
			invoices: [],
			summary: summary,
			tastingCompany: companyId,
			createdBy: userId,
			updatedBy: userId,
			createdAt: now,
		};
		if (musterIds) {
			report.type = "MUSTER";
			report.musterIds = musterIds;
		} else if (auctionId) {
			report.type = "AUCTION";
			report.auctionId = auctionId;
			delete report.companyId;
		} else if (financeId) {
			report.type = "FINANCE";
			report.financeId = financeId;
		} else if (privateSaleId) {
			report.type = "PVT-SALE";
			report.privateSaleId = privateSaleId;
		}
		let hasPriceIdea = false;
		let isConsolidated = false;
		// const hasPriceIdeaRules = false;
		for (let loop=0, length = invoices.length; loop<length; loop++) {
			let priceIdea = invoices[loop].priceIdea?Number(invoices[loop].priceIdea):0;
			if (isNaN(priceIdea) || (priceIdea<0)) {
				priceIdea = 0;
			}
			if (priceIdea) {
				hasPriceIdea = true;
			}
			if (invoices[loop].isConsolidated) {
				isConsolidated = true;
			}
			const obj = {
				mfgDate: invoices[loop].mfgDate,
				id: invoices[loop]._id || invoices[loop].id,
				// markId: invoices[loop].markId,
				// gradeId: invoices[loop].gradeId,
				invNo: invoices[loop].invNo,
				// breakNumber: invoices[loop].breakNumber,
				// samplingId: invoices[loop].samplingId,
				mark: invoices[loop].mark,
				grade: invoices[loop].grade,
				gradeType: invoices[loop].gradeType,
				// invPrefix: invoices[loop].invPrefix,
				manuallyAdded: invoices[loop].manuallyAdded,
				remarks: invoices[loop].remarks,
				values: invoices[loop].values,
				priceIdea: priceIdea,
			};
			if (!obj.id) {
				delete obj.id;
			}
			if (invoices[loop].lotNum) {
				obj.lotNum = invoices[loop].lotNum;
			}
			/* if (!obj.markId) {
				delete obj.markId;
			}
			if (!obj.gradeId) {
				delete obj.gradeId;
			}
			if (!obj.samplingId) {
				delete obj.samplingId;
			} */
			if (!obj.manuallyAdded) {
				delete obj.manuallyAdded;
			}
			report.invoices.push(obj);
		}
		report.hasPriceIdea = hasPriceIdea;
		if (location) {
			report.location = location;
		}
		const model = require("../models/tastingReport")(ctx);
		let result = null;
		report.version = 1;
		if (reportId) {
			report._id = reportId;
		}
		if (isConsolidated) {
			// report.isConsolidated = true;
			// result = await model.updateConsolidated(musterIds, report);
		} else {
			result = await model.update(report);
		}
		if (!result.status) {
			return ctx.ok(result);
		}
		reportId = result.doc._id;
		const service = require("../services/pdfExportService")(ctx);
		service.generateTastingReport(reportId);
		delete result.doc;
		result.docs = docs;
		if (ctx.request.fields.tokenExpired) {
			result.token = ctx.request.fields.token;
		}
		return ctx.ok(result);
	},
	searchTastingReport: async (ctx) => {
		const companyId = ctx.session.userId || ctx.request.fields.companyId;
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const reportType = ctx.request.fields.reportType;
		const clientId = ctx.request.fields.clientId;
		const markId = ctx.request.fields.markId;
		const locationId = ctx.request.fields.locationId;
		let start = ctx.request.fields.start;
		let end = ctx.request.fields.end;
		if (!(reportType && start && end)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		start = Number(start);
		end = Number(end);
		if (isNaN(start)) {
			return ctx.ok({status: false, msg: "Invalid date."});
		}
		if (isNaN(end)) {
			return ctx.ok({status: false, msg: "Invalid date."});
		}
		if ((end - start) > (31 * 24 * 60 * 60 * 1000)) {
			return ctx.ok({status: false, msg: "Date range must be less than 1 months"});
		}
		start = new Date(start);
		end = new Date(end);
		start.setHours(0, 0, 0, 0);
		end.setHours(23, 59, 59, 999);
		const query = {
			type: reportType,
			// companyId: clientId,
			date: {
				$gte: start,
				$lte: end,
			},
			// tastingCompany: agencyId,
		};
		if (reportType == "MUSTER") {
			// query.companyId = ctx.ObjectID(clientId);
			if (clientId) {
				query.companyId = clientId;
			}
			if (markId) {
				query.markId = markId;
			}
		} else if (reportType == "AUCTION") {
			if (locationId) {
				query.locationId = locationId;
			}
		}
		if (clientId && (companyId == clientId)) {
			query.published = true;
			// delete query.tastingCompany;
			// query.$or = [{tastingCompany: companyId}, {published: true}];
		}
		const projection = {date: 1, tastedBy: 1, tastingCompany: 1, published: 1};
		if (reportType == "MUSTER") {
			projection.invoices = 1;
			projection.companyId = 1;
		} else if (reportType == "AUCTION") {
			projection.saleNum = 1;
			projection.auctionCenter = 1;
		}
		const model = require("../models/tastingReport")(ctx);
		const result = await model.list(query, projection);
		if (!result.status) {
			return ctx.ok(result);
		}
		const list = [];
		if (result.docs.length > 0) {
			const userModel = require("../models/user")(ctx);
			const userResult = await userModel.listUsersWithCenters();
			if (!userResult.status) {
				return ctx.ok(result);
			}
			const userMap = {};
			for (let loop=0, length = userResult.doc.users.length; loop<length; loop++) {
				userMap[userResult.doc.users[loop]._id.toHexString()] = userResult.doc.users[loop].userName;
			}
			const locationMap = {};
			if (reportType == "AUCTION") {
				for (let loop=0, length = userResult.doc.centers.length; loop<length; loop++) {
					locationMap[userResult.doc.centers[loop]._id.toHexString()] = userResult.doc.centers[loop].code;
				}
			}
			const moment = require("moment");
			for (let loop=0, length= result.docs.length; loop<length; loop++) {
				result.docs[loop].date = moment(result.docs[loop].date).format("ddd, MMM Do YYYY");
				const tastedBy = result.docs[loop].tastedBy;
				const _tastedBy = [];
				let mark = "";
				if (tastedBy) {
					for (let inner=0, innerLen= tastedBy.length; inner<innerLen; inner++) {
						const name = userMap[tastedBy[inner].toHexString()];
						if (name) {
							_tastedBy.push(name);
						}
					}
				} else {
					_tastedBy.push("");
				}
				if (reportType == "MUSTER") {
					const _invoices = result.docs[loop].invoices;
					for (let inner=0, innerLen= _invoices.length; inner<innerLen; inner++) {
						if (_invoices[inner].id) {
							mark = _invoices[inner].mark;
							break;
						}
					}
					delete result.docs[loop].invoices;
					result.docs[loop].addlDisplay = mark;
				} else if (reportType == "AUCTION") {
					result.docs[loop].addlDisplay = `${locationMap[result.docs[loop].auctionCenter]} ${result.docs[loop].saleNum}`;
					delete result.docs[loop].locationId;
					delete result.docs[loop].saleNum;
				}
				result.docs[loop].tastedBy = _tastedBy.join(", ");
				list.push(result.docs[loop]);
			}
			const returnObj = {
				status: true,
				msg: "OK",
				docs: list,
			};
			if (ctx.request.fields.tokenExpired) {
				returnObj.token = ctx.request.fields.token;
			}
			return ctx.ok(returnObj);
		} else {
			return ctx.ok({
				status: true,
				msg: "No records found for the given criteria",
				docs: [],
			});
		}
	},
	tastingReportDetails: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const reportId = ctx.request.fields.reportId;
		if (!(reportId)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const model = require("../models/tastingReport")(ctx);
		const result = await model.details({_id: reportId});
		if (!result.status) {
			return ctx.ok(result);
		}
		for (let loop=0, length = result.doc.invoices.length; loop<length; loop++) {
			const invoice = result.doc.invoices[loop];
			invoice.display = {};
			const values = invoice.values;
			for (let inner=0, innerlen = values.length; inner<innerlen; inner++) {
				invoice.display[values[inner].param] = values[inner].label?values[inner].label:"--";
			}
		}
		result.doc.summary.display = {};
		const values = result.doc.summary.values;
		const summaryRemarksArray = [];
		for (let inner=0, innerlen = values.length; inner<innerlen; inner++) {
			result.doc.summary.display[values[inner].param] = values[inner].label?values[inner].label:"--";
			if (values[inner].remarks && (values[inner].remarks.length>0) && values[inner].remarks[0]) {
				summaryRemarksArray.push(values[inner].remarks[0]);
			}
		}
		if (result.doc.summary.analysis) {
			result.doc.summary.display["analysis"] = result.doc.summary.analysis;
		}
		if (summaryRemarksArray.length>0) {
			result.doc.summary.remarks = summaryRemarksArray.join(", ");
		}
		result.doc.date = result.doc.date.getTime();
		if (ctx.request.fields.tokenExpired) {
			result.token = ctx.request.fields.token;
		}
		return ctx.ok(result);
	},
	tastingVersion: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		return ctx.ok({status: true, msg: "OK", versionCode: icplApp.tastingAppVersionCode, apk: `teaconnect-${icplApp.tastingAppVersionName}.apk`});
	},
	updatePublishReport: async (ctx) => {
		const userId = ctx.session.userId || ctx.request.fields.userId;
		if (!userId) {
			return ctx.unauthorized({status: false, msg: "Invalid Request"});
		}
		const reportId = ctx.request.fields.reportId;
		if (!(reportId)) {
			return ctx.ok({status: false, msg: "Parameter(s) missing."});
		}
		const model = require("../models/tastingReport")(ctx);
		const result = await model.updatePublish(reportId, userId);
		return ctx.ok(result);
	},
	downloadTastingReportPdf: async (ctx) => {
		const reportId = ctx.request.fields.reportId;
		if (!reportId) {
			ctx.badRequest({status: false, msg: "parameter(s) missing"});
		}
		const fs = require("fs");
		const path = require("path");
		const model = require("../models/tastingReport")(ctx);
		const modelResult = await model.details({_id: reportId}, {docNum: 1, pdfPath: 1});
		if (!(modelResult.status && modelResult.doc)) {
			return ctx.notFound({status: false, msg: "File not found"});
		}
		if (!modelResult.doc.pdfPath) {
			const service = require("../services/pdfExportService")(ctx);
			const result = await service.generateTastingReport(reportId);
			if (!result.status) {
				return ctx.notFound({status: false, msg: "File not found"});
			}
			modelResult.doc.pdfPath = result.path;
		}
		const filePath = path.join(icplApp.appPath, modelResult.doc.pdfPath);
		if (!fs.existsSync(filePath)) {
			return ctx.notFound({status: false, msg: "File not found"});
		}
		ctx.body = fs.createReadStream(filePath);
		ctx.set("Content-type", "application/pdf");
		ctx.attachment(`${modelResult.docNum}.pdf`);
	},
	downloadMergedTastingReportPdf: async (ctx) => {
		let reportIds = ctx.request.fields.reports;
		if (!(reportIds)) {
			ctx.body = null;
			return;
		}
		if (typeof reportIds === "string" || reportIds instanceof String) {
			reportIds = JSON.parse(reportIds);
		}
		const colors = ["#391285", "#033500", "#d1001c", "#420303", "#3b2820"];
		const model = require("../models/tastingReport")(ctx);
		const result = await model.listMerged(reportIds);
		if (!result.status) {
			ctx.body = null;
			return;
		}
		const invoices = result.docs;
		if (invoices.length==0) {
			ctx.body = null;
			return;
		}
		const userIds = [];
		const usedColors = [];
		const gradeModel = require("../models/grade")(ctx);
		const gradeResult = await gradeModel.list({}, {code: 1});
		if (!gradeResult.status) {
			ctx.body = null;
			return;
		}
		const _grades = [""];
		for (let loop=0, length = gradeResult.docs.length; loop<length; loop++) {
			_grades.push(gradeResult.docs[loop].code);
		}
		// const _grades = JSON.parse(JSON.stringify(GRADE_ARRAY));
		const grade2d = [];
		const gradeMap = {};

		for (let loop=0, length = _grades.length; loop<length; loop++) {
			grade2d.push([]);
			gradeMap[_grades[loop]] = loop;
		}
		/* let lastMark = "";
		let lastPackingDate = "";
		let lastGrade = ""; */
		const moment = require("moment");
		const headers = [""];
		const headerWidths = [20];
		const paramNames = [];
		for (let loop=0, length = invoices.length; loop<length; loop++) {
			const grade = invoices[loop]._id.grade;
			if (!grade) {
				continue;
			}
			if (!gradeMap[grade]) {
				grade2d.push([]);
				gradeMap[grade] = grade2d.length -1;
			}
			const pos = gradeMap[grade];
			const mark = invoices[loop]._id.mark;
			const pkgDt = invoices[loop].reports[0].pkgDt;
			// let inv = `${invoices[loop]._id.prefix}${invoices[loop]._id.invNumber} ${grade}`;
			// let inv = `${mark} ${invoices[loop]._id.prefix}${invoices[loop]._id.invNumber} ${grade}`;
			let inv = `${mark} ${invoices[loop]._id.invNo} ${grade}`;
			if (pkgDt) {
				inv = `${inv} ${moment(pkgDt).format("DD/MM/YY")}`;
			}
			/* if ((lastMark != mark) || (lastGrade != grade) || (lastPackingDate != pkgDt)) {
				inv = `${mark} ${inv}`;
				if (pkgDt) {
					inv = `${inv} ${moment(pkgDt).format("DD/MM/YY")}`;
				}
			} */
			const _rows = [];
			for (let inner =0, innerLen = invoices[loop].reports.length; inner<innerLen; inner++) {
				const userId = invoices[loop].reports[inner].taster.toHexString();
				let color = "#000000";
				let uPos = userIds.indexOf(userId);
				if (uPos<0) {
					userIds.push(userId);
					uPos = userIds.length -1;
					if (userIds.length<=colors.length) {
						color = colors[userIds.length -1];
					}
					usedColors.push(color);
				}
				color = usedColors[uPos];
				_rows.push({color: color, values: invoices[loop].reports[inner].values, remarks: invoices[loop].reports[inner].remarks});
				if (loop==0 && inner==0) {
					for (let vLoop=0, vLength = invoices[loop].reports[inner].values.length; vLoop<vLength; vLoop++) {
						if (vLoop>4) {
							continue;
						}
						headers.push(invoices[loop].reports[inner].values[vLoop].param);
						headerWidths.push("auto");
						paramNames.push(invoices[loop].reports[inner].values[vLoop].param);
					}
				}
			}
			grade2d[pos].push({
				inv: inv,
				rows: _rows,
			});
			/* lastPackingDate = pkgDt;
			lastMark = mark;
			lastGrade = grade; */
		}
		headers.push({text: "REMARKS", alignment: "right"});
		headerWidths.push("*");
		const userModel = require("../models/user")(ctx);
		const userResult = await userModel.listUsersWithLocations(userIds);
		if (!userResult.status) {
			ctx.body = null;
			return;
		}
		const userMap = {};
		for (let loop=0, length = userResult.doc.users.length; loop<length; loop++) {
			userMap[userResult.doc.users[loop]._id.toHexString()] = {name: userResult.doc.users[loop].userName, company: global.hostCompanyName};
		}
		const masterContent = [];
		for (let loop = 0, length = userIds.length; loop < length; loop++) {
			const userId = userIds[loop];
			masterContent.push({
				columns: [{
					svg: `<svg width="20" height="10"><rect width="20" height="10" style="fill:${usedColors[loop]}" /></svg>`,
					width: 40,
				}, {
					text: `  ${userMap[userId].name} (${userMap[userId].company})`,
					width: "*",
				}],
			});
		}
		masterContent.push({text: " ", margin: [10, 10, 10, 10]});
		const tableBody = [];
		tableBody.push(headers);
		for (let outer = 0, outerLength = grade2d.length; outer<outerLength; outer++) {
			const records = grade2d[outer];
			for (let loop=0, length = records.length; loop<length; loop++) {
				tableBody.push([{text: records[loop].inv, bold: true, colSpan: headers.length}]);
				for (let inner =0, innerLen = records[loop].rows.length; inner<innerLen; inner++) {
					const _row = [""];
					for (let pLoop=0, pLen = paramNames.length; pLoop<pLen; pLoop++) {
						_row.push({text: "", color: records[loop].rows[inner].color});
					}
					for (let vLoop=0, vLen = records[loop].rows[inner].values.length; vLoop<vLen; vLoop++) {
						const currParam = records[loop].rows[inner].values[vLoop].param;
						const index = paramNames.indexOf(currParam);
						if (index<0) {
							continue;
						}
						if (vLoop>4) {
							continue;
						}
						if (records[loop].rows[inner].values[vLoop].val) {
							_row[index+1].text = ""+records[loop].rows[inner].values[vLoop].val;
						}
					}
					const remark = records[loop].rows[inner].remarks || "";
					_row.push({text: remark, color: records[loop].rows[inner].color});
					tableBody.push(_row);
				}
			}
		}
		masterContent.push({
			layout: "headerLineOnly",
			table: {
				headerRows: 1,
				widths: headerWidths,
				body: tableBody,
			},
		});
		// console.log(JSON.stringify(masterContent));
		const docDefinition = {
			pageSize: "A4",
			pageMargins: [30, 30, 30, 30],
			footer: function(currentPage, pageCount) {
				return {columns: [
					{text: `Page ${currentPage} of ${pageCount}`, fontSize: 11, alignment: "left", margin: [30, 0, 0, 0]},
					{text: "Powered by - TEAlink", fontSize: 11, alignment: "right", margin: [0, 0, 30, 0], link: "https://illimitable.in/tealink.html"},
				]};
			},
			info: {
				title: "Merged Report",
				author: "TEAlink by Illimitable",
				subject: "Merged Report",
				creator: "TEAlink by Illimitable",
				producer: "TEAlink by Illimitable",
			},
			content: masterContent,
		};
		const fonts = {
			Roboto: {
				normal: "assets/fonts/Roboto-Regular.ttf",
				bold: "assets/fonts/Roboto-Medium.ttf",
				italics: "assets/fonts/Roboto-Italic.ttf",
				bolditalics: "assets/fonts/Roboto-MediumItalic.ttf",
			},
		};
		const PdfPrinter = require("pdfmake/src/printer");
		const printer = new PdfPrinter(fonts);
		const pdfDoc = printer.createPdfKitDocument(docDefinition);
		ctx.set("Content-type", "application/pdf");
		const PassThrough = require("stream").PassThrough;
		ctx.body = pdfDoc.pipe(PassThrough());
		pdfDoc.end();
	},
	_downloadTastingReportXLSX: async (ctx) => {
		const reportId = ctx.request.fields.reportId;
		if (!(reportId)) {
			ctx.body = null;
			return;
		}
		const reportModel = require("../models/tastingReport")(ctx);
		const reportResult = await reportModel.printingDetails(reportId);
		if (!reportResult.status) {
			ctx.body = null;
			return;
		}
		const report = reportResult.doc;
		try {
			const moment = require("moment");
			const XLSX = require("xlsx-style");
			// const workbook = new XLSX.Workbook();
			const workbook = {SheetNames: [], Sheets: {}};
			const main = {};
			const availableColumnCount = 7 + report.invoices[0].values.length;
			const _columnNames = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
			let rowCount = 1;
			const boldStyle = {
				alignment: {
					wrapText: 1,
					horizontal: "center",
				},
				font: {
					name: "Verdana",
					sz: 10,
					bold: true,
				},
			};
			const normalStyle = {
				alignment: {
					wrapText: 1,
					horizontal: "center",
				},
				font: {
					name: "Verdana",
					sz: 10,
				},
			};
			main["A" + rowCount] = {
				v: "LOT NO",
				s: boldStyle,
				t: "s",
			};
			main["B" + rowCount] = {
				v: "INVOICE",
				s: boldStyle,
				t: "s",
			};
			main["C" + rowCount] = {
				v: "GRADE",
				s: boldStyle,
				t: "s",
			};
			main["D" + rowCount] = {
				v: "PRICE IDEA",
				s: boldStyle,
				t: "s",
			};
			main["E" + rowCount] = {
				v: "PKG DT",
				s: boldStyle,
				t: "s",
			};
			let currColCount = 5;
			for (let loop=0, length = report.invoices[0].values.length; loop<length; loop++) {
				main[_columnNames[currColCount] + rowCount] = {
					v: report.invoices[0].values[loop].param,
					s: boldStyle,
					t: "s",
				};
				currColCount++;
			}
			main[_columnNames[currColCount] + rowCount] = {
				v: "TOTAL",
				s: boldStyle,
				t: "s",
			};
			main[_columnNames[currColCount+1] + rowCount] = {
				v: "REMARKS",
				s: boldStyle,
				t: "s",
			};
			for (let loop=0, length= report.invoices.length; loop<length; loop++) {
				rowCount++;
				main["A" + rowCount] = {
					v: ""+(report.invoices[loop].lotNumber?report.invoices[loop].lotNumber:""),
					s: normalStyle,
					t: "s",
				};
				/* let invNum = "";
				if (report.invoices[loop].invPrefix) {
					invNum = report.invoices[loop].invPrefix;
				} */
				main["B" + rowCount] = {
					v: ""+report.invoices[loop].invNo,
					s: normalStyle,
					t: "s",
				};
				main["C" + rowCount] = {
					v: ""+report.invoices[loop].grade,
					s: normalStyle,
					t: "s",
				};
				main["D" + rowCount] = {
					v: ""+(report.invoices[loop].priceIdea?report.invoices[loop].priceIdea:"0"),
					s: normalStyle,
					t: "s",
				};
				let pkgDt = "";
				if (report.invoices[loop].mfgDate) {
					pkgDt = moment(report.invoices[loop].mfgDate).format("DD/MM");
				}
				main["E" + rowCount] = {
					v: pkgDt,
					s: normalStyle,
					t: "s",
				};
				let currColCount = 5;
				let valTotal = 0;
				for (let loop2=0, length2 = report.invoices[loop].values.length; loop2<length2; loop2++) {
					let val = "";
					if (report.invoices[loop].values[loop2].val) {
						val = ""+report.invoices[loop].values[loop2].val;
						// valTotal += report.invoices[loop].values[loop2].val;
						if (!isNaN(report.invoices[loop].values[loop2].val)) {
							valTotal += Number(report.invoices[loop].values[loop2].val);
						}
					}
					main[_columnNames[currColCount] + rowCount] = {
						v: val,
						s: normalStyle,
						t: "s",
					};
					currColCount++;
				}
				if (!valTotal) {
					valTotal = "";
				}
				main[_columnNames[currColCount+1] + rowCount] = {
					v: ""+(report.invoices[loop].remarks?report.invoices[loop].remarks:""),
					s: normalStyle,
					t: "s",
				};
			}
			/* const wscols = [{wch: 40}, {wch: 15}, {wch: 15}, {wch: 15}, {wch: 12}, {wch: 12}, {wch: 12},
				{wch: 20}, {wch: 15}, {wch: 25}, {wch: 12}, {wch: 12}, {wch: 10}, {wch: 40}, {wch: 25}, {wch: 25},
				{wch: 25}, {wch: 25}, {wch: 25}, {wch: 40}, {wch: 40}];
			main["!cols"] = wscols; */
			main["!ref"] = `A1:${_columnNames[availableColumnCount]}` + (rowCount + 1);
			workbook.SheetNames.push("main");
			workbook.Sheets["main"] = main;
			const wbout = XLSX.write(workbook, {bookType: "xlsx", bookSST: true, type: "buffer"});
			ctx.body = wbout;
			ctx.set("Content-type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			ctx.attachment(`${report.docNum}.xlsx`);
		} catch (err) {
			ctx.body = null;
			return;
		}
	},
	downloadTastingReportXLSX: async (ctx) => {
		const reportId = ctx.request.fields.reportId;
		if (!(reportId)) {
			ctx.body = null;
			return;
		}
		const reportModel = require("../models/tastingReport")(ctx);
		const reportResult = await reportModel.spreadSheetDetails(reportId);
		if (!reportResult.status) {
			ctx.body = null;
			return;
		}
		const invoices = reportResult.docs;
		try {
			const XLSX = require("xlsx-style");
			const workbook = {SheetNames: [], Sheets: {}};
			const main = {};
			let availableColumnCount = 14 + invoices[0].values.length;
			let hasLotNumber = false;
			if (invoices[0].lotNum) {
				availableColumnCount ++;
				hasLotNumber = true;
			}
			const _columnNames = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
			const headers = ["Season", "Tasting Date", "Garden", "Initial", "Inv/Batch", "Category", "Grade", "PKGS", "KGS", "MFG Date", "Valuation", "Valuation To"];
			const _values= invoices[0].values;
			for (let inner=0, innerLength = _values.length; inner<innerLength; inner++) {
				headers.push(_values[inner].param);
			}
			headers.push("Garden Category");
			headers.push("Remarks");
			let rowCount = 1;
			/* const boldStyle = {
				alignment: {
					wrapText: 1,
					horizontal: "center",
				},
				font: {
					name: "Verdana",
					sz: 10,
					bold: true,
				},
			}; */
			/* const normalStyle = {
				font: {
					name: "Verdana",
					sz: 9,
				},
			}; */
			let clmPtr = 0;
			for (let loop=0, length = headers.length; loop<length; loop++) {
				// main[_columnNames[clmPtr]+rowCount] = {v: headers[loop], t: "s", s: normalStyle};
				main[_columnNames[clmPtr]+rowCount] = {v: headers[loop], t: "s"};
				if ((loop==3) && hasLotNumber) {
					clmPtr++;
					// main[_columnNames[clmPtr]+rowCount] = {v: "Lot No", t: "s", s: normalStyle};
					main[_columnNames[clmPtr]+rowCount] = {v: "Lot No", t: "s"};
				}
				clmPtr++;
			}
			const rows = ["season", "tastingDate", "mark", "user", "invNo", "category", "grade", "noOfPkg", "totalKgs", "mfgDate", "priceIdea"];
			const rowsDataType = ["n", "d", "s", "s", "s", "s", "s", "n", "n", "d", "n"];
			for (let loop=0, length= invoices.length; loop<length; loop++) {
				const invoice = invoices[loop];
				if (!invoice.user) {
					continue;
				}
				clmPtr = 0;
				rowCount++;
				for (let rLoop=0, rLength = rows.length; rLoop<rLength; rLoop++) {
					if (invoice[rows[rLoop]]) {
						// main[_columnNames[clmPtr]+rowCount] = {v: invoice[rows[rLoop]], t: rowsDataType[rLoop], s: normalStyle};
						main[_columnNames[clmPtr]+rowCount] = {v: invoice[rows[rLoop]], t: rowsDataType[rLoop]};
					}
					if ((rLoop==3) && hasLotNumber) {
						clmPtr++;
						// main[_columnNames[clmPtr]+rowCount] = {v: invoice.lotNum, t: "s", s: normalStyle};
						main[_columnNames[clmPtr]+rowCount] = {v: invoice.lotNum, t: "s"};
					}
					clmPtr++;
				}
				// main[_columnNames[clmPtr]+rowCount] = {v: 0, t: "n", s: normalStyle};
				main[_columnNames[clmPtr]+rowCount] = {v: 0, t: "n"};
				clmPtr++;
				const _values= invoice.values;
				for (let inner=0, innerLength = _values.length; inner<innerLength; inner++) {
					if (_values[inner].val) {
						// main[_columnNames[clmPtr]+rowCount] = {v: _values[inner].val, t: "n", s: normalStyle};
						main[_columnNames[clmPtr]+rowCount] = {v: _values[inner].val, t: "n"};
					}
					clmPtr++;
				}
				clmPtr++;
				// main[_columnNames[clmPtr]+rowCount] = {v: invoice.remarks, t: "s", s: normalStyle};
				main[_columnNames[clmPtr]+rowCount] = {v: invoice.remarks, t: "s"};
			}
			main["!ref"] = `A1:${_columnNames[availableColumnCount]}` + (rowCount + 1);
			workbook.SheetNames.push("main");
			workbook.Sheets["main"] = main;
			const wbout = XLSX.write(workbook, {bookType: "xlsx", bookSST: true, type: "buffer"});
			ctx.body = wbout;
			ctx.set("Content-type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			ctx.attachment("report.xlsx");
		} catch (err) {
			ctx.body = null;
			return;
		}
	},
	downloadLatestTastingApk: (ctx) =>{
		return ctx.redirect(`/teaconnect-${icplApp.tastingAppVersionName}.apk`);
	},
};
