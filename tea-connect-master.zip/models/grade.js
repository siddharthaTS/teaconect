module.exports = (ctx) => {
	return {
		attributes: {
			name: {
				type: "STRING",
				min: 1,
				max: 15,
				transform: "UPPERCASE",
			},
			suffix: {
				type: "STRING",
				max: 15,
				transform: "UPPERCASE",
			},
			code: {
				type: "STRING",
				min: 1,
				max: 15,
				transform: "UPPERCASE",
			},
			slno: {
				type: "NUMBER",
				min: 1,
				max: 999,
				label: "Order SLNo",
			},
			category: {
				type: "OBJECTID",
				label: "Tea Category",
			},
			subCategory: {
				type: "OBJECTID",
				label: "Sub Category",
			},
			type: {
				type: "STRING",
				min: 1,
				max: 1,
				transform: "UPPERCASE",
			},
			subType: {
				type: "STRING",
				min: 1,
				max: 1,
				transform: "UPPERCASE",
				label: "Sub Type",
			},
		},
		metadata: {
			name: "grade",
			plural: "grades",
			collection: "grade",
		},
		create: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				}
				if (input.companyId) {
					input.companyId = ctx.ObjectID(input.companyId);
				}
				if (input.createdBy) {
					input.createdBy = ctx.ObjectID(input.createdBy);
				}
				if (input.updatedBy) {
					input.updatedBy = ctx.ObjectID(input.updatedBy);
				}
				if (input.category) {
					input.category = ctx.ObjectID(input.category);
				}
				if (input.subCategory) {
					input.subCategory = ctx.ObjectID(input.subCategory);
				}
				await ctx.mongo.collection("grade").insertOne(input);
				const sequenceResult = await ctx.mongo.collection("sequence").findOneAndUpdate({_id: "GR"}, {$inc: {value: 1}}, {
					returnOriginal: false, projection: {value: 1},
				});
				input.code = ""+sequenceResult.value.value;
				input.code = "GR"+ (input.code.padStart(4, "0"));
				ctx.mongo.collection("grade").findOneAndUpdate({_id: input._id}, {$set: {code: input.code}});
				return {status: true, msg: "grade created", doc: input};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		update: async (id, values, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						suffix: 1,
						code: 1,
						slno: 1,
						category: 1,
						subCategory: 1,
						type: 1,
						subType: 1,
						isActive: 1,
					};
				}
				if (values.companyId) {
					values.companyId = ctx.ObjectID(values.companyId);
				}
				if (values.createdBy) {
					values.createdBy = ctx.ObjectID(values.createdBy);
				}
				if (values.updatedBy) {
					values.updatedBy = ctx.ObjectID(values.updatedBy);
				}
				if (values.category) {
					values.category = ctx.ObjectID(values.category);
				}
				if (values.subCategory) {
					values.subCategory = ctx.ObjectID(values.subCategory);
				}
				const updateObj = {$set: values};
				const result = await ctx.mongo.collection("grade").findOneAndUpdate({
					_id: ctx.ObjectID(id),
				}, updateObj, {
					returnOriginal: false, projection: projection,
				});
				return {status: true, msg: "grade updated", doc: result.value};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		bulkCreate: async (docs) => {
			try {
				const sequence = await ctx.mongo.collection("sequence").findOne({_id: "GR"});
				let sequenceVal = sequence.value;
				const bulk = ctx.mongo.collection("grade").initializeUnorderedBulkOp();
				const indexes = [];
				const messages = [];
				const outcome = [];
				let writeErrors = [];
				for (var loop = 0; loop < docs.length; loop++) {
					sequenceVal++;
					outcome.push("Record inserted successfully.");
					docs[loop].code = ""+sequenceVal;
					if (docs[loop].code) {
						docs[loop].code = "GR"+ (docs[loop].code.padStart(4, "0"));
					}
					if (docs[loop].companyId) {
						docs[loop].companyId = ctx.ObjectID(docs[loop].companyId);
					}
					if (docs[loop].createdBy) {
						docs[loop].createdBy = ctx.ObjectID(docs[loop].createdBy);
					}
					if (docs[loop].updatedBy) {
						docs[loop].updatedBy = ctx.ObjectID(docs[loop].updatedBy);
					}
					bulk.insert(docs[loop]);
				}
				try {
					const result = await bulk.execute();
					writeErrors = result.getWriteErrors();
				} catch (err) {
					writeErrors = err.result.getWriteErrors();
				}
				ctx.mongo.collection("sequence").findOneAndUpdate({_id: "GR"}, {$set: {value: sequenceVal}});
				if (writeErrors.length == 0) {
					return {status: true, msg: "OK", result: {outcome: outcome, successCount: outcome.length}};
				}
				const innerLength = indexes.length;
				for (let loop = 0, length = writeErrors.length; loop < length; loop++) {
					let matchFound = false;
					for (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {
						if (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {
							outcome[writeErrors[loop].index] = messages[innerLoop];
							matchFound = true;
							break;
						}
					}
					if (!matchFound) {
						outcome[writeErrors[loop].index] = "Record not inserted.";
					}
				}
				return {status: true, msg: "OK", result: {outcome: outcome, successCount: (outcome.length - writeErrors.length)}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						suffix: 1,
						code: 1,
						slno: 1,
						category: 1,
						subCategory: 1,
						type: 1,
						subType: 1,
						isActive: 1,
					};
				}
				const docs = await ctx.mongo.collection("grade").find(query, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		details: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						code: 1,
						slno: 1,
						category: 1,
						subCategory: 1,
						type: 1,
						subType: 1,
						isActive: 1,
					};
				}
				const doc = await ctx.mongo.collection("grade").findOne(query, {projection: projection});
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithMarks: async () => {
			try {
				const docs = await ctx.mongo.collection("grade").aggregate([
					{$project: {code: 1, slno: 1, subType: 1}},
					{$group: {_id: null, grades: {$push: "$$ROOT"}}},
					{$lookup: {from: "mark", pipeline: [
						{$project: {name: 1, code: 1}},
					], as: "marks"}},
				]).toArray();
				if (docs.length !=1) {
					return {status: true, msg: "Ok", doc: {grades: [], marks: []}};
				}
				return {status: true, msg: "Ok", doc: docs[0]};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
