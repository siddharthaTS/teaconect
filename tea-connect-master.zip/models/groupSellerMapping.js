module.exports = (ctx) => {
	return {
		attributes: {
			group: {
				type: "OBJECTID",
				label: "Group Code",
			},
			seller: {
				type: "OBJECTID",
				label: "Seller Code",
			},
			dateFrom: {
				label: "Date From",
				type: "DATE",
			},
			dateTo: {
				label: "Date To",
				type: "DATE",
			},
		},
		metadata: {
			name: "groupSellerMapping",
			plural: "groupSellerMappings",
			collection: "groupsellermapping",
		},
		create: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				}
				if (input.seller) {
					input.seller = ctx.ObjectID(input.seller);
				}
				if (input.group) {
					input.group = ctx.ObjectID(input.group);
				}
				await ctx.mongo.collection("groupsellermapping").insertOne(input);
				return {status: true, msg: "mapping created", doc: input};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		update: async (id, values, projection) => {
			try {
				if (!projection) {
					projection={
						group: 1,
						seller: 1,
						dateFrom: 1,
						dateTo: 1,
						isActive: 1,
					};
				}
				if (values.seller) {
					values.seller = ctx.ObjectID(values.seller);
				}
				if (values.group) {
					values.group = ctx.ObjectID(values.group);
				}
				const updateObj = {$set: values};
				const result = await ctx.mongo.collection("groupsellermapping").findOneAndUpdate({
					_id: ctx.ObjectID(id),
				}, updateObj, {
					returnOriginal: false, projection: projection,
				});
				return {status: true, msg: "mapping updated", doc: result.value};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		bulkCreate: async (docs) => {
			try {
				const bulk = ctx.mongo.collection("groupsellermapping").initializeUnorderedBulkOp();
				const indexes = [];
				const messages = [];
				const outcome = [];
				let writeErrors = [];
				for (var loop = 0; loop < docs.length; loop++) {
					outcome.push("Record inserted successfully.");
					if (docs[loop].companyId) {
						docs[loop].companyId = ctx.ObjectID(docs[loop].companyId);
					}
					if (docs[loop].createdBy) {
						docs[loop].createdBy = ctx.ObjectID(docs[loop].createdBy);
					}
					if (docs[loop].updatedBy) {
						docs[loop].updatedBy = ctx.ObjectID(docs[loop].updatedBy);
					}
					bulk.insert(docs[loop]);
				}
				try {
					const result = await bulk.execute();
					writeErrors = result.getWriteErrors();
				} catch (err) {
					writeErrors = err.result.getWriteErrors();
				}
				if (writeErrors.length == 0) {
					return {status: true, msg: "OK", result: {outcome: outcome, successCount: outcome.length}};
				}
				const innerLength = indexes.length;
				for (let loop = 0, length = writeErrors.length; loop < length; loop++) {
					let matchFound = false;
					for (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {
						if (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {
							outcome[writeErrors[loop].index] = messages[innerLoop];
							matchFound = true;
							break;
						}
					}
					if (!matchFound) {
						outcome[writeErrors[loop].index] = "Record not inserted.";
					}
				}
				return {status: true, msg: "OK", result: {outcome: outcome, successCount: (outcome.length - writeErrors.length)}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						group: 1,
						seller: 1,
						dateFrom: 1,
						dateTo: 1,
						isActive: 1,
					};
				}
				const docs = await ctx.mongo.collection("groupsellermapping").find(query, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		details: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						group: 1,
						seller: 1,
						dateFrom: 1,
						dateTo: 1,
						isActive: 1,
					};
				}
				const doc = await ctx.mongo.collection("groupsellermapping").findOne(query, {projection: projection});
				return {status: true, msg: "Ok", doc: doc};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["dateFrom"]) {
						docs[loop]["dateFrom"] = docs[loop]["dateFrom"].getTime();
					}
					if (docs[loop]["dateTo"]) {
						docs[loop]["dateTo"] = docs[loop]["dateTo"].getTime();
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["dateFrom"]) {
						docs[loop]["dateFrom"] = new Date(docs[loop]["dateFrom"]);
					}
					if (docs[loop]["dateTo"]) {
						docs[loop]["dateTo"] = new Date(docs[loop]["dateTo"]);
					}
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
