module.exports = (ctx) => {
	return {
		update: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				} else {
					input._id = ctx.ObjectID(input._id);
				}
				if (input.companyId) {
					input.companyId = ctx.ObjectID(input.companyId);
				}
				if (input.createdBy) {
					input.createdBy = ctx.ObjectID(input.createdBy);
				}
				if (input.updatedBy) {
					input.updatedBy = ctx.ObjectID(input.updatedBy);
				}
				if (input.values) {
					let _val = [];
					for (let loop=0, length = input.values.length; loop<length; loop++) {
						if (!input.values[loop].name) {
							continue;
						}
						if (!input.values[loop].id) {
							input.values[loop].id = new ctx.ObjectID().toHexString();
						}
						input.values[loop].val = Number(input.values[loop].val);
						if (isNaN(input.values[loop].val)) {
							return {status: false, msg: "Invalid input"};
						}
						_val.push({id: input.values[loop].id, name: input.values[loop].name.trim().toTitleCase(), val: input.values[loop].val});
					}
					const _ = require("lodash");
					_val = _.sortBy(_val, ["val"]);
					input.values = _val;
				} else {
					input.values = [];
				}
				if (input.categories) {
					for (let loop=0, length = input.categories.length; loop<length; loop++) {
						input.categories[loop] = ctx.ObjectID(input.categories[loop]);
					}
				} else {
					input.categories = [];
				}
				if (!input.suggestions) {
					input.suggestions = [];
				}
				if (input.isActive == null) {
					input.isActive = true;
				}
				if (!input.slno) {
					if (!input.companyId) {
						return {status: false, msg: "Sl No is required"};
					}
					let _docs = await ctx.mongo.collection("tastingparam").aggregate([
						{$match: {companyId: input.companyId}},
						{$group: {_id: null, slno: {$max: "$slno"}}},
					]).toArray();
					if (_docs.length!=1) {
						_docs = [{slno: 0}];
					}
					input.slno = _docs[0].slno + 1;
				}
				await ctx.mongo.collection("tastingparam").findOneAndUpdate({_id: input._id}, {$set: input}, {upsert: true});
				delete input.companyId;
				delete input.createdAt;
				delete input.updatedAt;
				delete input.createdBy;
				delete input.updatedBy;
				return {status: true, msg: "Ok", doc: input};
			} catch (err) {
				let errMsg = "Encountered an unexpected error.";
				const indexes = ["name_1", "slno_1"];
				const messages = ["Name already in use", "Sl No already in use."];
				if (err.errmsg) {
					for (let innerLoop = 0, innerLength = indexes.length; innerLoop < innerLength; innerLoop++) {
						if (err.errmsg.indexOf(indexes[innerLoop]) >= 0) {
							errMsg = messages[innerLoop];
							break;
						}
					}
				}
				return {status: false, msg: errMsg};
			}
		},
		updateBulk: async (companyId, records) => {
			try {
				const doc = {};
				const bulk = ctx.mongo.collection("tastingparam").initializeUnorderedBulkOp();
				const now = new Date();
				for (let outerLoop=0, outerLength = records.length; outerLoop<outerLength; outerLoop++) {
					const input = records[outerLoop];
					for (let loop=0, length = input.values.length; loop<length; loop++) {
						if (input.values[loop].added) {
							doc[input.values[loop].id] = new ctx.ObjectID().toHexString();
							input.values[loop].id = doc[input.values[loop].id];
							delete input.values[loop].added;
						}
						input.values[loop].name = input.values[loop].name.trim().toTitleCase();
					}
					if (input.categories) {
						for (let loop=0, length = input.categories.length; loop<length; loop++) {
							input.categories[loop] = ctx.ObjectID(input.categories[loop]);
						}
					}
					const _ = require("lodash");
					input.values = _.sortBy(input.values, ["val"]);
					const obj = {values: input.values, updatedAt: now};
					if (input.notes) {
						obj.notes = input.notes;
					}
					bulk.find({_id: input._id}).update({$set: obj});
				}
				await bulk.execute();
				const projection={
					slno: 1,
					name: 1,
					isActive: 1,
					values: 1,
					suggestions: 1,
					readonly: 1,
					enableNotes: 1,
					notes: 1,
					categories: 1,
				};
				const docs = await ctx.mongo.collection("tastingparam").find({companyId: ctx.ObjectID(companyId)}, {projection: projection}).sort({slno: 1}).toArray();
				return {status: true, msg: "Ok", doc: doc, docs: docs};
			} catch (err) {
				let errMsg = "Encountered an unexpected error.";
				const indexes = ["name_1", "slno_1"];
				const messages = ["Name already in use", "Sl No already in use."];
				if (err.errmsg) {
					for (let innerLoop = 0, innerLength = indexes.length; innerLoop < innerLength; innerLoop++) {
						if (err.errmsg.indexOf(indexes[innerLoop]) >= 0) {
							errMsg = messages[innerLoop];
							break;
						}
					}
				}
				return {status: false, msg: errMsg};
			}
		},
		updateSuggestions: async (suggestions) => {
			try {
				const bulk = ctx.mongo.collection("tastingparam").initializeUnorderedBulkOp();
				const now = new Date();
				for (let outerLoop=0, outerLength = suggestions.length; outerLoop<outerLength; outerLoop++) {
					const input = suggestions[outerLoop];
					bulk.find({_id: ctx.ObjectID(input._id)}).update({$push: {suggestions: {$each: input.suggestions}}, $set: {updatedAt: now}});
				}
				await bulk.execute();
				return {status: true, msg: "Ok"};
			} catch (err) {
				let errMsg = "Encountered an unexpected error.";
				const indexes = ["name_1", "slno_1"];
				const messages = ["Name already in use", "Sl No already in use."];
				if (err.errmsg) {
					for (let innerLoop = 0, innerLength = indexes.length; innerLoop < innerLength; innerLoop++) {
						if (err.errmsg.indexOf(indexes[innerLoop]) >= 0) {
							errMsg = messages[innerLoop];
							break;
						}
					}
				}
				return {status: false, msg: errMsg};
			}
		},
		list: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						slno: 1,
						name: 1,
						isActive: 1,
						values: 1,
						suggestions: 1,
						readonly: 1,
						enableNotes: 1,
						notes: 1,
						categories: 1,
					};
				}
				const docs = await ctx.mongo.collection("tastingparam").find(query, {projection: projection}).sort({slno: 1}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listV2: async (companyId, projection) => {
			try {
				if (!projection) {
					projection={
						slno: 1,
						name: 1,
						isActive: 1,
						values: 1,
						suggestions: 1,
						readonly: 1,
						enableNotes: 1,
						notes: 1,
						copyGradesByType: 1,
					};
				}
				const docs = await ctx.mongo.collection("tastingparam").find({companyId: ctx.ObjectID(companyId)}, {projection: projection}).sort({slno: 1}).toArray();
				if (docs.length==0) {
					const now = new Date();
					docs.push({
						_id: new ctx.ObjectID(),
						companyId: ctx.ObjectID(companyId),
						createdAt: now,
						isActive: true,
						name: "LA",
						slno: 1,
						readonly: true,
						updatedAt: now,
						values: [],
						suggestions: [],
						enableNotes: true,
						notes: ["BROWN", "BROWNISH", "BLACK", "BLAKISH", "KHAKI", "GREY", "DULL"],
						copyGradesByType: true,
					});
					let _val = 4;
					while (_val<=7) {
						docs[0].values.push({
							id: new ctx.ObjectID().toHexString(),
							name: ""+_val,
							val: _val,
						});
						_val += 0.25;
					}
					docs.push({
						_id: new ctx.ObjectID(),
						companyId: ctx.ObjectID(companyId),
						createdAt: now,
						isActive: true,
						name: "INF",
						slno: 2,
						readonly: true,
						updatedAt: now,
						values: [],
						suggestions: [],
						enableNotes: true,
						notes: ["BRIGHT", "COPPERY", "GREENISH", "DULL", "DUAL", "TOUCH"],
						copyGradesByType: true,
					});
					_val = 4;
					while (_val<=7) {
						docs[1].values.push({
							id: new ctx.ObjectID().toHexString(),
							name: ""+_val,
							val: _val,
						});
						_val += 0.25;
					}
					docs.push({
						_id: new ctx.ObjectID(),
						companyId: ctx.ObjectID(companyId),
						createdAt: now,
						isActive: true,
						name: "LIQ",
						slno: 3,
						readonly: true,
						updatedAt: now,
						values: [],
						suggestions: [],
						enableNotes: true,
						notes: ["COLOURY", "YELLOW", "PINK", "BRIGHT", "DULL", "PALE", "THIN", "PINK", "SLATY", "TOUCH"],
						copyGradesByType: true,
					});
					_val = 4;
					while (_val<=7) {
						docs[2].values.push({
							id: new ctx.ObjectID().toHexString(),
							name: ""+_val,
							val: _val,
						});
						_val += 0.25;
					}
					await ctx.mongo.collection("tastingparam").insertMany(docs, {ordered: true});
					for (let loop=0, length = docs.length; loop<length; loop++) {
						delete docs[loop].companyId;
						delete docs[loop].createdAt;
						delete docs[loop].updatedAt;
					}
				} else {
					for (let loop=0, length = docs.length; loop<length; loop++) {
						if (!docs[loop].enableNotes) {
							docs[loop].enableNotes = false;
						}
						if (!docs[loop].notes) {
							docs[loop].notes = [];
						}
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listSorted: async () => {
			try {
				const docs = await ctx.mongo.collection("tastingparam").aggregate([
					{$match: {isActive: true}},
					{$project: {name: 1, slno: 1, values: 1, enableNotes: 1, notes: 1, copyGradesByType: 1}},
					{$unwind: "$values"},
					{$sort: {"_id": 1, "values.val": 1}},
					{$group: {_id: "$_id", name: {$first: "$name"}, slno: {$first: "$slno"}, values: {$push: "$values"}, enableNotes: {$first: "$enableNotes"}, notes: {$first: "$notes"}, copyGradesByType: {$first: "$copyGradesByType"}}},
					{$sort: {slno: 1}},
				]).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		categoryMapping: async () => {
			try {
				const docs = await ctx.mongo.collection("tastingparam").aggregate([
					{$project: {categories: 1, slno: 1}},
					{$unwind: "$categories"},
					{$sort: {categories: 1, slno: 1}},
					{$group: {_id: "$categories", params: {$push: "$_id"}}},
					{$lookup: {from: "category", let: {category_id: "$_id"}, pipeline: [
						{$match: {$expr: {$eq: ["$$category_id", "$_id"]}}},
						{$project: {name: 1, descriptiveRemarks: 1, _id: 0}},
					], as: "category"}},
					{$addFields: {category: {$arrayElemAt: ["$category", 0]}}},
				]).toArray();
				const mapping = {};
				for (let loop=0, length = docs.length; loop<length; loop++) {
					mapping[docs[loop]._id] = {params: docs[loop].params, category: docs[loop].category};
				}
				return {status: true, msg: "Ok", doc: mapping};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
