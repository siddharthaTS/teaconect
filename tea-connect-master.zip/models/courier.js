module.exports = (ctx) => {
	return {
		attributes: {
			name: {
				type: "STRING",
				min: 4,
				max: 80,
				transform: "TITLECASE",
				label: "courier Name",
			},

			code: {
				label: "Code No",
				type: "STRING",
				min: 10,
				max: 25,
				transform: "UPPERCASE",
			},
			cin: {
				label: "CIN No",
				type: "STRING",
				min: 10,
				max: 25,
				transform: "UPPERCASE",
			},
			url: {
				type: "BOOLEAN",
				label: "URL",
			},
			url_link: {
				type: "STRING",
				max: 80,
				label: "courier traking service url",
			},
		},
		metadata: {
			name: "courier",
			plural: "couriers",
			collection: "courier",
		},
		create: async (input) => {
			try {
				if (!input._id) {
					input._id = new ctx.ObjectID();
				}
				await ctx.mongo.collection("courier").insertOne(input);

				const sequenceResult = await ctx.mongo.collection("sequence").findOneAndUpdate({_id: "CM"}, {$inc: {value: 1}}, {
					returnOriginal: false, projection: {value: 1},
				});
				input.code = ""+sequenceResult.value.value;
				input.code = "CM"+ (input.code.padStart(4, "0"));
				ctx.mongo.collection("courier").findOneAndUpdate({_id: input._id}, {$set: {code: input.code}});

				return {status: true, msg: "courier created", doc: input};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		update: async (id, values, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						cin: 1,
						url: 1,
						url_link: 1,
						isActive: 1,
					};
				}
				const unset = {};
				// if ((values.isActive==null) || (values.isActive==undefined)) {
				// 	if ((values.fssaiNo == null ) || (values.fssaiNo == undefined ) || (values.fssaiNo == "" )) {
				// 		unset["fssaiNo"] = 1;
				// 		delete values.fssaiNo;
				// 	}
				// }
				const updateObj = {$set: values};
				if (Object.keys(unset).length>0) {
					updateObj["$unset"] = unset;
				}
				const result = await ctx.mongo.collection("courier").findOneAndUpdate({
					_id: ctx.ObjectID(id),
				}, updateObj, {
					returnOriginal: false, projection: projection,
				});
				return {status: true, msg: "courier updated", doc: result.value};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		bulkCreate: async (docs) => {
			try {
				const sequence = await ctx.mongo.collection("sequence").findOne({_id: "CM"});
				let sequenceVal = sequence.value;
				const bulk = ctx.mongo.collection("courier").initializeUnorderedBulkOp();
				const indexes = [];
				const messages = [];
				const outcome = [];
				let writeErrors = [];
				for (var loop = 0; loop < docs.length; loop++) {
					sequenceVal++;
					outcome.push("Record inserted successfully.");
					docs[loop].code = ""+sequenceVal;
					if (docs[loop].code) {
						docs[loop].code = "CM"+ (docs[loop].code.padStart(4, "0"));
					}
					if (docs[loop].companyId) {
						docs[loop].companyId = ctx.ObjectID(docs[loop].companyId);
					}
					if (docs[loop].createdBy) {
						docs[loop].createdBy = ctx.ObjectID(docs[loop].createdBy);
					}
					if (docs[loop].updatedBy) {
						docs[loop].updatedBy = ctx.ObjectID(docs[loop].updatedBy);
					}
					bulk.insert(docs[loop]);
				}
				try {
					const result = await bulk.execute();
					writeErrors = result.getWriteErrors();
				} catch (err) {
					writeErrors = err.result.getWriteErrors();
				}
				ctx.mongo.collection("sequence").findOneAndUpdate({_id: "CM"}, {$set: {value: sequenceVal}});
				if (writeErrors.length == 0) {
					return {status: true, msg: "OK", result: {outcome: outcome, successCount: outcome.length}};
				}
				const innerLength = indexes.length;
				for (let loop = 0, length = writeErrors.length; loop < length; loop++) {
					let matchFound = false;
					for (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {
						if (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {
							outcome[writeErrors[loop].index] = messages[innerLoop];
							matchFound = true;
							break;
						}
					}
					if (!matchFound) {
						outcome[writeErrors[loop].index] = "Record not inserted.";
					}
				}
				return {status: true, msg: "OK", result: {outcome: outcome, successCount: (outcome.length - writeErrors.length)}};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		list: async (query, projection) => {
			try {
				if (!projection) {
					projection={
						name: 1,
						code: 1,
						cin: 1,
						trackUrl: 1,
					};
				}
				const docs = await ctx.mongo.collection("courier").find(query, {projection: projection}).toArray();
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		listWithMarks: async () => {
			try {
				const docs = await ctx.mongo.collection("courier").aggregate([
					{$project: {name: 1, code: 1}},
					{$group: {_id: null, couriers: {$push: "$$ROOT"}}},
					{$lookup: {from: "location", pipeline: [{$project: {name: 1, code: 1}}], as: "locations"}},
				]).toArray();
				if (docs.length!=1) {
					return {status: true, msg: "Ok", doc: {locations: [], couriers: []}};
				} else {
					return {status: true, msg: "Ok", doc: docs[0]};
				}
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		serialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = docs[loop]["createdAt"].getTime();
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = docs[loop]["updatedAt"].getTime();
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
		deserialize: (docs) => {
			try {
				for (let loop=0, length=docs.length; loop<length; loop++) {
					if (docs[loop]["createdAt"]) {
						docs[loop]["createdAt"] = new Date(docs[loop]["createdAt"]);
					}
					if (docs[loop]["updatedAt"]) {
						docs[loop]["updatedAt"] = new Date(docs[loop]["updatedAt"]);
					}
				}
				return {status: true, msg: "Ok", docs: docs};
			} catch (err) {
				return {status: false, msg: "encountered an unexpected error."};
			}
		},
	};
};
