const _ = require("lodash");
//  const path = require("path");
const fs = require("fs");
const auth = require("basic-auth");
const compare = require("tsscmp");

const checkPrivilege = (session, privilegeName, requiredAccess) => {
	if (session && session.privileges) {
		const privilegeNames = Object.keys(session.privileges);
		let returnVal = false;
		for (let loop=0, length= privilegeNames.length; loop<length; loop++) {
			if (privilegeNames[loop]==privilegeName) {
				const access = session.privileges[privilegeName].access;
				const diff = _.difference(requiredAccess, access);
				if (diff.length != 0) {
					break;
				} else {
					returnVal = true;
				}
			} else if (session.privileges[privilegeNames[loop]].childNodes) {
				const innerPrivileges = session.privileges[privilegeNames[loop]].childNodes;
				if (innerPrivileges[privilegeName]) {
					const access = innerPrivileges[privilegeName].access;
					const diff = _.difference(requiredAccess, access);
					if (diff.length != 0) {
						break;
					} else {
						returnVal = true;
					}
				}
			}
		}
		return returnVal;
	} else {
		return false;
	}
};

// eslint-disable-next-line no-unused-vars
const cp = checkPrivilege;

const restrictedPaths = {
	/* "/home.html": {required: ["userId"], redirect: "/login.html"},
	"/login.html": {
		required: (session) => {
			if (session && session.userId) {
				return false;
			}
			return true;
		},
		redirect: "/home.html",
	},
	"/user-management.html": {
		required: (session) => {
			return cp(session, "user_management", ["view"]);
		}, redirect: "/login.html",
	}, */
};

const multipartPaths = {
	"/bulk-user-create.json": true,
	"/bulk-seller-create.json": true,
	"/bulk-buyer-create.json": true,
	"/bulk-courier-create.json": true,
	"/bulk-location-create.json": true,
	"/bulk-category-create.json": true,
	"/bulk-mark-create.json": true,
	"/bulk-grade-create.json": true,
	"/bulk-group-create.json": true,
	"/bulk-auction-center-create.json": true,
	"/bulk-group-seller-mapping.json": true,
	"/bulk-seller-mark-mapping.json": true,
	"/bulk-courier-address-mapping.json": true,
	"/bulk-group-seller-mapping-create.json": true,
	"/bulk-seller-mark-mapping-create.json": true,
	"/bulk-mark-entity-mapping-create.json": true,
};

const basicAuthParts = {
	"/sms-logs.html": {name: "admin", pass: "manager"},
};

module.exports = {
	policyHandler: async function(ctx, next) {
		/* if (ctx.session) {
			ctx.session.save();
		} */
		var path = ctx.path;
		if (!multipartPaths[path]) {
			const contentType = ctx.request.headers["content-type"];
			if (contentType && contentType.indexOf("multipart") >= 0) {
				if (ctx.request.files) {
					for (let loop = 0; loop < ctx.request.files.length; loop++) {
						fs.unlinkSync(ctx.request.files[loop].path);
					}
				}
			}
		}
		const authOptions = basicAuthParts[path];
		if (authOptions) {
			const user = auth(ctx);
			if (!user || (authOptions.name && !compare(authOptions.name, user.name)) || (authOptions.pass && !compare(authOptions.pass, user.pass))) {
				ctx.status = 401;
				ctx.set("WWW-Authenticate", "Basic");
				ctx.body = "Unauthorized Access";
				return;
			}
		}
		if (restrictedPaths[path]) {
			try {
				const required = restrictedPaths[path].required;
				if (required instanceof Array) {
					for (let loop = 0; loop < required.length; loop++) {
						if (!ctx.session[required[loop]]) {
							throw {};
						}
					}
				} else if (required instanceof Function) {
					const result = required(ctx.session);
					if (!result) {
						throw {};
					}
				}
			} catch (err) {
				const redirect = restrictedPaths[path].redirect;
				if (redirect) {
					throw {status: 403, redirect: redirect};
				} else {
					throw {status: 403, contextStatus: 200};
				}
			}
		}
		if (ctx.request && ctx.request.fields && ctx.request.fields.token) {
			try {
				let token = ctx.request.fields.token;
				let tokenExpired = false;
				let userId = "";
				let companyId = "";
				const jwt = require("jsonwebtoken");
				try {
					const decoded = jwt.verify(token, ctx.secret);
					userId = decoded._id;
					companyId = decoded.companyId;
					delete ctx.request.fields.token;
				} catch (err) {
					if (err.name=="TokenExpiredError") {
						try {
							const decoded = jwt.verify(token, ctx.secret, {ignoreExpiration: true});
							if (!decoded.renew) {
								return ctx.ok({status: false, msg: "Token expired"});
							}
							userId = decoded._id;
							companyId = decoded.companyId;
							token = jwt.sign({_id: userId}, ctx.secret, {expiresIn: "10h"});
							tokenExpired = true;
							ctx.request.fields.tokenExpired = tokenExpired;
							ctx.request.fields.token = token;
						} catch (err) {
							return ctx.unauthorized({status: false, msg: "Invalid Token."});
						}
					} else {
						return ctx.unauthorized({status: false, msg: "Invalid Token."});
					}
				}
				ctx.request.fields.userId = userId;
				ctx.request.fields.companyId = companyId;
			} catch (err) {
				return ctx.unauthorized({status: false, msg: "Invalid Request"});
			}
		}
		await next();
	},
};
