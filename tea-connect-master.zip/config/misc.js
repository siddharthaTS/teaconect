/* eslint no-extend-native:0 */

const crypto = require("crypto");
const algorithm = "aes-256-ctr";
// const password = "c3ffb5ba23b911e8b4670ed5f89f718b";
const password = "dd7e1a0e66c74618b9d2c9ab0d2f58cd";
const iv = "a47bfa1383d2f33d";

const encrypt = (text) => {
	var cipher = crypto.createCipheriv(algorithm, password, iv);
	var encrypted = cipher.update(text, "utf8", "hex");
	encrypted += cipher.final("hex");
	return encrypted;
};

const decrypt = (text) => {
	var decipher = crypto.createDecipheriv(algorithm, password, iv);
	var dec = decipher.update(text, "hex", "utf8");
	dec += decipher.final("utf8");
	return dec;
};

icplApp.encrypt = encrypt;
icplApp.decrypt = decrypt;

Date.prototype.getTimezoneOffsetMills = function() {
	return this.getTimezoneOffset() * 60 * 1000;
};

Date.prototype.getUTCTime = function() {
	return this.getTime() + (this.getTimezoneOffsetMills());
};

Date.prototype.setUTCTime = function(timeInMills) {
	timeInMills = timeInMills - this.getTimezoneOffsetMills();
	this.setTime(timeInMills);
};

Date.prototype.addDays = function(days) {
	this.setDate(this.getDate() + days);
};

Date.prototype.daysInMonth = function() {
	var d = new Date(this.getFullYear(), this.getMonth() + 1, 0);
	return d.getDate();
};

Date.prototype.getWeek = function() {
	var dt = new Date(this.getFullYear(), 0, 1);
	return Math.ceil((((this - dt) / 86400000) + dt.getDay()+1)/7);
};

String.prototype.toTitleCase = function() {
	return this.replace(
		/\w\S*/g,
		function(txt) {
			return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
		});
};

global.getDateOfISOWeek = function(w, y) {
	var simple = new Date(y, 0, 1 + (w - 1) * 7);
	var dow = simple.getDay();
	var ISOweekStart = simple;
	if (dow <= 4) {
		ISOweekStart.setDate(simple.getDate() - simple.getDay() + 1);
	} else {
		ISOweekStart.setDate(simple.getDate() + 8 - simple.getDay());
	}
	return ISOweekStart;
};

global.shortString = function(fullName) {
	const processed = [];
	try {
		const tokens = fullName.split(" ");
		const allowd = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
		for (let loop=0, length = tokens.length; loop<length; loop++) {
			var first = tokens[loop].charAt(0).toUpperCase();
			if (allowd.indexOf(first)>=0) {
				processed.push(first);
			}
		}
	} catch (err) {
		//
	}
	return processed.join("");
};

global.date2String = function(d) {
	var date = d.getDate();
	if (date<10) {
		date= "0"+date;
	}
	var month = d.getMonth() +1;
	if (month<10) {
		month= "0"+month;
	}
	return date+"/"+month+"/"+d.getFullYear();
};
