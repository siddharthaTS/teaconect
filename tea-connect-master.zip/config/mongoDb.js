
const MongoClient = require("mongodb").MongoClient;
const ObjectID = require("mongodb").ObjectID;

module.exports = async function(app) {
	try {
		const client = await MongoClient.connect("mongodb://localhost:27017", {poolSize: 5, useUnifiedTopology: true});
		const db = client.db("teaconnect");
		app.context.mongo = db;
		app.context.ObjectID = ObjectID;
	} catch (err) {
		// console.log(err);
		throw new Error(500);
	}
};
