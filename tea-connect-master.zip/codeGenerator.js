/* eslint-disable no-console */
/* eslint-disable no-useless-escape */
const fs = require("fs");
const path = require("path");
const changeCase = require("change-case");

function getViewURLName(name) {
	return changeCase.sentenceCase(name).toLowerCase().split(" ").join("-");
}

function getPrivilegeName(name) {
	return changeCase.sentenceCase(name).toLowerCase().split(" ").join("_");
}

function capitalizeFirstLetter(string) {
	return string.charAt(0).toUpperCase() + string.slice(1);
}

function spreadSheetColumnName(string) {
	return string.split(" ").join("").toLowerCase();
}

function printValidationConditions(obj) {
	var validations = "";
	if (!obj.nullable) {
		validations = "required ";
	}
	if (obj.type == "STRING") {
		if (obj.min) {
			validations += "minlength=\"" + obj.min + "\" ";
		}
		if (obj.max) {
			validations += "maxlength=\"" + obj.max + "\" ";
		}
	} else if (obj.type == "NUMBER") {
		if (obj.min) {
			validations += "min=\"" + obj.min + "\" ";
		}
		if (obj.max) {
			validations += "max=\"" + obj.max + "\" ";
		}
	} else if (obj.type == "MOBILE") {
		validations += "data-parsley-type=\"digits\" min=\"1000000000\" max=\"9999999999\" ";
	} else if (obj.type == "EMAIL") {
		validations += "data-parsley-type=\"email\" ";
	} else if (obj.type == "DAYOFWEEK") {
		validations += "pattern=\"\\bSun\\b|\\bMon\\b\|\\bTue\\b\|\\bWed\\b\|\\bThu\\b\|\\bFri\\b\|\\bSat\\b\" ";
	}

	return validations;
}

// eslint-disable-next-line no-unused-vars
function initBooleanAndDateField(model) {
	const keys = Object.keys(model);
	let hasDateField = false;
	let hasBooleanField = false;
	for (let loop=0, length= keys.length; loop< length; loop++) {
		if ((!hasDateField) && (model[keys[loop]].type=="DATE")) {
			hasDateField = true;
		} else if ((!hasBooleanField) && (model[keys[loop]].type=="BOOLEAN")) {
			hasBooleanField = true;
		}
		if (hasBooleanField && hasDateField) {
			break;
		}
	}
	const jsInsert = `
        ${hasBooleanField?"$(\".boolean-field\").checkbox();":""}
        ${hasDateField ?`$("input.datepicker").daterangepicker(
        {
          format: 'DD MMM YYYY',
          singleDatePicker: true,
          showDropdowns: true,
          startDate: moment()
        },
        function(start, end, label) {
          $("input.datepicker").attr("data-value",start.toDate().getTime());
        }
      );

`:""}`;
	return jsInsert;
}

function generateBooleanField(modelName, fieldName) {
	return `
         <label class="fake-toggle">
          <input name="${fieldName}" type="checkbox" ng-model="current${capitalizeFirstLetter(modelName)}.${fieldName}" />
          <span></span>
        </label>`;
}

function addPlaceholders(type) {
	if (type=="DAYOFWEEK") {
		return "placeholder=\"Day of week in ddd format\"";
	} else if (type=="MOBILE") {
		return "placeholder=\"10 digit mobile no\"";
	}

	return "";
}

const dir = ".gen";
if (!fs.existsSync(dir)) {
	fs.mkdirSync(dir);
}
const controllersDir = dir + path.sep + "controllers";
if (!fs.existsSync(controllersDir)) {
	fs.mkdirSync(controllersDir);
}
const modelsDir = dir + path.sep + "models";
if (!fs.existsSync(modelsDir)) {
	fs.mkdirSync(modelsDir);
}
const viewsDir = dir + path.sep + "views";
if (!fs.existsSync(viewsDir)) {
	fs.mkdirSync(viewsDir);
}
const partialViewsDir = viewsDir + path.sep + "partials";
if (!fs.existsSync(partialViewsDir)) {
	fs.mkdirSync(partialViewsDir);
}
const jsViewDir = dir + path.sep + "js";
if (!fs.existsSync(jsViewDir)) {
	fs.mkdirSync(jsViewDir);
}
const filesToSkip = [
	"sync",
	"user",
];
const files = fs.readdirSync("models/");
files.forEach(function(file) {
	const tmp = file.toString().split(".")[0];
	if (filesToSkip.indexOf(tmp)>=0) {
		return;
	}
	const model = require("./models/" + file)();
	if (model.metadata) {
		const _attributes = model.attributes;
		if (!_attributes) {
			return;
		}
		const attributeNames = Object.keys(_attributes);
		for (let loop=0, length = attributeNames.length; loop<length; loop++) {
			if (!_attributes[attributeNames[loop]].label) {
				_attributes[attributeNames[loop]].label = capitalizeFirstLetter(attributeNames[loop]);
			}
		}
		model.attributes = _attributes;
		const newFiles = [];
		newFiles.push(controllersDir + path.sep + model.metadata.name + "Controller.js");
		newFiles.push(dir + path.sep + "_"+model.metadata.name + "bulkValidationService.js");
		newFiles.push(modelsDir + path.sep + model.metadata.name + ".js");
		newFiles.push(viewsDir + path.sep + model.metadata.name + ".hbs");
		newFiles.push(jsViewDir + path.sep + model.metadata.name + "Management.js");
		newFiles.forEach(function(newFile, index) {
			fs.openSync(newFile, "w");
			if (index == 0) {
				createController(newFile, model);
			} else if (index == 1) {
				createBulkValidationService(newFile, model);
			} else if (index == 2) {
				createModel(newFile, model);
			} else if (index == 3) {
				createView(newFile, model);
			} else if (index == 4) {
				createJsView(newFile, model);
			}
		});
	}
});


function createController(file, model) {
	const contentArray = [];
	const modelAttributes = model.attributes;
	const attributeNames = Object.keys(modelAttributes);
	contentArray.push("const changeCase = require(\"change-case\");");
	contentArray.push("const validatorUtil = require(\"validator\");");
	contentArray.push("");
	/* validator function code start*/
	contentArray.push("function " + model.metadata.name + "Validator(input, validateExisting) {");
	var tmp = "\tif (!validateExisting && (!(";
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		if ((modelAttributes[attributeNames[loop]].source=="SESSION") || (modelAttributes[attributeNames[loop]].nullable) || (modelAttributes[attributeNames[loop]].type == "BOOLEAN")) {
			continue;
		}
		tmp += "input." + attributeNames[loop] + " && ";
	}
	tmp += "true))) {";
	contentArray.push(tmp);
	contentArray.push("\t\treturn {status: false, msg: \"Parameter(s) missing.\"};");
	contentArray.push("\t}");

	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		if (modelAttributes[attributeNames[loop]].type == "STRING") {
			if (modelAttributes[attributeNames[loop]].min && modelAttributes[attributeNames[loop]].max) {
				contentArray.push("\tif (input." + attributeNames[loop] + ") {");
				contentArray.push("\t\tif ((input." + attributeNames[loop] + ".length < " + modelAttributes[attributeNames[loop]].min + ") || (input." + attributeNames[loop] + ".length > " + modelAttributes[attributeNames[loop]].max + ")) {");
				contentArray.push("\t\t\treturn {status: false, msg: \"Invalid value for '" + (modelAttributes[attributeNames[loop]].label ? modelAttributes[attributeNames[loop]].label : attributeNames[loop]) + "'.\"};");
				contentArray.push("\t\t}");
				contentArray.push("\t}");
			}
			if (modelAttributes[attributeNames[loop]].transform) {
				contentArray.push("\tif (input." + attributeNames[loop] + ") {");
				tmp = "\t\tinput." + attributeNames[loop] + " = ";
				if (modelAttributes[attributeNames[loop]].transform == "UPPERCASE") {
					tmp += "input." + attributeNames[loop] + ".toUpperCase();";
				} else if (modelAttributes[attributeNames[loop]].transform == "LOWERCASE") {
					tmp += "input." + attributeNames[loop] + ".toLowerCase();";
				} else if (modelAttributes[attributeNames[loop]].transform == "TITLECASE") {
					tmp += "input." + attributeNames[loop] + ".toTitleCase();";
				}
				contentArray.push(tmp);
				contentArray.push("\t}");
			}
		} else if (modelAttributes[attributeNames[loop]].type == "NUMBER") {
			contentArray.push("\tif (input." + attributeNames[loop] + " != null) {");
			contentArray.push("\t\tinput." + attributeNames[loop] + " = Number(input." + attributeNames[loop] + ");");
			contentArray.push("\t\tif (isNaN(input." + attributeNames[loop] + ")) {");
			contentArray.push("\t\t\treturn {status: false, msg: \"Invalid value for '" + (modelAttributes[attributeNames[loop]].label ? modelAttributes[attributeNames[loop]].label : attributeNames[loop]) + "'.\"};");
			contentArray.push("\t\t}");
			contentArray.push("\t}");
			if (modelAttributes[attributeNames[loop]].min && modelAttributes[attributeNames[loop]].max) {
				contentArray.push("\tif ((input." + attributeNames[loop] + " < " + modelAttributes[attributeNames[loop]].min + ") || (input." + attributeNames[loop] + " > " + modelAttributes[attributeNames[loop]].max + ")) {");
				contentArray.push("\t\treturn {status: false, msg: \"Invalid value for '" + (modelAttributes[attributeNames[loop]].label ? modelAttributes[attributeNames[loop]].label : attributeNames[loop]) + "'.\"};");
				contentArray.push("\t}");
			}
		} else if (modelAttributes[attributeNames[loop]].type == "MOBILE") {
			contentArray.push("\tif (input." + attributeNames[loop] + ") {");
			contentArray.push("\t\tif (input." + attributeNames[loop] + ".length != 10 ) {");
			contentArray.push("\t\t\treturn {status: false, msg: \"Invalid value for '" + (modelAttributes[attributeNames[loop]].label ? modelAttributes[attributeNames[loop]].label : attributeNames[loop]) + "'.\"};");
			contentArray.push("\t\t}");
			contentArray.push("\t}");
		} else if (modelAttributes[attributeNames[loop]].type == "EMAIL") {
			contentArray.push("\tif (input." + attributeNames[loop] + ") {");
			contentArray.push("\t\tif (!validatorUtil.isEmail(input." + attributeNames[loop] + ")) {");
			contentArray.push("\t\t\treturn {status: false, msg: \"Invalid value for '" + (modelAttributes[attributeNames[loop]].label ? modelAttributes[attributeNames[loop]].label : attributeNames[loop]) + "'.\"};");
			contentArray.push("\t\t}");
			contentArray.push("\t}");
		} else if (modelAttributes[attributeNames[loop]].type == "DATE") {
			contentArray.push("\tif (input." + attributeNames[loop] + " != null) {");
			contentArray.push("\t\tinput." + attributeNames[loop] + " = Number(input." + attributeNames[loop] + ");");
			contentArray.push("\t\tif (isNaN(input." + attributeNames[loop] + ")) {");
			contentArray.push("\t\t\treturn {status: false, msg: \"Invalid value for '" + (modelAttributes[attributeNames[loop]].label ? modelAttributes[attributeNames[loop]].label : attributeNames[loop]) + "'.\"};");
			contentArray.push("\t\t}");
			contentArray.push("\t\tconst " + attributeNames[loop] + "ValDt = new Date();");
			contentArray.push("\t\t" + attributeNames[loop] + "ValDt.setTime(input." + attributeNames[loop] + ");");
			contentArray.push("\t\tinput." + attributeNames[loop] + " = " + attributeNames[loop] + "ValDt;");
			contentArray.push("\t}");
		} else if (modelAttributes[attributeNames[loop]].type == "BOOLEAN") {
			contentArray.push("\tif (input." + attributeNames[loop] + " == true) {");
			contentArray.push("\t\tinput." + attributeNames[loop] + " = true;");
			contentArray.push("\t} else if ((input." + attributeNames[loop] + " != null) && (input." + attributeNames[loop] + " != undefined)) {");
			contentArray.push("\t\tinput." + attributeNames[loop] + " = false;");
			contentArray.push("\t}");
		}
	}
	contentArray.push("\tconst _ = require(\"lodash\");");
	contentArray.push("\tinput = _.omitBy(input, _.isNil);");
	contentArray.push("\treturn {status: true, msg: \"\", data: input};");
	contentArray.push("}");
	/* validator function code end*/
	contentArray.push("");
	contentArray.push("module.exports = {");
	/* create code start*/
	contentArray.push("\tcreate"+capitalizeFirstLetter(model.metadata.name)+": async (ctx) => {");

	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		if (modelAttributes[attributeNames[loop]].source=="SESSION") {
			contentArray.push("\t\tconst " + attributeNames[loop] + "Val = ctx.session." + attributeNames[loop] +" || ctx.request.fields." + attributeNames[loop] +";");
		} else {
			contentArray.push("\t\tconst " + attributeNames[loop] + "Val = ctx.request.fields." + attributeNames[loop] +";");
		}
	}
	contentArray.push("");
	contentArray.push("\t\tconst now = new Date();");
	contentArray.push("\t\tconst input = {");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		contentArray.push("\t\t\t" + attributeNames[loop] + ": " + attributeNames[loop] + "Val,");
	}
	contentArray.push("\t\t};");
	contentArray.push("\t\tinput.isActive = true;");
	contentArray.push("\t\tinput.createdBy = ctx.session.userId || ctx.request.fields.userId;");
	contentArray.push("\t\tinput.updatedBy = ctx.session.userId || ctx.request.fields.userId;");
	contentArray.push("\t\tif (!input.createdBy) {");
	contentArray.push("\t\t\treturn ctx.ok({status: false, msg: \"Session expired or invalid entry\"});");
	contentArray.push("\t\t}");
	contentArray.push("\t\tinput.companyId = ctx.request.fields.companyId || global.hostCompanyId;");
	contentArray.push("\t\tinput.companyId = ctx.ObjectID(input.companyId);");
	contentArray.push("\t\tinput.createdBy = ctx.ObjectID(input.createdBy);");
	contentArray.push("\t\tinput.updatedBy = ctx.ObjectID(input.updatedBy);");
	contentArray.push("\t\tinput.createdAt = now;");
	contentArray.push("\t\tinput.updatedAt = now;");
	contentArray.push("");
	contentArray.push("\t\tconst validationResult = " + model.metadata.name + "Validator(input);");
	contentArray.push("\t\tif (!validationResult.status) {");
	contentArray.push("\t\t\treturn ctx.ok(validationResult);");
	contentArray.push("\t\t}");
	contentArray.push("\t\tconst model = require(\"../models/" + model.metadata.name + "\")(ctx);");
	contentArray.push("\t\tlet result = await model.create(validationResult.data);");
	contentArray.push("\t\tif (!result.status) {");
	contentArray.push("\t\t\treturn ctx.ok(result);");
	contentArray.push("\t\t}");
	contentArray.push("\t\tresult = model.serialize([result.doc]);");
	contentArray.push("\t\tif (!result.status) {");
	contentArray.push("\t\t\treturn ctx.ok(result);");
	contentArray.push("\t\t}");
	contentArray.push("\t\treturn ctx.ok({status: true, msg: \"OK\", doc: result.docs[0]});");
	contentArray.push("\t},");
	/* create code end*/

	/* update code start*/
	contentArray.push("\tupdate"+capitalizeFirstLetter(model.metadata.name)+": async (ctx) => {");
	contentArray.push("\t\tif (!(ctx.request.fields.find && ctx.request.fields.update)) {");
	contentArray.push("\t\t\treturn ctx.ok({status: false, msg: \"Parameter(s) missing.\"});");
	contentArray.push("\t\t}");
	contentArray.push("\t\tconst "+ model.metadata.name +"Id = ctx.request.fields.find;");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		contentArray.push("\t\tconst " + attributeNames[loop] + "Val = ctx.request.fields.update." + attributeNames[loop] + ";");
	}
	contentArray.push("\t\tconst isActiveVal = ctx.request.fields.update.isActive;");
	contentArray.push("");
	contentArray.push("\t\tconst now = new Date();");
	contentArray.push("\t\tlet input = {");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		contentArray.push("\t\t\t" + attributeNames[loop] + ": " + attributeNames[loop] + "Val,");
	}
	contentArray.push("\t\t\tisActive: isActiveVal,");
	contentArray.push("\t\t};");
	contentArray.push("");
	contentArray.push("\t\tconst validationResult = " + model.metadata.name + "Validator(input, true);");
	contentArray.push("\t\tif (!validationResult.status) {");
	contentArray.push("\t\t\treturn ctx.ok(validationResult);");
	contentArray.push("\t\t}");
	contentArray.push("\t\tinput = validationResult.data;");
	contentArray.push("\t\tinput.updatedBy = ctx.session.userId || ctx.request.fields.userId;");
	contentArray.push("\t\tif (!input.updatedBy) {");
	contentArray.push("\t\t\treturn ctx.ok({status: false, msg: \"Session expired or invalid entry\"});");
	contentArray.push("\t\t}");
	contentArray.push("\t\tinput.updatedBy = ctx.ObjectID(input.updatedBy);");
	contentArray.push("\t\tinput.updatedAt = now;");
	contentArray.push("\t\tconst model = require(\"../models/" + model.metadata.name + "\")(ctx);");
	contentArray.push("\t\tlet result = await model.update("+ model.metadata.name+"Id, input);");
	contentArray.push("\t\tif (!result.status) {");
	contentArray.push("\t\t\treturn ctx.ok(result);");
	contentArray.push("\t\t}");
	contentArray.push("\t\tresult = model.serialize([result.doc]);");
	contentArray.push("\t\tif (!result.status) {");
	contentArray.push("\t\t\treturn ctx.ok(result);");
	contentArray.push("\t\t}");
	contentArray.push("\t\treturn ctx.ok({status: true, msg: \"OK\", doc: result.docs[0]});");
	contentArray.push("\t},");
	/* update code end*/

	/* bulkCreate code start*/
	contentArray.push("\tbulkCreate"+capitalizeFirstLetter(model.metadata.name)+": async (ctx) => {");
	contentArray.push("\t\tif (!(ctx.session.userId || ctx.request.fields.userId)) {");
	contentArray.push("\t\t\treturn ctx.ok({status: false, msg: \"Session expired/invalid entry.\"});");
	contentArray.push("\t\t}");
	contentArray.push("\t\tconst userId = ctx.session.userId || ctx.request.fields.userId;");
	contentArray.push("\t\tconst companyId = ctx.request.fields.companyId || global.hostCompanyId;");
	contentArray.push("\t\ttry {");
	contentArray.push("\t\t\tconst uploadedFilePath = ctx.request.fields.upload[0].path;");
	contentArray.push("\t\t\tfor (let loop = 0, length = ctx.request.files.length; loop < length; loop++) {");
	contentArray.push("\t\t\t\tif (ctx.request.files[loop].path != uploadedFilePath) {");
	contentArray.push("\t\t\t\t\tfs.unlinkSync(ctx.request.files[loop].path);");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t\tif (!uploadedFilePath) {");
	contentArray.push("\t\t\t\treturn ctx.ok({status: false, msg: \"Parameter(s) missing.\"});");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t\tconst XLSX = require(\"xlsx-style\");");
	contentArray.push("\t\t\tlet requiredJson = null;");
	contentArray.push("\t\t\tconst workbook = XLSX.readFile(uploadedFilePath);");
	contentArray.push("\t\t\tconst first_sheet_name = workbook.SheetNames[0];");
	contentArray.push("\t\t\tconst worksheet = workbook.Sheets[first_sheet_name];");
	contentArray.push("\t\t\trequiredJson = XLSX.utils.sheet_to_json(worksheet, {raw: true});");
	contentArray.push("\t\t\t// const path = require(\"path\");");
	contentArray.push("\t\t\tconst fs = require(\"fs\");");
	contentArray.push("\t\t\tfs.unlinkSync(uploadedFilePath);");
	contentArray.push("\t\t\tif (!requiredJson) {");
	contentArray.push("\t\t\t\treturn ctx.ok({status: false, msg: \"Uploaded file was empty or had data in unrecognised format.\"});");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t\tconst validatorService = require(\"../services/bulkValidationService\")(ctx);");
	contentArray.push("\t\t\tconst validatedResult = await validatorService.validate"+capitalizeFirstLetter(model.metadata.plural)+"(requiredJson, userId, companyId);");
	contentArray.push("\t\t\tif (validatedResult.docs.length == 0 && validatedResult.outcome.length == 0) {");
	contentArray.push("\t\t\t\treturn ctx.ok({");
	contentArray.push("\t\t\t\t\tstatus: false,");
	contentArray.push("\t\t\t\t\tmsg: \"Uploaded file was empty or had data in unrecognised format.\",");
	contentArray.push("\t\t\t\t});");
	contentArray.push("\t\t\t} else if (validatedResult.docs.length == 0 && validatedResult.outcome.length > 0) {");
	contentArray.push("\t\t\t\treturn ctx.ok({");
	contentArray.push("\t\t\t\t\tstatus: true,");
	contentArray.push("\t\t\t\t\tmsg: \"\",");
	contentArray.push("\t\t\t\t\toutcome: validatedResult.outcome,");
	contentArray.push("\t\t\t\t\tsuccessCount: 0,");
	contentArray.push("\t\t\t\t});");
	contentArray.push("\t\t\t} else {");
	contentArray.push("\t\t\t\tconst model = require(\"../models/"+ model.metadata.name +"\")(ctx);");
	contentArray.push("\t\t\t\tconst "+ model.metadata.name +"Result = await model.bulkCreate(validatedResult.docs);");
	contentArray.push("\t\t\t\tif (!"+ model.metadata.name +"Result.status) {");
	contentArray.push("\t\t\t\t\treturn ctx.ok({status: false, msg: \"Illegal or invalid values.\"});");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tfor (var loop = 0, length = "+model.metadata.name+"Result.result.outcome.length; loop < length; loop++) {");
	contentArray.push("\t\t\t\t\tvalidatedResult.outcome[validatedResult.ref[loop]] = "+model.metadata.name+"Result.result.outcome[loop];");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tlet "+ model.metadata.name +"Result2 = await model.list({companyId: ctx.ObjectID(companyId)});");
	contentArray.push("\t\t\t\tif ("+ model.metadata.name +"Result2.status) {");
	contentArray.push("\t\t\t\t\t"+ model.metadata.name +"Result2 = model.serialize("+ model.metadata.name +"Result2.docs);");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tif ("+ model.metadata.name +"Result2.status) {");
	contentArray.push("\t\t\t\t\treturn ctx.ok({");
	contentArray.push("\t\t\t\t\t\tstatus: true,");
	contentArray.push("\t\t\t\t\t\tmsg: \"\",");
	contentArray.push("\t\t\t\t\t\toutcome: validatedResult.outcome,");
	contentArray.push("\t\t\t\t\t\tsuccessCount: "+model.metadata.name+"Result.result.successCount,");
	contentArray.push("\t\t\t\t\t\tdocs: "+model.metadata.name+"Result2.docs,");
	contentArray.push("\t\t\t\t\t});");
	contentArray.push("\t\t\t\t} else {");
	contentArray.push("\t\t\t\t\treturn ctx.ok({");
	contentArray.push("\t\t\t\t\t\tstatus: true,");
	contentArray.push("\t\t\t\t\t\tmsg: \"\",");
	contentArray.push("\t\t\t\t\t\toutcome: validatedResult.outcome,");
	contentArray.push("\t\t\t\t\t\tsuccessCount: "+model.metadata.name+"Result.result.successCount,");
	contentArray.push("\t\t\t\t\t});");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t} catch (err) {");
	contentArray.push("\t\t\tconsole.log(err);");
	contentArray.push("\t\t\treturn ctx.ok({status: false, msg: \"Illegal or invalid values.\"});");
	contentArray.push("\t\t}");
	contentArray.push("\t},");
	/* bulkCreate code end*/
	contentArray.push("}");
	fs.writeFile(file, contentArray.join("\n"), function(err) {
		if (err) {
			return console.log(err);
		}
	});
}

function createBulkValidationService(file, model) {
	const contentArray = [];
	const modelAttributes = model.attributes;
	const attributeNames = Object.keys(modelAttributes);
	const columnNames = [];
	contentArray.push("const "+ model.metadata.plural + "ValidationMap = {");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		if (modelAttributes[attributeNames[loop]].source=="SESSION") {
			continue;
		}
		const _columnName = spreadSheetColumnName(modelAttributes[attributeNames[loop]].label);
		columnNames.push(modelAttributes[attributeNames[loop]].label);
		contentArray.push("\t"+ _columnName + ": {");
		contentArray.push("\t\tname: \""+attributeNames[loop]+"\",");
		contentArray.push("\t\tlabel: \""+modelAttributes[attributeNames[loop]].label+"\",");
		contentArray.push("\t\tnullable: {");
		if (modelAttributes[attributeNames[loop]].nullable) {
			contentArray.push("\t\t\tval: true,");
			contentArray.push("\t\t\tmsg: \"\",");
		} else {
			contentArray.push("\t\t\tval: false,");
			contentArray.push("\t\t\tmsg: \""+ modelAttributes[attributeNames[loop]].label +" is required.\",");
		}
		contentArray.push("\t\t},");
		if (modelAttributes[attributeNames[loop]].type=="NUMBER") {
			contentArray.push("\t\tnumeric: {");
			contentArray.push("\t\t\tval: null,");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" must be a valid number.\",");
			contentArray.push("\t\t},");
		}
		if (modelAttributes[attributeNames[loop]].type=="EMAIL") {
			contentArray.push("\t\temail: {");
			contentArray.push("\t\t\tval: null,");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" must be a valid email address.\",");
			contentArray.push("\t\t},");
		}
		if ((modelAttributes[attributeNames[loop]].type=="STRING") && (modelAttributes[attributeNames[loop]].min)) {
			contentArray.push("\t\tmin: {");
			contentArray.push("\t\t\tval: "+modelAttributes[attributeNames[loop]].min+",");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" must be atleast "+modelAttributes[attributeNames[loop]].min+" character long\",");
			contentArray.push("\t\t},");
		}
		if ((modelAttributes[attributeNames[loop]].type=="STRING") && (modelAttributes[attributeNames[loop]].max)) {
			contentArray.push("\t\tmax: {");
			contentArray.push("\t\t\tval: "+modelAttributes[attributeNames[loop]].max+",");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" can maximum be "+modelAttributes[attributeNames[loop]].max+" character long\",");
			contentArray.push("\t\t},");
		}
		if ((modelAttributes[attributeNames[loop]].type=="NUMBER") && (modelAttributes[attributeNames[loop]].min)) {
			contentArray.push("\t\tgtEqualTo: {");
			contentArray.push("\t\t\tval: "+modelAttributes[attributeNames[loop]].min+",");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" must be greater than or equal to  "+modelAttributes[attributeNames[loop]].min+"\",");
			contentArray.push("\t\t},");
		}
		if ((modelAttributes[attributeNames[loop]].type=="NUMBER") && (modelAttributes[attributeNames[loop]].max)) {
			contentArray.push("\t\tltEqualTo: {");
			contentArray.push("\t\t\tval: "+modelAttributes[attributeNames[loop]].max+",");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" must be less than or equal to  "+modelAttributes[attributeNames[loop]].max+"\",");
			contentArray.push("\t\t},");
		}
		if ((modelAttributes[attributeNames[loop]].type=="STRING") && (modelAttributes[attributeNames[loop]].transform)) {
			if (modelAttributes[attributeNames[loop]].transform=="TITLECASE") {
				contentArray.push("\t\ttransform: \"TitleCase\",");
			} else if (modelAttributes[attributeNames[loop]].transform=="UPPERCASE") {
				contentArray.push("\t\ttransform: \"UpperCase\",");
			} else if (modelAttributes[attributeNames[loop]].transform=="LOWERCASE") {
				contentArray.push("\t\ttransform: \"LowerCase\",");
			}
		}
		if (modelAttributes[attributeNames[loop]].type=="NUMBER") {
			contentArray.push("\t\ttransform: \"Number\",");
		}
		if (modelAttributes[attributeNames[loop]].type=="DATE") {
			contentArray.push("\t\ttransform: \"Date\",");
		}
		if (modelAttributes[attributeNames[loop]].type=="BOOLEAN") {
			contentArray.push("\t\ttransform: \"Boolean\",");
		}
		if (modelAttributes[attributeNames[loop]].type=="DAYOFWEEK") {
			contentArray.push("\t\tcustom: {");
			contentArray.push("\t\t\tval: null,");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" must be a valid day of week in 'ddd' format\",");
			contentArray.push("\t\t}");
		}
		if (modelAttributes[attributeNames[loop]].type=="OBJECTID") {
			contentArray.push("\t\tcustom: {");
			contentArray.push("\t\t\tval: null,");
			contentArray.push("\t\t\tmsg: \""+modelAttributes[attributeNames[loop]].label+" must be a valid "+(modelAttributes[attributeNames[loop]].label?modelAttributes[attributeNames[loop]].label:attributeNames[loop])+"\",");
			contentArray.push("\t\t},");
		}
		contentArray.push("\t},");
	}
	contentArray.push("};");
	contentArray.push("module.exports = (ctx) => {");
	contentArray.push("\treturn{");
	contentArray.push("\t\tvalidate"+capitalizeFirstLetter(model.metadata.plural)+": async (docs, currentUser, companyId) => {");
	contentArray.push("\t\t\tconst validationMap = JSON.parse(JSON.stringify("+model.metadata.plural + "ValidationMap));");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		const _columnName = spreadSheetColumnName(modelAttributes[attributeNames[loop]].label);
		if (modelAttributes[attributeNames[loop]].type=="DAYOFWEEK") {
			contentArray.push("\t\t\tvalidationMap."+_columnName+".custom.val = async function(input, validatedObj) {");
			contentArray.push("\t\t\t\tif(dayOfWeeks.indexOf(input)>=0){");
			contentArray.push("\t\t\t\t\treturn true;");
			contentArray.push("\t\t\t\t}");
			contentArray.push("\t\t\t\treturn false;");
			contentArray.push("\t\t\t};");
		} else if (modelAttributes[attributeNames[loop]].type=="OBJECTID") {
			contentArray.push("\t\t\tvalidationMap."+_columnName+".custom.val = async function(input, validatedObj) {");
			// contentArray.push("\t\t\t\t");
			// contentArray.push("\t\t\t\t");
			// contentArray.push("\t\t\t\t");
			contentArray.push("\t\t\t\treturn true;");
			contentArray.push("\t\t\t};");
		}
	}
	contentArray.push("\t\t\tconst result = await doValidation(ctx, docs, validationMap, currentUser, companyId, []);");
	contentArray.push("\t\t\treturn result;");
	contentArray.push("\t\t}");
	contentArray.push("\t}");
	contentArray.push("}");
	fs.writeFile(file, contentArray.join("\n"), function(err) {
		if (err) {
			return console.log(err);
		}
	});
	fs.writeFile(dir+path.sep+"create_"+model.metadata.plural+".csv", columnNames.join(","), function(err) {
		if (err) {
			return console.log(err);
		}
	});
}

function createModel(file, model) {
	const contentArray = [];
	const modelAttributes = model.attributes;
	const attributeNames = Object.keys(modelAttributes);

	contentArray.push("module.exports = (ctx) => {");
	contentArray.push("\treturn {");
	contentArray.push("\t\tcreate: async (input) => {");
	contentArray.push("\t\t\ttry {");
	contentArray.push("\t\t\t\tif (!input._id) {");
	contentArray.push("\t\t\t\t\tinput._id = new ctx.ObjectID();");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tawait ctx.mongo.collection(\""+model.metadata.collection+"\").insertOne(input);");
	contentArray.push("\t\t\t\treturn {status: true, msg: \""+model.metadata.name+" created\", doc: input};");
	contentArray.push("\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\treturn {status: false, msg: \"encountered an unexpected error.\"};");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t},");
	contentArray.push("\t\tupdate: async (id, values, projection) => {");
	contentArray.push("\t\t\ttry {");
	contentArray.push("\t\t\t\tif (!projection) {");
	contentArray.push("\t\t\t\t\tprojection={");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		contentArray.push("\t\t\t\t\t\t" + attributeNames[loop] +": 1,");
	}
	contentArray.push("\t\t\t\t\t\tisActive: 1,");
	contentArray.push("\t\t\t\t\t};");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tconst unset = {};");
	contentArray.push("\t\t\t\tif ((values.isActive==null) || (values.isActive==undefined)) {");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		if (modelAttributes[attributeNames[loop]].nullable) {
			contentArray.push("\t\t\t\t\tif ((values."+attributeNames[loop]+" == null ) || (values."+attributeNames[loop]+" == undefined ) || (values."+attributeNames[loop]+" == \"\" )) {");
			contentArray.push("\t\t\t\t\t\tunset[\""+attributeNames[loop]+"\"] = 1;");
			contentArray.push("\t\t\t\t\t\tdelete values."+attributeNames[loop]+";");
			contentArray.push("\t\t\t\t\t}");
		}
	}
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tconst updateObj = {$set: values};");
	contentArray.push("\t\t\t\tif (Object.keys(unset).length>0) {");
	contentArray.push("\t\t\t\t\tupdateObj[\"$unset\"] = unset;");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tconst result = await ctx.mongo.collection(\""+model.metadata.collection+"\").findOneAndUpdate({");
	contentArray.push("\t\t\t\t\t_id: ctx.ObjectID(id),");
	contentArray.push("\t\t\t\t}, updateObj, {");
	contentArray.push("\t\t\t\t\treturnOriginal: false, projection: projection,");
	contentArray.push("\t\t\t\t});");
	contentArray.push("\t\t\t\treturn {status: true, msg: \""+model.metadata.name+" updated\", doc: result.value};");
	contentArray.push("\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\treturn {status: false, msg: \"encountered an unexpected error.\"};");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t},");
	contentArray.push("\t\tbulkCreate: async (docs) => {");
	contentArray.push("\t\t\ttry {");
	contentArray.push("\t\t\t\tconst bulk = ctx.mongo.collection(\""+model.metadata.collection+"\").initializeUnorderedBulkOp();");
	contentArray.push("\t\t\t\tconst indexes = [];");
	contentArray.push("\t\t\t\tconst messages = [];");
	contentArray.push("\t\t\t\tconst outcome = [];");
	contentArray.push("\t\t\t\tlet writeErrors = [];");
	contentArray.push("\t\t\t\tfor (var loop = 0; loop < docs.length; loop++) {");
	contentArray.push("\t\t\t\t\toutcome.push(\"Record inserted successfully.\");");
	contentArray.push("\t\t\t\t\tif (docs[loop].companyId) {");
	contentArray.push("\t\t\t\t\t\tdocs[loop].companyId = ctx.ObjectID(docs[loop].companyId);");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t\tif (docs[loop].createdBy) {");
	contentArray.push("\t\t\t\t\t\tdocs[loop].createdBy = ctx.ObjectID(docs[loop].createdBy);");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t\tif (docs[loop].updatedBy) {");
	contentArray.push("\t\t\t\t\t\tdocs[loop].updatedBy = ctx.ObjectID(docs[loop].updatedBy);");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t\tbulk.insert(docs[loop]);");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\ttry {");
	contentArray.push("\t\t\t\t\tconst result = await bulk.execute();");
	contentArray.push("\t\t\t\t\twriteErrors = result.getWriteErrors();");
	contentArray.push("\t\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\t\twriteErrors = err.result.getWriteErrors();");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tif (writeErrors.length == 0) {");
	contentArray.push("\t\t\t\t\treturn {status: true, msg: \"OK\", result: {outcome: outcome, successCount: outcome.length}};");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tconst innerLength = indexes.length;");
	contentArray.push("\t\t\t\tfor (let loop = 0, length = writeErrors.length; loop < length; loop++) {");
	contentArray.push("\t\t\t\t\tlet matchFound = false;");
	contentArray.push("\t\t\t\t\tfor (let innerLoop = 0; innerLoop < innerLength; innerLoop++) {");
	contentArray.push("\t\t\t\t\t\tif (writeErrors[loop].errmsg.indexOf(indexes[innerLoop]) >= 0) {");
	contentArray.push("\t\t\t\t\t\t\toutcome[writeErrors[loop].index] = messages[innerLoop];");
	contentArray.push("\t\t\t\t\t\t\tmatchFound = true;");
	contentArray.push("\t\t\t\t\t\t\tbreak;");
	contentArray.push("\t\t\t\t\t\t}");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t\tif (!matchFound) {");
	contentArray.push("\t\t\t\t\t\toutcome[writeErrors[loop].index] = \"Record not inserted.\";");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\treturn {status: true, msg: \"OK\", result: {outcome: outcome, successCount: (outcome.length - writeErrors.length)}};");
	contentArray.push("\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\treturn {status: false, msg: \"encountered an unexpected error.\"};");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t},");
	contentArray.push("\t\tlist: async (query, projection) => {");
	contentArray.push("\t\t\ttry {");
	contentArray.push("\t\t\t\tif (!projection) {");
	contentArray.push("\t\t\t\t\tprojection={");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		contentArray.push("\t\t\t\t\t\t" + attributeNames[loop] +": 1,");
	}
	contentArray.push("\t\t\t\t\t\tisActive: 1,");
	contentArray.push("\t\t\t\t\t};");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tconst docs = await ctx.mongo.collection(\""+model.metadata.collection+"\").find(query, {projection: projection}).toArray();");
	contentArray.push("\t\t\t\treturn {status: true, msg: \"Ok\", docs: docs};");
	contentArray.push("\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\treturn {status: false, msg: \"encountered an unexpected error.\"};");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t},");
	contentArray.push("\t\tdetails: async (query, projection) => {");
	contentArray.push("\t\t\ttry {");
	contentArray.push("\t\t\t\tif (!projection) {");
	contentArray.push("\t\t\t\t\tprojection={");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		contentArray.push("\t\t\t\t\t\t" + attributeNames[loop] +": 1,");
	}
	contentArray.push("\t\t\t\t\t\tisActive: 1,");
	contentArray.push("\t\t\t\t\t};");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\tconst doc = await ctx.mongo.collection(\""+model.metadata.collection+"\").findOne(query, {projection: projection});");
	contentArray.push("\t\t\t\treturn {status: true, msg: \"Ok\", doc: doc};");
	contentArray.push("\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\treturn {status: false, msg: \"encountered an unexpected error.\"};");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t},");
	contentArray.push("\t\tserialize: (docs) => {");
	contentArray.push("\t\t\ttry {");
	contentArray.push("\t\t\t\tfor (let loop=0, length=docs.length; loop<length; loop++) {");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		if (modelAttributes[attributeNames[loop]].type=="DATE") {
			contentArray.push("\t\t\t\t\tif (docs[loop][\"" + attributeNames[loop] +"\"]) {");
			contentArray.push("\t\t\t\t\t\tdocs[loop][\"" + attributeNames[loop] +"\"] = docs[loop][\""+ attributeNames[loop] +"\"].getTime();");
			contentArray.push("\t\t\t\t\t}");
		}
	}
	contentArray.push("\t\t\t\t\tif (docs[loop][\"createdAt\"]) {");
	contentArray.push("\t\t\t\t\t\tdocs[loop][\"createdAt\"] = docs[loop][\"createdAt\"].getTime();");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t\tif (docs[loop][\"updatedAt\"]) {");
	contentArray.push("\t\t\t\t\t\tdocs[loop][\"updatedAt\"] = docs[loop][\"updatedAt\"].getTime();");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\treturn {status: true, msg: \"Ok\", docs: docs};");
	contentArray.push("\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\treturn {status: false, msg: \"encountered an unexpected error.\"};");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t},");
	contentArray.push("\t\tdeserialize: (docs) => {");
	contentArray.push("\t\t\ttry {");
	contentArray.push("\t\t\t\tfor (let loop=0, length=docs.length; loop<length; loop++) {");
	for (let loop = 0, length = attributeNames.length; loop < length; loop++) {
		if (modelAttributes[attributeNames[loop]].type=="DATE") {
			contentArray.push("\t\t\t\t\tif (docs[loop][\"" + attributeNames[loop] +"\"]) {");
			contentArray.push("\t\t\t\t\t\tdocs[loop][\"" + attributeNames[loop] +"\"] = new Date(docs[loop][\""+ attributeNames[loop] +"\"]);");
			contentArray.push("\t\t\t\t\t}");
		}
	}
	contentArray.push("\t\t\t\t\tif (docs[loop][\"createdAt\"]) {");
	contentArray.push("\t\t\t\t\t\tdocs[loop][\"createdAt\"] = new Date(docs[loop][\"createdAt\"]);");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t\tif (docs[loop][\"updatedAt\"]) {");
	contentArray.push("\t\t\t\t\t\tdocs[loop][\"updatedAt\"] = new Date(docs[loop][\"updatedAt\"]);");
	contentArray.push("\t\t\t\t\t}");
	contentArray.push("\t\t\t\t}");
	contentArray.push("\t\t\t\treturn {status: true, msg: \"Ok\", docs: docs};");
	contentArray.push("\t\t\t} catch (err) {");
	contentArray.push("\t\t\t\treturn {status: false, msg: \"encountered an unexpected error.\"};");
	contentArray.push("\t\t\t}");
	contentArray.push("\t\t},");
	contentArray.push("\t}");
	contentArray.push("}");
	fs.writeFile(file, contentArray.join("\n"), function(err) {
		if (err) {
			return console.log(err);
		}
	});
}

function createView(file, model) {
	const modelAttributes = model.attributes;
	const attributeNames = Object.keys(modelAttributes);
	const localPartialViewsDir = partialViewsDir + path.sep + model.metadata.name + "Management";
	if (!fs.existsSync(localPartialViewsDir)) {
		fs.mkdirSync(localPartialViewsDir);
	}
	const tmpNames = [];
	for (let loop=0, length = attributeNames.length; loop< length; loop++) {
		if (!modelAttributes[attributeNames[loop]].nullable) {
			tmpNames.push(attributeNames[loop]);
		}
	}
	const selectedLength = tmpNames.length<5?tmpNames.length:5;
	const selectedAttributes = tmpNames.slice(0, selectedLength);
	var content = `
{{> header}}
<script type="text/javascript">
    {{{ _initVariable '${model.metadata.plural}' ${model.metadata.plural}}}}
</script>
<div class="ui secondary pointing fluid menu">
  <h2 style="margin-left: 30px;" class="ui header">${capitalizeFirstLetter(model.metadata.name)} Management</h2>

  <div class="right menu inner-nav-menu">
    <a class="ui item inner-nav-menu-list" href="masters/${getViewURLName(model.metadata.name)}-management.html#/list">
      ${capitalizeFirstLetter(model.metadata.plural)}
    </a>
    {{#hasPrivilege privileges '${getPrivilegeName(model.metadata.name)}_management' 'create' true}}
      <a class="ui item inner-nav-menu-create" href="masters/${getViewURLName(model.metadata.name)}-management.html#/create">
        Create
      </a>
    {{/hasPrivilege}}
    {{#hasPrivilege privileges '${getPrivilegeName(model.metadata.name)}_management' 'update' true}}
      <a class="ui item inner-nav-menu-update" href="masters/${getViewURLName(model.metadata.name)}-management.html#/update">
        Update
      </a>
    {{/hasPrivilege}}
  </div>
</div>
<div class="ui container" ui-view="main" style="text-align: start;">
</div>
<div style="display: block; height: 20px;width: 100%"></div>
<div class="upload-status-modal ui small modal" style="" data-target="">
  <div class="header" style="height:30px;">
    ${capitalizeFirstLetter(model.metadata.plural)} created
  </div>
  <div class="content">
    <p><span>2/5 ${capitalizeFirstLetter(model.metadata.plural)} created,</span> <a href="javascript:downloadExcel();">Click here to view details</a></p>
  </div>
  <div class="actions">
    <div class="ui positive button">
      Okay
    </div>
  </div>
</div>
<script type="text/ng-template" id="/list.tpl.html">
    {{> ${model.metadata.name}Management/list}}
</script>
<script type="text/ng-template" id="/create.tpl.html">
    {{> ${model.metadata.name}Management/create}}
</script>
<script type="text/ng-template" id="/update.tpl.html">
    {{> ${model.metadata.name}Management/update}}
</script>
{{> footer}}
`;

	fs.writeFile(file, content, function(err) {
		if (err) {
			return console.log(err);
		}
	});

	var listPartialContent = `
<div class="ui floating warning message" ng-if="${model.metadata.plural}.length == 0">
  <div class="header">
    Currently there are no ${model.metadata.plural}
  </div>
  <a ui-sref="create">Click here</a> to create a ${model.metadata.name}.
</div>
<div class="ui" ng-if="${model.metadata.plural}.length > 0" style="margin-top: 20px;">
  <div class="content">
    <div class="ui">
      <form class="ui form">
        <div class="field">
          <div class="sixteen wide field">
            <div class="ui icon input">
              <input type="text" name="name" placeholder="Search ${model.metadata.plural}" ng-model="${model.metadata.name}Search">
              <i class="search icon"></i>
            </div>
          </div>
        </div>
      </form>
      <div style="height: 5px;"></div>
      <div class="scrable_table">

        <table class="ui unstackable table data_table">
          <thead>
          <tr>${selectedAttributes.map((attr, i) => `
            <th>${capitalizeFirstLetter(modelAttributes[attr].label?modelAttributes[attr].label:attr)}</th>`).join("")}
            <th>Active</th>
            <th>Action</th>
            <th style="width: 30px;"></th>
          </tr>
          </thead>
          <tbody>
          <tr dir-paginate="${model.metadata.name} in ${model.metadata.plural} | filter:${model.metadata.name}Search | itemsPerPage:20">
            ${selectedAttributes.map((attr, i) => `<td>\\{{${model.metadata.name}.${attr}}}</td>
            `).join("")}<td>
              <div class="user-list ui toggle checkbox read-only" ng-class="${model.metadata.name}.isActive?'checked ' + ${model.metadata.name}._id:${model.metadata.name}._id" ng-click="setEnableddisabled(${model.metadata.name});">
                <input id="\\{{${model.metadata.name}._id}}" type="checkbox" ng-checked="${model.metadata.name}.isActive" onclick="return false;">
                <label></label>
              </div>
            </td>
            <td>
              {{#hasPrivilege privileges '${getPrivilegeName(model.metadata.name)}_management' 'update' true}}
                <i title="Update ${capitalizeFirstLetter(model.metadata.name)}" class="large edit link icon" ng-click="navUpdate(${model.metadata.name});"></i>
              {{/hasPrivilege}}
            </td>
            <td style="width: 30px;">
              <i class="notched circle loading icon" style="visibility: hidden;"></i>
            </td>
          </tr>
          </tbody>
        </table>
        <dir-pagination-controls max-size="7" direction-links="true" boundary-links="true">
        </dir-pagination-controls>
      </div>
    </div>
  </div>
</div>
    `;

	fs.writeFile(localPartialViewsDir+path.sep+"list.hbs", listPartialContent, function(err) {
		if (err) {
			return console.log(err);
		}
	});

	var selectionPartialContent = `
<div id="${model.metadata.name}_selection" class="ui fluid search selection dropdown" style="margin-bottom: 20px;">
  <input type="hidden" name="user">
  <i class="dropdown icon"></i>
  <div class="default text">Select ${capitalizeFirstLetter(model.metadata.name)}</div>
  <div class="menu">
    <div ng-repeat="${model.metadata.name} in ${model.metadata.plural}" class="item" data-value="\\{{${model.metadata.name}._id}}"><i class="address book outline icon"></i>\\{{${model.metadata.name}.name}}</div>
  </div>
</div>
<input type="hidden" id="proxy-${model.metadata.name}-change" ng-click="${model.metadata.name}Changed();"/>
    
    `;
	fs.writeFile(localPartialViewsDir+path.sep+model.metadata.name+"Selection.hbs", selectionPartialContent, function(err) {
		if (err) {
			return console.log(err);
		}
	});

	var updatePartialContent = `
{{> ${model.metadata.name}Management / ${model.metadata.name}Selection}}
{{> ${model.metadata.name}Management / ${model.metadata.name}Form}}
<div id="submit_update_${model.metadata.name}" class="ui primary button disabled" ng-click="submitUpdate${capitalizeFirstLetter(model.metadata.name)}();">
  <i class="checkmark icon"></i>
  Update
</div>
<div id="reset_update_${model.metadata.name}" class="ui secondary button disabled" ng-click="resetUpdate${capitalizeFirstLetter(model.metadata.name)}();">
  <i class="undo icon"></i>
  Reset
</div>    
    `;

	fs.writeFile(localPartialViewsDir+path.sep+"update.hbs", updatePartialContent, function(err) {
		if (err) {
			return console.log(err);
		}
	});

	var createPartialContent = `
<div class="ui top attached tabular menu create-${model.metadata.name}-tabs">
  <div class="active item" data-tab="first">Using Form</div>
  <div class="item" data-tab="second">Using File Upload</div>
</div>
<div class="ui bottom attached active tab segment" data-tab="first">
  <div style="width:100%; height:20px;"></div>
  {{> ${model.metadata.name}Management / ${model.metadata.name}Form}}
  <div id="submit_create_${model.metadata.name}" class="ui primary button" ng-click="submitCreate${capitalizeFirstLetter(model.metadata.name)}();">
    <i class="checkmark icon"></i>
    Create
  </div>
  <div id="reset_create_${model.metadata.name}" class="ui secondary button" ng-click="clearCreate${capitalizeFirstLetter(model.metadata.name)}();">
    <i class="undo icon"></i>
    Clear
  </div>
</div>
<div class="ui bottom attached tab segment file-upload-tab" data-tab="second">
  <div id="holder" class="ui segment div_drag" style="min-height: 280px;cursor: pointer;text-align: center;" onclick="$('#file_for_upload').click();">
    <i class="massive cloud upload icon"></i>
    <div>
      <p>
        <label> drag and drop file or click to upload</label>
        <a class="ui basic large label" style="display:none">file name .xlsx</a>
      </p>
      <div class="ui tiny images" style="opacity: 0.3;">
        <img class="ui image" src="/images/ods.svg">
        <img class="ui image" src="/images/xls.svg">
        <img class="ui image" src="/images/xlsx.svg">
      </div>
    </div>
  </div>
  <input type="file" id="file_for_upload" style="display:none" onchange="processFileForUpload(event);" accept="application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.oasis.opendocument.spreadsheet"/>
  <ul class="parsley-errors-list filled"><li class="parsley-required"></li></ul>
  <div id="submit_create_${model.metadata.name}_bulk" class="ui primary button disabled" ng-click="submitCreate${capitalizeFirstLetter(model.metadata.name)}Bulk();">
    <i class="checkmark icon"></i>
    Create
  </div>
  <div id="reset_create_${model.metadata.name}_bulk" class="ui secondary button" ng-click="clearCreate${capitalizeFirstLetter(model.metadata.name)}Bulk();">
    <i class="undo icon"></i>
    Clear
  </div>
  <a href="/samplefiles/create_${model.metadata.plural}.xlsx">View sample file</a>
</div> 
    `;

	fs.writeFile(localPartialViewsDir+path.sep+"create.hbs", createPartialContent, function(err) {
		if (err) {
			return console.log(err);
		}
	});


	var formPartialContent = `
<form class="ui form" id="${model.metadata.plural}_form" style="margin-bottom: 20px;">
${attributeNames.map((attr, i) => `<div class="field">
    <label>${capitalizeFirstLetter(modelAttributes[attr].label?modelAttributes[attr].label:attr)} ${modelAttributes[attr].nullable?"":"*"}<span class="parsley-error-custom ${attr}"></span></label>
    <div class="twelve wide field">
      <div class="field">${(modelAttributes[attr].type=="BOOLEAN")?generateBooleanField(model.metadata.name, attr):`
        <input name="${attr}" ${addPlaceholders(modelAttributes[attr].type)} type="text" ${(modelAttributes[attr].type=="DATE")?"class=\"datepicker\"":` ng-model="current${capitalizeFirstLetter(model.metadata.name)}.${attr}"`} ${printValidationConditions(modelAttributes[attr])} data-parsley-errors-container=".parsley-error-custom.${attr}">`}
      </div>
    </div>
  </div>
`).join("")}</form>
    `;

	fs.writeFile(localPartialViewsDir+path.sep+model.metadata.name+"Form.hbs", formPartialContent, function(err) {
		if (err) {
			return console.log(err);
		}
	});
}

function createJsView(file, model) {
	var content=`
/* global ${model.metadata.plural}:true*/
/* eslint no-global-assign:0 */

app.config(["$stateProvider", "$urlRouterProvider", "$locationProvider", function($stateProvider, $urlRouterProvider, $locationProvider) {
	$urlRouterProvider.otherwise("/list");
	$stateProvider
		.state("list", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-list").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/list.tpl.html",
					controller: "${model.metadata.name}Controller",
				},
			},
			url: "/list",
		})
		.state("create", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-create").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/create.tpl.html",
					controller: "${model.metadata.name}Controller",
				},
			},
			url: "/create",
		})
		.state("update", {
			onEnter: function() {
				$(".inner-nav-menu").find("a").removeClass("active");
				$(".inner-nav-menu-update").addClass("active");
			},
			views: {
				"main": {
					templateUrl: "/update.tpl.html",
					controller: "${model.metadata.name}Controller",
				},
			},
			url: "/update?${model.metadata.name}id",
		});
}]);
var currentState = null;
var currentParams = null;
app.run(["$rootScope", "$state", "$location", "$window", function run($rootScope, $state, $location, $window) {
	$rootScope.$on("$stateChangeStart", function(e, toState, toParams, fromState, fromParams) {
	//
	});
	$rootScope.$on("$stateChangeError", function(event, toState, toParams, fromState, fromParams, error) {
	//
	});
	$rootScope.$on("$stateChangeSuccess", function(event, toState, toParams, fromState, fromParams) {
		currentState = toState;
		currentParams = toParams;
	});
	$rootScope.$on("$viewContentLoaded", function(e, toState, toParams, fromState, fromParams) {
		if (currentState && ["update"].indexOf(currentState.name) >= 0) {
			$("#${model.metadata.name}_selection").dropdown({forceSelection: false});
			$("#${model.metadata.name}_selection").dropdown("setting", "onChange", function(val) {
				setTimeout(function() {
					$("#proxy-${model.metadata.name}-change").click();
				}, 200);
			});
			setTimeout(function() {
				if (currentParams.${model.metadata.name}id) {
					$("#${model.metadata.name}_selection").dropdown("set selected", currentParams.${model.metadata.name}id);
				}
			}, 300);
		}
		if (currentState && ["create"].indexOf(currentState.name) >= 0) {
			$(".create-${model.metadata.name}-tabs .item").tab();
			holder = document.getElementById("holder");
			holder.ondragover = function() {
				$(this).addClass("div_drag_hover");
				return false;
			};
			holder.ondragend = function() {
				$(this).removeClass("div_drag_hover");
				return false;
			};
			holder.ondrop = function(e) {
				$(this).removeClass("div_drag_hover");
				e.preventDefault();
				processFileForUpload(e);
			};
			setTimeout(function() {
				$(".boolean-field").checkbox();
				$("input.datepicker").each(function(idx, ele) {
					$(ele).daterangepicker({
						format: "DD MMM YYYY",
						singleDatePicker: true,
						showDropdowns: true,
						startDate: moment(),
					},
					function(start, end, label) {
						$(ele).attr("data-value", start.toDate().getTime());
					});
				});
			}, 500);
		}
	});
}]);

app.controller("${model.metadata.name}Controller", ["$scope", "$rootScope", "$stateParams", "dataFactory", "$state", "$timeout", function($scope, $rootScope, $stateParams, dataFactory, $state, $timeout) {
	$scope.${model.metadata.plural} = ${model.metadata.plural};
	$scope.current${capitalizeFirstLetter(model.metadata.name)} = {isActive: true};
	$scope.current${capitalizeFirstLetter(model.metadata.name)}Org = {isActive: true};
	$scope.${model.metadata.plural}UnderProcessing = {};


	$scope.${model.metadata.name}Changed = function() {
		var ${model.metadata.name}Id = $("#${model.metadata.name}_selection input").val();
		if (${model.metadata.name}Id.length > 1) {
			if ($state.current.name == "update") {
				var posIn${capitalizeFirstLetter(model.metadata.plural)} = _.findIndex($scope.${model.metadata.plural}, ["_id", ${model.metadata.name}Id]);
				if (posIn${capitalizeFirstLetter(model.metadata.plural)} > -1) {
					$scope.current${capitalizeFirstLetter(model.metadata.name)} = JSON.parse(JSON.stringify($scope.${model.metadata.plural}[posIn${capitalizeFirstLetter(model.metadata.plural)}]));
					$scope.current${capitalizeFirstLetter(model.metadata.name)}Org = JSON.parse(JSON.stringify($scope.${model.metadata.plural}[posIn${capitalizeFirstLetter(model.metadata.plural)}]));
					$(".datepicker").each(function(idx, ele) {
						try {
							$(ele).attr("data-value", $scope.current${capitalizeFirstLetter(model.metadata.name)}[$(ele).attr("name")]);
							var tmpMoment = moment($scope.current${capitalizeFirstLetter(model.metadata.name)}[$(ele).attr("name")]);
							$(ele).val(tmpMoment.format("DD MMM YYYY"));
							$(ele).daterangepicker({
								format: "DD MMM YYYY",
								singleDatePicker: true,
								showDropdowns: true,
								startDate: tmpMoment,
							},
							function(start, end, label) {
								$(ele).attr("data-value", start.toDate().getTime());
							});
						} catch (e) {
							//
						}
					});
					$(".boolean-field").checkbox("uncheck");
					$(".boolean-field").each(function(idx, ele) {
						try {
							if ($scope.current${capitalizeFirstLetter(model.metadata.name)}[$(ele).attr("data-field-name")]) {
								$(ele).checkbox("check");
							}
						} catch (e) {
							//
						}
					});
					$("#submit_update_${model.metadata.name}").removeClass("disabled");
					$("#reset_update_${model.metadata.name}").removeClass("disabled");
				}
			}
		}
	};

	$scope.navUpdate = function(${model.metadata.name}) {
		$state.go("update", {${model.metadata.name}id: ${model.metadata.name}._id});
	};

	$scope.submitUpdate${capitalizeFirstLetter(model.metadata.name)} = function() {
		var parsleyHandle = $("#${model.metadata.plural}_form").parsley();
		parsleyHandle.validate();
		if (parsleyHandle.isValid()) {
			$("#submit_update_${model.metadata.name}").addClass("loading disabled");
			$("#reset_update_${model.metadata.name}").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			var _tmp = JSON.parse(JSON.stringify($scope.current${capitalizeFirstLetter(model.metadata.name)}));
			delete _tmp.isActive;
			var payload = {
				find: $("#${model.metadata.name}_selection input").val(),
				update: _tmp,
			};
			dataFactory.post("update-${model.metadata.name}.json", payload).then(function(data) {
				$("#submit_update_${model.metadata.name}").removeClass("loading disabled");
				$("#reset_update_${model.metadata.name}").removeClass("disabled");
				if (data.status) {
					dataFactory.toastSuccess("${capitalizeFirstLetter(model.metadata.name)} updated successfully");
					var posIn${capitalizeFirstLetter(model.metadata.plural)} = _.findIndex(${model.metadata.plural}, ["_id", $("#${model.metadata.name}_selection input").val()]);
					if (posIn${capitalizeFirstLetter(model.metadata.plural)} >= 0) {
						${model.metadata.plural}[posIn${capitalizeFirstLetter(model.metadata.plural)}] = data.doc;
						$scope.${model.metadata.plural} = ${model.metadata.plural};
						$scope.current${capitalizeFirstLetter(model.metadata.name)}Org = JSON.parse(JSON.stringify(data.doc));
					}
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_update_${model.metadata.name}").removeClass("loading disabled");
				$("#reset_update_${model.metadata.name}").removeClass("disabled");
			});
		}
	};

	$scope.resetUpdate${capitalizeFirstLetter(model.metadata.name)} = function() {
		$scope.current${capitalizeFirstLetter(model.metadata.name)} = JSON.parse(JSON.stringify($scope.current${capitalizeFirstLetter(model.metadata.name)}Org));
	};

	$scope.setEnableddisabled = function(${model.metadata.name}) {
		if ($scope.${model.metadata.plural}UnderProcessing[${model.metadata.name}._id]) {
			return;
		}
		$scope.${model.metadata.plural}UnderProcessing[${model.metadata.name}._id] = true;
		$("." + ${model.metadata.name}._id).parent().parent().find(".notched.circle.loading").css("visibility", "visible");
		$("." + ${model.metadata.name}._id).checkbox();
		var payload = {
			find: ${model.metadata.name}._id,
			update: {isActive: (!${model.metadata.name}.isActive)},
		};
		dataFactory.post("update-${model.metadata.name}.json", payload).then(function(data) {
			if (data.status) {
				${model.metadata.name}.isActive = data.doc.isActive;
				$timeout(function() {
					if (${model.metadata.name}.isActive) {
						$("." + ${model.metadata.name}._id).checkbox("check");
					} else {
						$("." + ${model.metadata.name}._id).checkbox("uncheck");
					}
					$("." + ${model.metadata.name}._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				}, 200);
			} else {
				$("." + ${model.metadata.name}._id).parent().parent().find(".notched.circle.loading").css("visibility", "hidden");
				dataFactory.toastError(data.msg);
			}
			$scope.${model.metadata.plural}UnderProcessing[${model.metadata.name}._id] = false;
		}, function() {
			$("." + ${model.metadata.name}._id).parent().parent().find(".notched.circle.loading").hide();
			dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
			$scope.${model.metadata.plural}UnderProcessing[${model.metadata.name}._id] = false;
		});
	};

	$scope.submitCreate${capitalizeFirstLetter(model.metadata.name)} = function() {
		var parsleyHandle = $("#${model.metadata.plural}_form").parsley();
		parsleyHandle.validate();
		var additionalValidations = true;
		if (parsleyHandle.isValid() && additionalValidations) {
			$("#submit_create_${model.metadata.name}").addClass("loading disabled");
			$("#reset_create_${model.metadata.name}").addClass("disabled");
			$scope.loadDateAndBooleanFields();
			dataFactory.post("create-${model.metadata.name}.json", $scope.current${capitalizeFirstLetter(model.metadata.name)}).then(function(data) {
				$("#submit_create_${model.metadata.name}").removeClass("loading disabled");
				$("#reset_create_${model.metadata.name}").addClass("disabled");
				if (data.status) {
					${model.metadata.plural}.push(data.doc);
					$scope.${model.metadata.plural} = ${model.metadata.plural};
					$scope.clearCreate${capitalizeFirstLetter(model.metadata.name)}();
					dataFactory.toastSuccess("${capitalizeFirstLetter(model.metadata.name)} created successfully");
				} else {
					dataFactory.toastError(data.msg);
				}
			}, function() {
				dataFactory.toastError("we have encounterd an unexpected error, plesae try after some time.");
				$("#submit_create_${model.metadata.name}").removeClass("loading disabled");
			});
		}
	};

	$scope.clearCreate${capitalizeFirstLetter(model.metadata.name)} = function() {
		$scope.current${capitalizeFirstLetter(model.metadata.name)} = {isActive: true};
	};

	$scope.submitCreate${capitalizeFirstLetter(model.metadata.name)}Bulk = function() {
		$("#submit_create_${model.metadata.name}_bulk").addClass("loading");
		$.ajax({
			url: BASE_URL + "bulk-${model.metadata.name}-create.json",
			data: window.fileUploadForm,
			cache: false,
			contentType: false,
			processData: false,
			type: "POST",
			dataType: "json",
			success: function(data) {
				if (data.status) {
					$scope.clearCreate${capitalizeFirstLetter(model.metadata.name)}Bulk();
					uploadResultArray = [];
					for (var loop = 0; loop < data.outcome.length; loop++) {
						uploadResultArray.push([data.outcome[loop]]);
					}
					if (data.docs) {
						${model.metadata.plural} = data.docs;
						$scope.${model.metadata.plural} = ${model.metadata.plural};
					}
					$(".upload-status-modal p span").html(data.successCount + "/" + data.outcome.length + "${capitalizeFirstLetter(model.metadata.plural)} created.");
					$(".upload-status-modal").modal({closable: false}).modal("show");
				} else {
					dataFactory.toastError(data.msg);
				}
				window.fileUploadForm = null;
				$("#submit_create_${model.metadata.name}_bulk").removeClass("loading");
			},
			error: function() {
				$("#submit_create_${model.metadata.name}_bulk").removeClass("loading");
				dataFactory.toastError("Currently we are unable to process your request, plesae try later.");
			},
		});
	};

	$scope.clearCreate${capitalizeFirstLetter(model.metadata.name)}Bulk = function() {
		$(".file-upload-tab .parsley-required").html("");
		$("#holder p label").show();
		$("#holder p a").html("");
		$("#holder p a").hide();
		$("#submit_create_${model.metadata.name}_bulk").addClass("disabled");
		$("#reset_create_${model.metadata.name}_bulk").addClass("disabled");
		window.fileUploadForm = null;
	};

	$scope.loadDateAndBooleanFields = function() {
		$(".datepicker").each(function(idx, ele) {
			try {
				$scope.current${capitalizeFirstLetter(model.metadata.name)}[$(ele).attr("name")] = Number($(ele).attr("data-value"));
			} catch (e) {
				//
			}
		});

		$(".boolean-field").each(function(idx, ele) {
			try {
				$scope.current${capitalizeFirstLetter(model.metadata.name)}[$(ele).attr("data-field-name")] = $(ele).hasClass("checked");
			} catch (e) {
				//
			}
		});

		$(".foreign-field").each(function(idx, ele) {
			try {
				$scope.current${capitalizeFirstLetter(model.metadata.name)}[$(ele).attr("data-field-name")] = $(ele).find("input").val();
			} catch (e) {
				//
			}
		});
	};
}]);
var holder = null;

function processFileForUpload(e) {
	try {
		var files = e.target.files || e.dataTransfer.files || e.originalEvent.dataTransfer.files;
		var file = files[0];
		if (file) {
			if (/\\.(xls|xlsx|ods)$/i.test(file.name)) {
				var extention = file.name.toUpperCase().split(".");
				extention = extention[extention.length - 1];
				$(".file-upload-tab .parsley-required").html("");
				if (file.size > (512 * 1024 * 1024)) {
					$(".file-upload-tab .parsley-required").html("Please use a file smaller than 512kB");
					return;
				}
				$(".file-upload-tab .parsley-required").html("");
				$("#holder p label").hide();
				$("#holder p a").html(file.name);
				$("#holder p a").show();
				$("#submit_create_${model.metadata.name}_bulk").removeClass("disabled");
				$("#reset_create_${model.metadata.name}_bulk").removeClass("disabled");
				window.fileUploadForm = new FormData();
				window.fileUploadForm.append("extention", extention);
				window.fileUploadForm.append("upload", file);
				document.getElementById("file_for_upload").value = "";
			} else {
				$(".file-upload-tab .parsley-required").html("Only <i>xls, xlsx, ods<i/> files are allowed.");
			}
		}
		return;
	} catch (err) {
		//
	}
}
var uploadResultArray = [[]];
// eslint-disable-next-line no-unused-vars
function downloadExcel() {
	$(".upload-status-modal .positive").click();
	var wb = new Workbook();
	var ws = sheet_from_array_of_arrays(uploadResultArray);
	wb.SheetNames.push("outcome");
	wb.Sheets["outcome"] = ws;
	var wbout = XLSX.write(wb, {
		bookType: "xlsx",
		bookSST: true,
		type: "binary",
	});
	saveAs(new Blob([s2ab(wbout)], {
		type: "application/octet-stream",
	}), "outcome_" + new Date().getTime() + ".xlsx");
}

`;

	fs.writeFile(file, content, function(err) {
		if (err) {
			return console.log(err);
		}
	});
}
